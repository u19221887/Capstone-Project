﻿using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations.Schema;

namespace AceSystemAPI.Models
{
    public class TutorSubject: BaseEntity
    {

        [ForeignKey(nameof(Subject))]
        public int SubjectId { get; set; }

        [ForeignKey(nameof(TutorGrade))]
        public int TutorGradeId { get; set; }

        //crate tutor and company availability objects

        public Subject? Subject { get; set; }

        public TutorGrade? TutorGrade { get; set;}
    }
}
