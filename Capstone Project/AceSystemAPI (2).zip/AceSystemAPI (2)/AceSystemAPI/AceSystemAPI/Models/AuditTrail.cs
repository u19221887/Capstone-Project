﻿using AceSystemAPI.Models.Repositories;

namespace AceSystemAPI.Models
{
    public class AuditTrail: BaseEntity
    {
        public string Email { get; set; }

        public string Action { get; set; }

        public DateTime Date { get; set; }
    }
}
