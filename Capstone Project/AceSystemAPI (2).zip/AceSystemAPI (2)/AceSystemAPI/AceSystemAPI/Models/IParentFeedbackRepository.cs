using Microsoft.AspNetCore.Mvc;

namespace AceSystemAPI.Models
{
  public interface IParentFeedbackRepository
  {
    void Add<T>(T entity) where T : class;
    Task<bool> SaveChangesAsync();
    Task<ParentFeedback[]> GetAllFeedbacksAsync();

  }
}
