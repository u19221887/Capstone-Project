﻿using Microsoft.EntityFrameworkCore;

namespace AceSystemAPI.Models
{
    public class SubjectRepository : ISubjectRepository
    {
        private readonly AppDbContext _appDbContext;

        public SubjectRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void Delete<T>(T entity) where T : class
        {
            _appDbContext.Remove(entity);
        }
        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _appDbContext.SaveChangesAsync() > 0;
        }

        public async Task<Subject[]> GetAllSubjectsAsync()
        {
            IQueryable<Subject> query = _appDbContext.Subjects;
            return await query.ToArrayAsync();
        }

        public async Task<Subject> GetSubjectAsync(int subjectId)
        {
            IQueryable<Subject> query = _appDbContext.Subjects.Where(c => c.Id == subjectId);

            return await query.FirstOrDefaultAsync();

        }


    }
}

