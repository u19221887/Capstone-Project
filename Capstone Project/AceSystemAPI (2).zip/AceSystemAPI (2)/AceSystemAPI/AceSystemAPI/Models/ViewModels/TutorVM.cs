﻿namespace AceSystemAPI.Models.ViewModels
{
    public class TutorVM
    {
        public int Id { get; set; }

        public string Name { get; set; } = string.Empty;

        public string StudentName { get; set; } = string.Empty;

        public string Subject { get; set; } = string.Empty;

        public string Price { get; set; } = string.Empty;

        public string? Type { get; set; }

        public bool isPayedUp { get; set; }

        public bool isDiscountApplied { get; set; } = false;
        public int TutorId { get; set; }
        public DateTime StartTime { get; set; }

        public DateTime EndTime { get; set; }
        public DateTime Date { get; set; }

    }
}
