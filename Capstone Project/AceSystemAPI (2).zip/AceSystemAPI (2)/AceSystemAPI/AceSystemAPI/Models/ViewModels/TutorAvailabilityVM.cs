﻿namespace AceSystemAPI.Models.ViewModels
{
    public class TutorAvailabilityVM
    {
        public int TutorId { get; set; }
        public int[]? CompanyAvailabilities { get; set; }

        public DateTime Date { get; set; }

    }
}
