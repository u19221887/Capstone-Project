﻿namespace AceSystemAPI.Models.ViewModels
{
    public class SubjectTutorViewModel
    {
        public int SubjectId { get; set; }
        public int TutorId { get; set; }
    }
}