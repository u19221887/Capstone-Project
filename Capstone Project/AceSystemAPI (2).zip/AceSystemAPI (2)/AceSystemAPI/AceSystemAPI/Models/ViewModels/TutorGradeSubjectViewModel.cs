﻿namespace AceSystemAPI.Models.ViewModels
{
    public class TutorGradeSubjectViewModel
    {
        public int TutorGradeId { get; set; }
        public int[]? Subjects { get; set; }
    }
}
