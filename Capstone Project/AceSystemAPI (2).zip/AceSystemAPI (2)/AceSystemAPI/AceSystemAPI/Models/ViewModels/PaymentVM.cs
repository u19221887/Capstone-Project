﻿namespace AceSystemAPI.Models.ViewModels
{
    public class PaymentVM
    {
        public int BookingId { get; set; }


        public string Ref { get; set; } = string.Empty;

        public int Amount { get; set; }

    }
}
