namespace AceSystemAPI.ViewModels
{
  public class RecordingsViewModel
  {
    public string Name { get; set; } = string.Empty;
    public string Description { get; set; } = string.Empty;
    public string? Date { get; set; } = string.Empty;
    public string? FilePath { get; set; } = string.Empty;
    public string? FileName { get; set; } = string.Empty;
    public IFormFile? VideoFile { get; set; }
    public int? Subject_Id { get; set; }


    public RecordingsViewModel(string name, string description, string date, string filePath, string fileName, IFormFile? videoFile, int subject_Id)
    {
      Name = name;
      Description = description;
      Date = date;
      FilePath = filePath;
      FileName = filePath;
      VideoFile = videoFile;
      Subject_Id = subject_Id;
    }

    public RecordingsViewModel()
    {

    }
  }
}
