﻿namespace AceSystemAPI.Models.ViewModels
{
    public class TutorGradeViewModel
    {
        public int TutorId { get; set; }
        public int[]? Grades { get; set; }
    }
}
