using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
  public class Recordings
  {
    [Key]
    public int Recordings_ID { get; set; }
    [Required, StringLength(100)]
    public string Name { get; set; }
    [Required, StringLength(12)]
    public string Date { get; set; }
    [Required, StringLength(100)]
    public string Description { get; set; }
    [Required, StringLength(255)]
    public string FileName { get; set; }
    [Required, MaxLengthAttribute]
    public string FilePath { get; set; }

    //Link to TutorSubject
    public int? Subject_Id { get; set; }
    public TutorSubject? Subject { get; set; }
  }
}
