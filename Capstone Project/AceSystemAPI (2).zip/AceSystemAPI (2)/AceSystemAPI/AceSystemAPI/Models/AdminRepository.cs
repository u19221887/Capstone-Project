﻿using Microsoft.EntityFrameworkCore;

namespace AceSystemAPI.Models
{
    public class AdminRepository : IAdminRepository
    {
        private readonly AppDbContext _appDbContext;


        public AdminRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        public void Delete<T>(T entity) where T : class
        {
            _appDbContext.Remove(entity);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _appDbContext.SaveChangesAsync() > 0;
        }

        public async Task<Admin[]> GetAllAdminsAsync()
        {
            IQueryable<Admin> query = _appDbContext.Admins;
            return await query.ToArrayAsync();
        }

        public async Task<Admin> GetAdminAsync(int adminId)
        {
            IQueryable<Admin> query = _appDbContext.Admins.Where(c => c.AdminId == adminId);

            return await query.FirstOrDefaultAsync();

        }

        public async Task<Admin> GetAdminProfileAsync(string adminEmail)
        {
            IQueryable<Admin> query = _appDbContext.Admins.Where(c => c.adminEmail == adminEmail);
            return await query.FirstOrDefaultAsync();
        }
    }
}

