﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models.Repositories
{
    public class BaseEntity
    {
        [Key]
        public int Id { get; set; }

    }
}