﻿namespace AceSystemAPI.Models
{
    public interface IDiscountRepository
    {
        void Add<T>(T entity) where T : class;
        void Delete<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<Discount> GetDiscountAsync(int discountId);
        Task<Discount[]> GetAllDiscountsAsync();

        Task<Discount[]> GetActiveDiscountsAsync();

        Task<Discount[]> GetInactiveDiscountsAsync();

        Task<DiscountStatus[]> GetDiscountStatusesAsync();



    }
}
