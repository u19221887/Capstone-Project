﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class TutorApplicationStatus
    {
        [Key]
        public int TutorApplicationStatusId { get; set; }
        public string TutorApplicationDescription { get; set; } = string.Empty;

        public virtual ICollection<TutorApplication> TutorApplications { get; set; }
    }
}
