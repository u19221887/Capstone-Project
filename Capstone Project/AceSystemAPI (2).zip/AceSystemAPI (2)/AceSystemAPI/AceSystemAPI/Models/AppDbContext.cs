﻿using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Bookings;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;


namespace AceSystemAPI.Models
{
    public class AppDbContext : IdentityDbContext<IdentityUser>
    {


        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options)
        {
        }

        public DbSet<Student> Students { get; set; }
        //public DbSet<Booking> Bookings { get; set; }
        public DbSet<Discount> Discounts { get; set; }
        public DbSet<DiscountStatus> DiscountStatuses { get; set; }
        //public DbSet<PaymentType> PaymentTypes { get; set; }
        //public DbSet<RescheduleBooking> RescheduleBookings { get; set; }
        //public DbSet<BookingStatus> BookingStatuses { get; set; }
        //public DbSet<BookingInstance> BookingInstances { get; set; }
        //public DbSet<Session> Sessions { get; set; }
        //public DbSet<SessionStatus> SessionStatuses { get; set; }
        //public DbSet<SessionType> SessionTypes { get; set; }
        public DbSet<Recordings> Recordings { get; set; }

        public DbSet<BookingType> BookingType { get; set; } 
        //public DbSet<PayFast> PayFasts { get; set; }
       
        public DbSet<TutorType> TutorTypes { get; set; }
        public DbSet<Admin> Admins { get; set; }
        public DbSet<ParentFeedback> ParentFeedbacks { get; set; }
        public DbSet<Grade> Grades { get; set; }
        //public DbSet<Homework> Homeworks { get; set; }
        //public DbSet<Password> Passwords { get; set; }
        //public DbSet<Refund> Refunds { get; set; }
        //public DbSet<RefundType> RefundTypes { get; set; }
        //public DbSet<StudentHomeworkLine> StudentHomeworkLines { get; set; }
        public DbSet<Subject> Subjects { get; set; }
        public DbSet<SubjectTutor> SubjectTutor { get; set; }
        
        public DbSet<TutorSubject> TutorSubjects { get; set; }
        //public DbSet<SubjectGradeLine> SubjectGradeLines { get; set; }
        //public DbSet<SubjectTutorLine> SubjectTutorLines { get; set; }
        //public DbSet<Timeslot> Timeslots { get; set; }
        //public DbSet<TimeslotStatus> TimeslotStatuses { get; set; }
        public DbSet<TutorApplication> TutorApplications { get; set; }
        public DbSet<TutorApplicationStatus> TutorApplicationsStatuses { get; set; }

        public DbSet<CompanyAvailability> CompanyAvailability { get; set; }

        public DbSet<_Booking> Booking { get; set; }
        public DbSet<Payment> Payment { get; set; }
        public DbSet<Tutors> Tutors { get; set; }
        public DbSet<TutorAvailability> TutorAvailability { get; set; }

        public DbSet<SessionCost> SessionCosts { get; set; }

        public DbSet<TutorGrade> TutorGrades { get; set; } 

        public DbSet<AuditTrail> AuditTrails { get; set; }


        //public DbSet<TutorHomeworkLine> TutorHomeworkLines { get; set; }
        //public DbSet<TutorStatus> TutorStatuses { get; set; }
        //public DbSet<TutorPrice> TutorPrices { get; set; }
        //public DbSet<TutorTimeslot> TutorTimeslots { get; set; }
        //public DbSet<User> Users { get; set; }
        //public DbSet<UserType> UserTypes { get; set; }
        //public DbSet<BookingType> BookingTypes { get; set; }



        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);
            this.SeedRoles(modelBuilder);
           this.SeedTimes(modelBuilder);


            //        modelBuilder.Entity<Admin>()
            //    .HasOne(a => a.User)
            //    .WithOne(u => u.Admin)
            //    .HasForeignKey<User>(u => u.Admin_ID);

            //        modelBuilder.Entity<TutorHomeworkLine>()
            //.HasOne(thl => thl.Tutor)
            //.WithMany()
            //.HasForeignKey(thl => thl.TutorId)
            //.OnDelete(DeleteBehavior.NoAction);

            //loadToSession cost

            //seed subject 
            //modelBuilder.Entity<Subject>()
            //   .HasData(
            //                  new
            //                  {
            //                      Id = 1,
            //                      subjectName = "InPerson",
            //                      Amount = 250.00
            //                  }               );


           modelBuilder.Entity<SessionCost>()
                .HasData(
                               new
                               {
                    Id = 1,
                    Description = "InPerson",
                    Amount = 250.00
                }
                                          );
            modelBuilder.Entity<SessionCost>()
                .HasData(
                                              new
                                              {
                    Id = 2,
                      Description = "Online",
                    Amount = 150.00
                }
                                                                                       );



            modelBuilder.Entity<DiscountStatus>()
               .HasData(
               new
               {
                   DiscountStatusId = 1,
                   DiscountStatusDescription = "Active"
               }
           );

            modelBuilder.Entity<BookingType>()
               .HasData(
               new
               {
                   Id = 1,
                   Description = "In-Person"
               }
           );

            modelBuilder.Entity<BookingType>()
               .HasData(
               new
               {
                   Id = 2,
                   Description = "Online"
               }
           );

            modelBuilder.Entity<DiscountStatus>()
               .HasData(
               new
               {
                   DiscountStatusId = 2,
                   DiscountStatusDescription = "Inactive"
               }
           );

            modelBuilder.Entity<TutorApplicationStatus>()
                .HasData(
                new
                {
                    TutorApplicationStatusId = 1,
                    TutorApplicationDescription = "Pending"
                }
           );

            modelBuilder.Entity<TutorApplicationStatus>()
               .HasData(
               new
               {
                   TutorApplicationStatusId = 2,
                   TutorApplicationDescription = "Accepted"
               }
          );

            modelBuilder.Entity<TutorApplicationStatus>()
               .HasData(
               new
               {
                   TutorApplicationStatusId = 3,
                   TutorApplicationDescription = "Rejected"
               }
          );

            modelBuilder.Entity<TutorType>()
               .HasData(
               new
               {
                   TutorTypeId = 1,
                   TutorTypeDescription = "Full-time"
               }
          );

            modelBuilder.Entity<TutorType>()
              .HasData(
              new
              {
                  TutorTypeId = 2,
                  TutorTypeDescription = "Part-time"
              }
         );
            modelBuilder.Entity<Grade>()
               .HasData(
               new
               {
                   Id = 1,
                   gradeName = "Grade 4"
               }
           );

            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 2,
                  gradeName = "Grade 5"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 3,
                  gradeName = "Grade 6"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 4,
                  gradeName = "Grade 7"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 5,
                  gradeName = "Grade 8"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 6,
                  gradeName = "Grade 9"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 7,
                  gradeName = "Grade 10"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 8,
                  gradeName = "Grade 11"
              }
          );
            modelBuilder.Entity<Grade>()
              .HasData(
              new
              {
                  Id = 9,
                  gradeName = "Grade 12"
              }
          );

        }


        protected void SeedRoles(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<IdentityRole>().HasData
                (
                    new IdentityRole() { Name = "Admin", ConcurrencyStamp = "1", NormalizedName = "Admin" },
                    new IdentityRole() { Name = "Student", ConcurrencyStamp = "2", NormalizedName = "Student" },
                    new IdentityRole() { Name = "Tutor", ConcurrencyStamp = "3", NormalizedName = "Tutor" }
                    );

        }

        protected void SeedTimes(ModelBuilder modelBuilder)
        {
            List<CompanyAvailability> availabilities = new List<CompanyAvailability>();

            // Define the start and end times as 8 am and 8 pm, respectively
            DateTime startTime = DateTime.Today.AddHours(8);
            DateTime endTime = DateTime.Today.AddHours(20);
            int idCounter = -1;
            // Loop from 8 am to 7 pm to create the availabilities
            while (startTime < endTime)
            {
                CompanyAvailability availability = new CompanyAvailability
                {
                    Id = idCounter,
                    startTime = startTime,
                    endTime = startTime.AddHours(1) // Adding 1 hour difference
                };

                availabilities.Add(availability);

                startTime = startTime.AddHours(1); // Move to the next hour
                idCounter--;
            }

            // Add configuration for CompanyAvailability entity
            modelBuilder.Entity<CompanyAvailability>(entity =>

                // Seed data
                entity.HasData(availabilities)
            );

        }
    }


}
