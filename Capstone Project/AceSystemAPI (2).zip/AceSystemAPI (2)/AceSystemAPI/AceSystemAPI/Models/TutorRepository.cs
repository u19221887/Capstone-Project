﻿using Microsoft.EntityFrameworkCore;

namespace AceSystemAPI.Models
{
    public class TutorRepository : ITutorRepository
    {
        private readonly AppDbContext _context;
        public TutorRepository(AppDbContext context)
        {
            _context = context;
        }

        public void Add<T>(T entity) where T : class
        {
            _context.Add(entity); ;
        }

        public void Delete<T>(T entity) where T : class
        {
            _context.Remove(entity);
        }

        public async Task<Tutors[]> GetAllTutorsAsync()
        {
            IQueryable<Tutors> query = _context.Tutors;
            return await query.ToArrayAsync();
        }

        public async Task<Tutors[]> GetFullTimeTutorsAsync()
        {
            IQueryable<Tutors> query = _context.Tutors.Where(c => c.TutorTypeId == 1);
            return await query.ToArrayAsync();
        }

        public async Task<Tutors[]> GetPartTimeTutorsAsync()
        {
            IQueryable<Tutors> query = _context.Tutors.Where(c => c.TutorTypeId == 2);
            return await query.ToArrayAsync();
        }

        public async Task<Tutors> GetTutorFromTutorApplicationAsync(int tutorId)
        {
            IQueryable<Tutors> query = _context.Tutors.Where(c => c.Id == tutorId);
            return await query.FirstOrDefaultAsync();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<TutorType[]> GetTutorTypesAsync()
        {
            IQueryable<TutorType> query = _context.TutorTypes;
            return await query.ToArrayAsync();
        }

        public async Task<TutorApplication> GetTutorApplicationAsync(int tutorApplicationId)
        {
            IQueryable<TutorApplication> query = _context.TutorApplications.Where(c => c.TutorApplicationId == tutorApplicationId);

            return await query.FirstOrDefaultAsync();
        }

        public async Task<Tutors> GetTutorProfileAsync(int tutorId)
        {
            IQueryable<Tutors> query = _context.Tutors.Where(c => c.Id == tutorId);
            return await query.FirstOrDefaultAsync();
        }

        public async Task<Tutors> GetTutorById(int tutorId)
        {
            IQueryable<Tutors> query = _context.Tutors.Where(c => c.Id == tutorId);
            return await query.FirstOrDefaultAsync();
        }


        //public async Task<Tutor> GetTutorFromTutorApplicationAsync(int tutorApplicationId)
        //{
        //    IQueryable<Tutor> query = _context.Tutors.Where(c => c.TutorApplicationId == tutorApplicationId);

        //    return await query.FirstOrDefaultAsync();
        //}

        public async Task<Tutors> GetTutorProfileAsync(string tutorEmail)
        {
            IQueryable<Tutors> query = _context.Tutors.Where(c => c.TutorEmail == tutorEmail);
            return await query.FirstOrDefaultAsync();
        }

    }
}

