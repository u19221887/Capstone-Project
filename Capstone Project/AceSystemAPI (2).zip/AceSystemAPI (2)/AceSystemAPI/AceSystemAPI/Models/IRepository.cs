﻿using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Bookings;
using AceSystemAPI.Models.Repositories;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace AceSystemAPI.Models.Interfaces
{
    public interface IRepository<T> where T : BaseEntity
    {
        Task<IEnumerable<T>> GetAllAsync();
        Task<T> GetByIdAsync(int id);
        void Add(T entity);

        void Update(T entity);

        void Remove(object Id);
        void Remove(T entity);

        Task<bool> SaveChangesAsync();

        void SaveChanges();
        Task<T> FindByConditionAsync(Expression<Func<T, bool>> predicate);

        Task<IEnumerable<T>> FindByListConditionAsync(Expression<Func<T, bool>> predicate);

        Task<_Booking[]> CountOnlineAsync();

        Task<_Booking[]> CountInPersonAsync();

        Task<SessionCost[]> GetSessionCostsAsync();
    }
}
