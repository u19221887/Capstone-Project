﻿using AceSystemAPI.ViewModels;

namespace AceSystemAPI.Models
{
    public interface ITutorApplicationRepository
    {
        void Add<T>(T entity) where T : class;
        void Delete<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<TutorApplication> GetTutorApplicationAsync(int TutorApplicationId);
        Task<TutorApplication> GetTutorApplicationAsyncByEmail(string TutorApplicationEmail);
        Task<TutorApplication[]> GetAllTutorApplicationsAsync();
        Task<TutorApplication[]> GetPendingTutorApplicationsAsync();
        Task<TutorApplication[]> GetAcceptedTutorApplicationsAsync();

    }
}
