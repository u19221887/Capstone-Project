﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class TutorType
    {
        [Key]
        public int TutorTypeId { get; set; }
        public string TutorTypeDescription { get; set; } = string.Empty;

        public virtual ICollection<Tutors> Tutor { get; set; }
    }
}
