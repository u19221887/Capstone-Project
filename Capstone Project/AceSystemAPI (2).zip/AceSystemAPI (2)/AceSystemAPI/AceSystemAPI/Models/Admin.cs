﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class Admin
    {
        [Key]
        public int AdminId { get; set; }
        public string adminName { get; set; } = String.Empty;
        public string adminSurname { get; set; } = String.Empty;
        public string adminPhoneNumber { get; set; } = String.Empty;
        public string adminEmail { get; set; } = String.Empty;

        public string adminIdNumber { get; set; } = String.Empty;

        //public User User { get; set; }
    }
}
