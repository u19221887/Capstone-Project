﻿using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Bookings;
using AceSystemAPI.Models.Interfaces;
using Microsoft.EntityFrameworkCore;
using System.Linq.Expressions;

namespace AceSystemAPI.Models.Repositories
{
    public class Repository<T> : IRepository<T> where T : BaseEntity
    {
        private readonly AppDbContext _context;
        private readonly DbSet<T> _entities;

        public Repository(AppDbContext context)
        {
            _context = context ?? throw new ArgumentNullException(nameof(context));
            _entities = context.Set<T>();
        }

        public async Task<IEnumerable<T>> GetAllAsync()
        {
            return await _entities.ToListAsync();
        }

        public async Task<T> GetByIdAsync(int id)
        {
            return await _entities.SingleOrDefaultAsync(s => s.Id == id);
        }

        public void Add(T entity)
        {
            _entities.Add(entity);
        }
        public void Update(T entity)
        {
            T updatedentity = _entities.Find(entity.Id);
            updatedentity = entity;
        }

        public void Remove(T entity)
        {
            _entities.Remove(entity);
        }

        public void Remove(object Id)
        {
            T entity = _entities.Find(Id);
            this.Remove(entity);
        }





        public async Task<bool> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync().ConfigureAwait(false) > 0;
        }

        public void SaveChanges()
        {
            _context.SaveChanges();
        }

        public async Task<T> FindByConditionAsync(Expression<Func<T, bool>> predicate)
        {
            return await _context.Set<T>().FirstOrDefaultAsync(predicate);
        }

        public async Task<IEnumerable<T>> FindByListConditionAsync(Expression<Func<T, bool>> predicate)
        {
            return await _context.Set<T>().Where(predicate).ToListAsync();
        }

        public async Task<SessionCost[]> GetSessionCostsAsync()
        {
            IQueryable<SessionCost> query = _context.SessionCosts;
            return await query.ToArrayAsync();
        }
        public async Task<_Booking[]> CountOnlineAsync()
        {
            IQueryable<_Booking> query = _context.Booking.Where(c => c.SessionCostId == 2);
            return await query.ToArrayAsync();
        }

        public async Task<_Booking[]> CountInPersonAsync()
        {
            IQueryable<_Booking> query = _context.Booking.Where(c => c.SessionCostId == 1);
            return await query.ToArrayAsync();
        }

    }
}
