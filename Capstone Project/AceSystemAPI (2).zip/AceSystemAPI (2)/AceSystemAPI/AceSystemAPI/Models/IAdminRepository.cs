﻿namespace AceSystemAPI.Models
{
    public interface IAdminRepository
    {
        void Add<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<Admin> GetAdminAsync(int adminId);
        Task<Admin[]> GetAllAdminsAsync();
        void Delete<T>(T entity) where T : class;

        Task<Admin> GetAdminProfileAsync(string adminEmail);
    }
}
