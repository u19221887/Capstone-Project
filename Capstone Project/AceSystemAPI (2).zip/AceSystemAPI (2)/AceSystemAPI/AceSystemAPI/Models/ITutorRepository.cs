﻿namespace AceSystemAPI.Models
{
    public interface ITutorRepository
    {
        void Add<T>(T entity) where T : class;
        void Delete<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<Tutors> GetTutorFromTutorApplicationAsync(int tutorId);
        Task<Tutors[]> GetAllTutorsAsync();

        Task<Tutors[]> GetFullTimeTutorsAsync();

        Task<Tutors[]> GetPartTimeTutorsAsync();

        Task<TutorType[]> GetTutorTypesAsync();

        Task<TutorApplication> GetTutorApplicationAsync(int tutorApplicationId);

        Task<Tutors> GetTutorProfileAsync(int tutorId);

        Task<Tutors> GetTutorProfileAsync(string tutorEmail);

        Task<Tutors> GetTutorById(int tutorId);

    }
}
