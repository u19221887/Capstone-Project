﻿using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations.Schema;

namespace AceSystemAPI.Models
{
    public class TutorGrade : BaseEntity
    {
        [ForeignKey(nameof(Tutor))]
        public int TutorId { get; set; }

        [ForeignKey(nameof(Grade))]
        public int GradeId { get; set; }

        //crate tutor and company availability objects

        public Tutors? Tutor { get; set; }
        public Grade? Grade { get; set; }
    }
}
