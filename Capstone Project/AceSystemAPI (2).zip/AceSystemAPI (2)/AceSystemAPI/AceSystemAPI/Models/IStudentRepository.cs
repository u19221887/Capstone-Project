﻿using AceSystemAPI.Models.Booking;

namespace AceSystemAPI.Models
{
    public interface IStudentRepository
    {

        void Add<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<Student> GetStudentAsync(int studentId);
        Task<Student[]> GetAllStudentsAsync();
        void Delete<T>(T entity) where T : class;
    }
}
