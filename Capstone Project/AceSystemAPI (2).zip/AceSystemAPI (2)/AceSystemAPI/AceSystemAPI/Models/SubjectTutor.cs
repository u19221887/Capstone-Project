﻿using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations.Schema;

namespace AceSystemAPI.Models
{
    public class SubjectTutor: BaseEntity
    {
        [ForeignKey(nameof(Subject))]
        public int SubjectId { get; set; }
        public Subject? Subject { get; set; }


        [ForeignKey(nameof(Tutor))]
        public int TutorId { get; set; }
        public Tutors? Tutor { get; set; }
    }
}
