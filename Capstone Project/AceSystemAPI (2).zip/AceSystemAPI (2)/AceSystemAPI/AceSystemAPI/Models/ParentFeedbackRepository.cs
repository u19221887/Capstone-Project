using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace AceSystemAPI.Models
{
  public class ParentFeedbackRepository : IParentFeedbackRepository
  {

    private readonly AppDbContext _appDbContext;

    public ParentFeedbackRepository(AppDbContext appDbContext)
    {
      _appDbContext = appDbContext;
    }

    public void Add<T>(T entity) where T : class
    {
      _appDbContext.Add(entity);
    }

    public async Task<bool> SaveChangesAsync()
    {
      return await _appDbContext.SaveChangesAsync() > 0;
    }

    public async Task<ParentFeedback[]> GetAllFeedbacksAsync()
    {
      IQueryable<ParentFeedback> query = _appDbContext.ParentFeedbacks;
      return await query.ToArrayAsync();
    }


  }
}
