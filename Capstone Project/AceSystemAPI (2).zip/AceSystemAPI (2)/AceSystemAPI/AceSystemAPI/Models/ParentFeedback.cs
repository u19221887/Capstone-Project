using Microsoft.AspNetCore.Mvc;
using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
  public class ParentFeedback
  {
    [Key]
    public int StudentId { get; set; }

    public string ParentName { get; set; } = string.Empty;
    public string ParentSurname { get; set; } = string.Empty;
    public string ParentFeedbackDescription { get; set; } = string.Empty;
    public string StudentName { get; set; } = string.Empty;
    public string StudentSurname { get; set; } = string.Empty;
    public string Subject { get; set; } = string.Empty;

  }
}
