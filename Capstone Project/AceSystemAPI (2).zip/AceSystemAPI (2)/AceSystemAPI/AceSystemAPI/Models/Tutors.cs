﻿using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class Tutors : BaseEntity
    {
        //[Key]
        //public int TutorId { get; set; }

        public string? Title { get; set; }
        public string TutorName { get; set; } = string.Empty;
        public string TutorSurname { get; set; } = string.Empty;
        public string TutorPhoneNumber { get; set; } = string.Empty;
        public string? TutorImage { get; set; } = string.Empty;
        public string? TutorIdNumber { get; set; } = string.Empty;
        public string TutorEmail { get; set; } = string.Empty;
        public string? TutorProvince { get; set; } = String.Empty;
        public string? TutorCity { get; set; } = String.Empty;
        public string? TutorAddress { get; set; } = String.Empty;
        public string? TutorPostalCode { get; set; }

        public DateTime Date { get; set; }

        //user id
        public string? userId { get; set; } = string.Empty;
        public int TutorApplicationId { get; set; }

        public int? TutorTypeId { get; set; }
        public TutorType TutorType { get; set; }

        public TutorApplication TutorApplication { get; set; }


    }
}
