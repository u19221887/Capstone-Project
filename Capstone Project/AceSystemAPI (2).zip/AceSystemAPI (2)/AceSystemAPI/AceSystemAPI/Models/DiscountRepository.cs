﻿using Microsoft.EntityFrameworkCore;
using AceSystemAPI.Models;


namespace AceSystemAPI.Models
{
    public class DiscountRepository : IDiscountRepository
    {

        private readonly AppDbContext _context;
        public DiscountRepository(AppDbContext context)
        {
            _context = context;
        }

        public void Add<T>(T entity) where T : class
        {
            _context.Add(entity);
        }

        public void Delete<T>(T entity) where T : class
        {
            _context.Remove(entity);
        }

        public async Task<Discount[]> GetAllDiscountsAsync()
        {
            IQueryable<Discount> query = _context.Discounts;
            return await query.ToArrayAsync();
        }

        public async Task<Discount> GetDiscountAsync(int discountId)
        {
            IQueryable<Discount> query = _context.Discounts.Where(c => c.discountId == discountId);
            return await query.FirstOrDefaultAsync();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync() > 0;
        }

        public async Task<Discount[]> GetActiveDiscountsAsync()
        {
            IQueryable<Discount> query = _context.Discounts.Where(c => c.DiscountStatusId == 1);
            return await query.ToArrayAsync();
        }

        public async Task<Discount[]> GetInactiveDiscountsAsync()
        {
            IQueryable<Discount> query = _context.Discounts.Where(c => c.DiscountStatusId == 2);
            return await query.ToArrayAsync();
        }

        public async Task<DiscountStatus[]> GetDiscountStatusesAsync()
        {
            IQueryable<DiscountStatus> query = _context.DiscountStatuses;
            return await query.ToArrayAsync();
        }
    }
}
