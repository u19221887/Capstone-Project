﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class TutorApplication
    {
        [Key]
        public int TutorApplicationId { get; set; }
        public string TutorApplicationName { get; set; }
        public string TutorApplicationSurname { get; set; }
        public string TutorApplicationEmail { get; set; }
        public string TutorApplicationPhoneNumber { get; set; }
        public string? TutorApplicationCV { get; set; }

        public string Grade { get; set; }
        public string Subject { get; set; }
        public int TutorApplicationStatusId { get; set; }

        public TutorApplicationStatus TutorApplicationStatus { get; set; }
        public virtual ICollection<Tutors> Tutors { get; set; }
    }
}
