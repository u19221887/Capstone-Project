﻿using AceSystemAPI.Models.Booking;
using Microsoft.EntityFrameworkCore;

namespace AceSystemAPI.Models
{
    public class StudentRepository: IStudentRepository
    {

        private readonly AppDbContext _appDbContext;

        public StudentRepository(AppDbContext appDbContext)
        {
            _appDbContext = appDbContext;
        }

        public void Delete<T>(T entity) where T : class
        {
            _appDbContext.Remove(entity);
        }

        public void Add<T>(T entity) where T : class
        {
            _appDbContext.Add(entity);
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _appDbContext.SaveChangesAsync() > 0;
        }

        public async Task<Student[]> GetAllStudentsAsync()
        {
            IQueryable<Student> query = _appDbContext.Students;
            return await query.ToArrayAsync();
        }

        public async Task<Student> GetStudentAsync(int studentId)
        {
            IQueryable<Student> query = _appDbContext.Students.Where(c => c.Id == studentId);

            return await query.FirstOrDefaultAsync();

        }
    }
}
