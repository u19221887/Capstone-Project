﻿using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class Grade: BaseEntity
    {
       

        public string gradeName { get; set; }
       

    }
}
