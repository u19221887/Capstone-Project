﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class DiscountStatus
    {
        [Key]
        public int DiscountStatusId { get; set; }
        public string DiscountStatusDescription { get; set; } = string.Empty;

        public virtual ICollection<Discount> Discounts { get; set; }
    }
}
