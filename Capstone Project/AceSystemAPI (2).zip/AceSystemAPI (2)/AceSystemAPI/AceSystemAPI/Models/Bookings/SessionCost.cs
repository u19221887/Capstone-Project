﻿using AceSystemAPI.Models.Repositories;

namespace AceSystemAPI.Models.Bookings
{
    public class SessionCost: BaseEntity
    {
        public double Amount { get; set; }
        public string Description { get; set; } = string.Empty;

    }
}
