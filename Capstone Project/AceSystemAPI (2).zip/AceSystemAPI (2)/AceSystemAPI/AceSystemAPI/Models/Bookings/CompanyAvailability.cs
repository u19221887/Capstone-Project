﻿using AceSystemAPI.Models.Repositories;

namespace AceSystemAPI.Models.Booking
{
    public class CompanyAvailability : BaseEntity
    {
        public DateTime startTime { get; set; }
        public DateTime endTime { get; set; }
    }
}
