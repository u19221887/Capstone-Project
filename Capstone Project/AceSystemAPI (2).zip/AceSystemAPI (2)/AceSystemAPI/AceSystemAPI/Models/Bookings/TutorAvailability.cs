﻿using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations.Schema;

namespace AceSystemAPI.Models.Booking
{
    public class TutorAvailability : BaseEntity
    {

        [ForeignKey(nameof(Tutor))]
        public int TutorId { get; set; }

        [ForeignKey(nameof(CompanyAvailability))]
        public int CompanyAvailabilityId { get; set; }

        public Boolean isTaken { get; set; }

        public DateTime Date { get; set; }

        //crate tutor and company availability objects

        public Tutors? Tutor { get; set; }
        public CompanyAvailability? CompanyAvailability { get; set; }

    }
}
