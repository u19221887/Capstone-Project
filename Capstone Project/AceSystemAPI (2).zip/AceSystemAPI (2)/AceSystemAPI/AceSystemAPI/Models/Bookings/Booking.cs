﻿using AceSystemAPI.Models.Bookings;
using AceSystemAPI.Models.Repositories;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace AceSystemAPI.Models.Booking
{
    public class _Booking : BaseEntity
    {


        public string userId { get; set; } = string.Empty;

        [ForeignKey(nameof(TutorAvailability))]
        public int TutorAvailabiltyId { get; set; }

        [ForeignKey(nameof(Student))]
        public int? StudentId { get; set; }

        public int SessionCostId { get; set; }

        public int TutorSubjectId { get; set; }

        public bool isPayed { get; set; } =  false;



        //create student and tutor objects

        public SubjectTutor? SubjectTutor { get; set; }
        public Student? Student { get; set; }
        public TutorAvailability? TutorAvailability { get; set; }

 
        public SessionCost? SessionCost { get; set; }

    }
}
