﻿using AceSystemAPI.Models.Repositories;
using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations.Schema;

namespace AceSystemAPI.Models.Booking
{
    public class Student : BaseEntity
    {

        public string userId { get; set; } = string.Empty;
        public string StudentName { get; set; } = string.Empty;
        public string StudentSurname { get; set; } = string.Empty;
        public string StudentPhoneNumber { get; set; } = string.Empty;
        public string StudentEmail { get; set; } = string.Empty;

        public int Grade { get; set; }
        public string DateOfBirth { get; set; } = string.Empty;
        public int StudentAge { get; set; }

        public string ParentTitle { get; set; } = string.Empty;
        public string ParentName { get; set; } = string.Empty;

        public string ParentSurname { get; set; } = string.Empty;
        public string ParentPhoneNumber { get; set; } = string.Empty;


        public string ParentEmail { get; set; } = string.Empty;

        public string StudentProvince { get; set; } = string.Empty;
        public string StudentCity { get; set; } = string.Empty;
        public string StudentAddress { get; set; } = string.Empty;
        public string StudentPostalCode { get; set; } = string.Empty;


        //public Booking Booking { get; set; }

        //public ICollection<StudentHomeworkLine> StudentHomeworkLine { get; set; }

        //public TutorHomeworkLine TutorHomeworkLine { get; set; }
        //public User User { get; set; }
    }
}
