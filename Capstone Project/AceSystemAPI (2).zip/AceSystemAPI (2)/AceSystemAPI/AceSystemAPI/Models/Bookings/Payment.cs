﻿using AceSystemAPI.Models.Repositories;

namespace AceSystemAPI.Models.Booking
{
    public class Payment : BaseEntity
    {
        public int Amount { get; set; }

        public DateTime Date { get; set; }

        public string Ref { get; set; }


        public string userId { get; set; }




    }
}
