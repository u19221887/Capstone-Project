﻿using AceSystemAPI.Models.Repositories;

namespace AceSystemAPI.Models
{
    public class BookingType: BaseEntity
    {
        public string Description { get; set; }
    }
}
