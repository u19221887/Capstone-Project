﻿using AceSystemAPI.Models.Repositories;
using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Models
{
    public class Subject : BaseEntity
    {
        //[Key]
        //public int Subject_ID { get; set; }
        public string SubjectName { get; set; } = String.Empty;
        public string SubjectDescription { get; set; } = String.Empty;
    }
}
