﻿namespace AceSystemAPI.Models
{
    public interface ISubjectRepository
    {
        void Add<T>(T entity) where T : class;
        Task<bool> SaveChangesAsync();
        Task<Subject> GetSubjectAsync(int subjectId);
        Task<Subject[]> GetAllSubjectsAsync();
        void Delete<T>(T entity) where T : class;
    }
}
