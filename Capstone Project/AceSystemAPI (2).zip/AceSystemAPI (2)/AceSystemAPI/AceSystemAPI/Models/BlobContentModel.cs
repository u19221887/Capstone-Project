namespace AceSystemAPI.Models
{
  public class BlobContentModel
  {
    public string FilePath { get; set; }
    public string FileName { get; set; }
  }
}
