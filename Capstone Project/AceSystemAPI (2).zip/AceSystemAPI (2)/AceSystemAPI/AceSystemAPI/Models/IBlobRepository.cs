namespace AceSystemAPI.Models
{
  public interface IBlobRepository
  {
    Task<BlobObject> GetBlobFile(string name);
    //Task<string> UploadBlobFile(string fileName, string filePath);
    void DeleteHomeworkFile(string name);
    Task<List<string>> ListBlobs();
    Task<string> UploadVideoFiles(string fileName, byte[] fileData);
    Task<string> GenerateBlobStreamLinkAsync(string fileName);
    Task<string> UploadHomeworkFile(string fileName, byte[] fileData);
  }
}
