namespace AceSystemAPI.Models
{
  public interface IRecordingsRepository
  {
    void Add<T>(T entity) where T : class;
    void Delete<T>(T entity) where T : class;

    Task<bool> SaveChangesAsync();

    Task<Recordings[]> GetAllRecordingsDetailsAsync();
    Task<Recordings> GetRecordingDetailsAsync(int Recordings_ID);


    Task<Recordings[]> GetSearchedRecordingsDetailsAsync(string enteredQuery);

    Task<BlobObject> GetBlobFile(string name);
    Task<BlobObject> GetABlobFile(string fileName);
    Task<string> UploadBlobFile(string fileName, byte[] fileData);

    void DeleteBlob(string name);
    Task<List<string>> ListBlobs();
  }
}
