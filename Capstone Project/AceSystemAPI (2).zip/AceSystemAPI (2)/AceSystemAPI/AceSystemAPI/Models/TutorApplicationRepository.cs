﻿using AceSystemAPI.ViewModels;
using Microsoft.EntityFrameworkCore;

namespace AceSystemAPI.Models
{
    public class TutorApplicationRepository : ITutorApplicationRepository
    {
        private readonly AppDbContext _context;

        public TutorApplicationRepository(AppDbContext context)
        {
            _context = context;
        }

        public void Add<T>(T entity) where T : class
        {
            _context.Add(entity);
        }

        public void Delete<T>(T entity) where T : class
        {
            _context.Remove(entity);
        }

        public async Task<TutorApplication[]> GetAcceptedTutorApplicationsAsync()
        {
            IQueryable<TutorApplication> query = _context.TutorApplications.Where(c => c.TutorApplicationStatusId == 2);
            return await query.ToArrayAsync();
        }


        public async Task<TutorApplication[]> GetAllTutorApplicationsAsync()
        {
            IQueryable<TutorApplication> query = _context.TutorApplications;
            return await query.ToArrayAsync();
        }

        public async Task<TutorApplication[]> GetPendingTutorApplicationsAsync()
        {
            IQueryable<TutorApplication> query = _context.TutorApplications.Where(c => c.TutorApplicationStatusId == 1);
            return await query.ToArrayAsync();
        }

        public async Task<TutorApplication> GetTutorApplicationAsync(int tutorApplicationId)
        {
            IQueryable<TutorApplication> query = _context.TutorApplications.Where(c => c.TutorApplicationId == tutorApplicationId);
            return await query.FirstOrDefaultAsync();
        }

        public async Task<TutorApplication> GetTutorApplicationAsyncByEmail(string tutorApplicationEmail)
        {
            IQueryable<TutorApplication> query = _context.TutorApplications.Where(c => c.TutorApplicationEmail == tutorApplicationEmail);
            return await query.FirstOrDefaultAsync();
        }

        public async Task<bool> SaveChangesAsync()
        {
            return await _context.SaveChangesAsync() > 0;
        }


    }
}
