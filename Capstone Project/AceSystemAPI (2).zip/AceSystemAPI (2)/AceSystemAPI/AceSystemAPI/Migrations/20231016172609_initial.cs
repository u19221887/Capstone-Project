﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AceSystemAPI.Migrations
{
    public partial class initial : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "Admins",
                columns: table => new
                {
                    AdminId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    adminName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    adminSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    adminPhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    adminEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    adminIdNumber = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Admins", x => x.AdminId);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoles",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoles", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUsers",
                columns: table => new
                {
                    Id = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    UserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedUserName = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    Email = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    NormalizedEmail = table.Column<string>(type: "nvarchar(256)", maxLength: 256, nullable: true),
                    EmailConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    PasswordHash = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    SecurityStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ConcurrencyStamp = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    PhoneNumberConfirmed = table.Column<bool>(type: "bit", nullable: false),
                    TwoFactorEnabled = table.Column<bool>(type: "bit", nullable: false),
                    LockoutEnd = table.Column<DateTimeOffset>(type: "datetimeoffset", nullable: true),
                    LockoutEnabled = table.Column<bool>(type: "bit", nullable: false),
                    AccessFailedCount = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUsers", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "AuditTrails",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Email = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Action = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AuditTrails", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "BookingType",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_BookingType", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "CompanyAvailability",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    startTime = table.Column<DateTime>(type: "datetime2", nullable: false),
                    endTime = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_CompanyAvailability", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "DiscountStatuses",
                columns: table => new
                {
                    DiscountStatusId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DiscountStatusDescription = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_DiscountStatuses", x => x.DiscountStatusId);
                });

            migrationBuilder.CreateTable(
                name: "Grades",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    gradeName = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Grades", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "ParentFeedbacks",
                columns: table => new
                {
                    StudentId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    ParentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentFeedbackDescription = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_ParentFeedbacks", x => x.StudentId);
                });

            migrationBuilder.CreateTable(
                name: "Payment",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Amount = table.Column<int>(type: "int", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    Ref = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    userId = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Payment", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "SessionCosts",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Amount = table.Column<double>(type: "float", nullable: false),
                    Description = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SessionCosts", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Students",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    userId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentPhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Grade = table.Column<int>(type: "int", nullable: false),
                    DateOfBirth = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentAge = table.Column<int>(type: "int", nullable: false),
                    ParentTitle = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentPhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    ParentEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentProvince = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentCity = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentAddress = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    StudentPostalCode = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Students", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "Subjects",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubjectName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    SubjectDescription = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Subjects", x => x.Id);
                });

            migrationBuilder.CreateTable(
                name: "TutorApplicationsStatuses",
                columns: table => new
                {
                    TutorApplicationStatusId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TutorApplicationDescription = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TutorApplicationsStatuses", x => x.TutorApplicationStatusId);
                });

            migrationBuilder.CreateTable(
                name: "TutorTypes",
                columns: table => new
                {
                    TutorTypeId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TutorTypeDescription = table.Column<string>(type: "nvarchar(max)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TutorTypes", x => x.TutorTypeId);
                });

            migrationBuilder.CreateTable(
                name: "AspNetRoleClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetRoleClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetRoleClaims_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserClaims",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ClaimType = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    ClaimValue = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserClaims", x => x.Id);
                    table.ForeignKey(
                        name: "FK_AspNetUserClaims_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserLogins",
                columns: table => new
                {
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderKey = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    ProviderDisplayName = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserLogins", x => new { x.LoginProvider, x.ProviderKey });
                    table.ForeignKey(
                        name: "FK_AspNetUserLogins_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserRoles",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    RoleId = table.Column<string>(type: "nvarchar(450)", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserRoles", x => new { x.UserId, x.RoleId });
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetRoles_RoleId",
                        column: x => x.RoleId,
                        principalTable: "AspNetRoles",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_AspNetUserRoles_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "AspNetUserTokens",
                columns: table => new
                {
                    UserId = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    LoginProvider = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Name = table.Column<string>(type: "nvarchar(450)", nullable: false),
                    Value = table.Column<string>(type: "nvarchar(max)", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_AspNetUserTokens", x => new { x.UserId, x.LoginProvider, x.Name });
                    table.ForeignKey(
                        name: "FK_AspNetUserTokens_AspNetUsers_UserId",
                        column: x => x.UserId,
                        principalTable: "AspNetUsers",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Discounts",
                columns: table => new
                {
                    discountId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    DiscountStartDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    DiscountEndDate = table.Column<DateTime>(type: "datetime2", nullable: false),
                    NumberOfSessions = table.Column<int>(type: "int", nullable: false),
                    DiscountCode = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    DiscountStatusId = table.Column<int>(type: "int", nullable: false),
                    DiscountPercentage = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Discounts", x => x.discountId);
                    table.ForeignKey(
                        name: "FK_Discounts_DiscountStatuses_DiscountStatusId",
                        column: x => x.DiscountStatusId,
                        principalTable: "DiscountStatuses",
                        principalColumn: "DiscountStatusId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TutorApplications",
                columns: table => new
                {
                    TutorApplicationId = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TutorApplicationName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorApplicationSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorApplicationEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorApplicationPhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorApplicationCV = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Grade = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Subject = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorApplicationStatusId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TutorApplications", x => x.TutorApplicationId);
                    table.ForeignKey(
                        name: "FK_TutorApplications_TutorApplicationsStatuses_TutorApplicationStatusId",
                        column: x => x.TutorApplicationStatusId,
                        principalTable: "TutorApplicationsStatuses",
                        principalColumn: "TutorApplicationStatusId",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Tutors",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Title = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorName = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorSurname = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorPhoneNumber = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorImage = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorIdNumber = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorEmail = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorProvince = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorCity = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorAddress = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorPostalCode = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false),
                    userId = table.Column<string>(type: "nvarchar(max)", nullable: true),
                    TutorApplicationId = table.Column<int>(type: "int", nullable: false),
                    TutorTypeId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Tutors", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Tutors_TutorApplications_TutorApplicationId",
                        column: x => x.TutorApplicationId,
                        principalTable: "TutorApplications",
                        principalColumn: "TutorApplicationId",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Tutors_TutorTypes_TutorTypeId",
                        column: x => x.TutorTypeId,
                        principalTable: "TutorTypes",
                        principalColumn: "TutorTypeId");
                });

            migrationBuilder.CreateTable(
                name: "SubjectTutor",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubjectId = table.Column<int>(type: "int", nullable: false),
                    TutorId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_SubjectTutor", x => x.Id);
                    table.ForeignKey(
                        name: "FK_SubjectTutor_Subjects_SubjectId",
                        column: x => x.SubjectId,
                        principalTable: "Subjects",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_SubjectTutor_Tutors_TutorId",
                        column: x => x.TutorId,
                        principalTable: "Tutors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TutorAvailability",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TutorId = table.Column<int>(type: "int", nullable: false),
                    CompanyAvailabilityId = table.Column<int>(type: "int", nullable: false),
                    isTaken = table.Column<bool>(type: "bit", nullable: false),
                    Date = table.Column<DateTime>(type: "datetime2", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TutorAvailability", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TutorAvailability_CompanyAvailability_CompanyAvailabilityId",
                        column: x => x.CompanyAvailabilityId,
                        principalTable: "CompanyAvailability",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TutorAvailability_Tutors_TutorId",
                        column: x => x.TutorId,
                        principalTable: "Tutors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TutorGrades",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    TutorId = table.Column<int>(type: "int", nullable: false),
                    GradeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TutorGrades", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TutorGrades_Grades_GradeId",
                        column: x => x.GradeId,
                        principalTable: "Grades",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TutorGrades_Tutors_TutorId",
                        column: x => x.TutorId,
                        principalTable: "Tutors",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Booking",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    userId = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    TutorAvailabiltyId = table.Column<int>(type: "int", nullable: false),
                    StudentId = table.Column<int>(type: "int", nullable: true),
                    SessionCostId = table.Column<int>(type: "int", nullable: false),
                    TutorSubjectId = table.Column<int>(type: "int", nullable: false),
                    isPayed = table.Column<bool>(type: "bit", nullable: false),
                    SubjectTutorId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Booking", x => x.Id);
                    table.ForeignKey(
                        name: "FK_Booking_SessionCosts_SessionCostId",
                        column: x => x.SessionCostId,
                        principalTable: "SessionCosts",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_Booking_Students_StudentId",
                        column: x => x.StudentId,
                        principalTable: "Students",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Booking_SubjectTutor_SubjectTutorId",
                        column: x => x.SubjectTutorId,
                        principalTable: "SubjectTutor",
                        principalColumn: "Id");
                    table.ForeignKey(
                        name: "FK_Booking_TutorAvailability_TutorAvailabiltyId",
                        column: x => x.TutorAvailabiltyId,
                        principalTable: "TutorAvailability",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "TutorSubjects",
                columns: table => new
                {
                    Id = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    SubjectId = table.Column<int>(type: "int", nullable: false),
                    TutorGradeId = table.Column<int>(type: "int", nullable: false)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_TutorSubjects", x => x.Id);
                    table.ForeignKey(
                        name: "FK_TutorSubjects_Subjects_SubjectId",
                        column: x => x.SubjectId,
                        principalTable: "Subjects",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                    table.ForeignKey(
                        name: "FK_TutorSubjects_TutorGrades_TutorGradeId",
                        column: x => x.TutorGradeId,
                        principalTable: "TutorGrades",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Cascade);
                });

            migrationBuilder.CreateTable(
                name: "Recordings",
                columns: table => new
                {
                    Recordings_ID = table.Column<int>(type: "int", nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    Name = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    Date = table.Column<string>(type: "nvarchar(12)", maxLength: 12, nullable: false),
                    Description = table.Column<string>(type: "nvarchar(100)", maxLength: 100, nullable: false),
                    FileName = table.Column<string>(type: "nvarchar(255)", maxLength: 255, nullable: false),
                    FilePath = table.Column<string>(type: "nvarchar(max)", nullable: false),
                    Subject_Id = table.Column<int>(type: "int", nullable: true),
                    SubjectId = table.Column<int>(type: "int", nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_Recordings", x => x.Recordings_ID);
                    table.ForeignKey(
                        name: "FK_Recordings_TutorSubjects_SubjectId",
                        column: x => x.SubjectId,
                        principalTable: "TutorSubjects",
                        principalColumn: "Id");
                });

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "236fdbcd-94ec-40a8-b197-97c6d62da3b8", "1", "Admin", "Admin" },
                    { "67225ee2-4ade-43f1-baca-042e78045e39", "2", "Student", "Student" },
                    { "80367bfd-8717-406c-a103-a7b568150f6d", "3", "Tutor", "Tutor" }
                });

            migrationBuilder.InsertData(
                table: "BookingType",
                columns: new[] { "Id", "Description" },
                values: new object[,]
                {
                    { 1, "In-Person" },
                    { 2, "Online" }
                });

            migrationBuilder.InsertData(
                table: "CompanyAvailability",
                columns: new[] { "Id", "endTime", "startTime" },
                values: new object[,]
                {
                    { -12, new DateTime(2023, 10, 16, 20, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 19, 0, 0, 0, DateTimeKind.Local) },
                    { -11, new DateTime(2023, 10, 16, 19, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 18, 0, 0, 0, DateTimeKind.Local) },
                    { -10, new DateTime(2023, 10, 16, 18, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 17, 0, 0, 0, DateTimeKind.Local) },
                    { -9, new DateTime(2023, 10, 16, 17, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 16, 0, 0, 0, DateTimeKind.Local) },
                    { -8, new DateTime(2023, 10, 16, 16, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 15, 0, 0, 0, DateTimeKind.Local) },
                    { -7, new DateTime(2023, 10, 16, 15, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 14, 0, 0, 0, DateTimeKind.Local) },
                    { -6, new DateTime(2023, 10, 16, 14, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 13, 0, 0, 0, DateTimeKind.Local) },
                    { -5, new DateTime(2023, 10, 16, 13, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 12, 0, 0, 0, DateTimeKind.Local) },
                    { -4, new DateTime(2023, 10, 16, 12, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 11, 0, 0, 0, DateTimeKind.Local) },
                    { -3, new DateTime(2023, 10, 16, 11, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 10, 0, 0, 0, DateTimeKind.Local) },
                    { -2, new DateTime(2023, 10, 16, 10, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 9, 0, 0, 0, DateTimeKind.Local) },
                    { -1, new DateTime(2023, 10, 16, 9, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 10, 16, 8, 0, 0, 0, DateTimeKind.Local) }
                });

            migrationBuilder.InsertData(
                table: "DiscountStatuses",
                columns: new[] { "DiscountStatusId", "DiscountStatusDescription" },
                values: new object[,]
                {
                    { 1, "Active" },
                    { 2, "Inactive" }
                });

            migrationBuilder.InsertData(
                table: "Grades",
                columns: new[] { "Id", "gradeName" },
                values: new object[,]
                {
                    { 1, "Grade 4" },
                    { 2, "Grade 5" },
                    { 3, "Grade 6" },
                    { 4, "Grade 7" },
                    { 5, "Grade 8" },
                    { 6, "Grade 9" },
                    { 7, "Grade 10" },
                    { 8, "Grade 11" },
                    { 9, "Grade 12" }
                });

            migrationBuilder.InsertData(
                table: "SessionCosts",
                columns: new[] { "Id", "Amount", "Description" },
                values: new object[,]
                {
                    { 1, 250.0, "InPerson" },
                    { 2, 150.0, "Online" }
                });

            migrationBuilder.InsertData(
                table: "TutorApplicationsStatuses",
                columns: new[] { "TutorApplicationStatusId", "TutorApplicationDescription" },
                values: new object[,]
                {
                    { 1, "Pending" },
                    { 2, "Accepted" },
                    { 3, "Rejected" }
                });

            migrationBuilder.InsertData(
                table: "TutorTypes",
                columns: new[] { "TutorTypeId", "TutorTypeDescription" },
                values: new object[,]
                {
                    { 1, "Full-time" },
                    { 2, "Part-time" }
                });

            migrationBuilder.CreateIndex(
                name: "IX_AspNetRoleClaims_RoleId",
                table: "AspNetRoleClaims",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "RoleNameIndex",
                table: "AspNetRoles",
                column: "NormalizedName",
                unique: true,
                filter: "[NormalizedName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserClaims_UserId",
                table: "AspNetUserClaims",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserLogins_UserId",
                table: "AspNetUserLogins",
                column: "UserId");

            migrationBuilder.CreateIndex(
                name: "IX_AspNetUserRoles_RoleId",
                table: "AspNetUserRoles",
                column: "RoleId");

            migrationBuilder.CreateIndex(
                name: "EmailIndex",
                table: "AspNetUsers",
                column: "NormalizedEmail");

            migrationBuilder.CreateIndex(
                name: "UserNameIndex",
                table: "AspNetUsers",
                column: "NormalizedUserName",
                unique: true,
                filter: "[NormalizedUserName] IS NOT NULL");

            migrationBuilder.CreateIndex(
                name: "IX_Booking_SessionCostId",
                table: "Booking",
                column: "SessionCostId");

            migrationBuilder.CreateIndex(
                name: "IX_Booking_StudentId",
                table: "Booking",
                column: "StudentId");

            migrationBuilder.CreateIndex(
                name: "IX_Booking_SubjectTutorId",
                table: "Booking",
                column: "SubjectTutorId");

            migrationBuilder.CreateIndex(
                name: "IX_Booking_TutorAvailabiltyId",
                table: "Booking",
                column: "TutorAvailabiltyId");

            migrationBuilder.CreateIndex(
                name: "IX_Discounts_DiscountStatusId",
                table: "Discounts",
                column: "DiscountStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_Recordings_SubjectId",
                table: "Recordings",
                column: "SubjectId");

            migrationBuilder.CreateIndex(
                name: "IX_SubjectTutor_SubjectId",
                table: "SubjectTutor",
                column: "SubjectId");

            migrationBuilder.CreateIndex(
                name: "IX_SubjectTutor_TutorId",
                table: "SubjectTutor",
                column: "TutorId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorApplications_TutorApplicationStatusId",
                table: "TutorApplications",
                column: "TutorApplicationStatusId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorAvailability_CompanyAvailabilityId",
                table: "TutorAvailability",
                column: "CompanyAvailabilityId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorAvailability_TutorId",
                table: "TutorAvailability",
                column: "TutorId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorGrades_GradeId",
                table: "TutorGrades",
                column: "GradeId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorGrades_TutorId",
                table: "TutorGrades",
                column: "TutorId");

            migrationBuilder.CreateIndex(
                name: "IX_Tutors_TutorApplicationId",
                table: "Tutors",
                column: "TutorApplicationId");

            migrationBuilder.CreateIndex(
                name: "IX_Tutors_TutorTypeId",
                table: "Tutors",
                column: "TutorTypeId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorSubjects_SubjectId",
                table: "TutorSubjects",
                column: "SubjectId");

            migrationBuilder.CreateIndex(
                name: "IX_TutorSubjects_TutorGradeId",
                table: "TutorSubjects",
                column: "TutorGradeId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "Admins");

            migrationBuilder.DropTable(
                name: "AspNetRoleClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserClaims");

            migrationBuilder.DropTable(
                name: "AspNetUserLogins");

            migrationBuilder.DropTable(
                name: "AspNetUserRoles");

            migrationBuilder.DropTable(
                name: "AspNetUserTokens");

            migrationBuilder.DropTable(
                name: "AuditTrails");

            migrationBuilder.DropTable(
                name: "Booking");

            migrationBuilder.DropTable(
                name: "BookingType");

            migrationBuilder.DropTable(
                name: "Discounts");

            migrationBuilder.DropTable(
                name: "ParentFeedbacks");

            migrationBuilder.DropTable(
                name: "Payment");

            migrationBuilder.DropTable(
                name: "Recordings");

            migrationBuilder.DropTable(
                name: "AspNetRoles");

            migrationBuilder.DropTable(
                name: "AspNetUsers");

            migrationBuilder.DropTable(
                name: "SessionCosts");

            migrationBuilder.DropTable(
                name: "Students");

            migrationBuilder.DropTable(
                name: "SubjectTutor");

            migrationBuilder.DropTable(
                name: "TutorAvailability");

            migrationBuilder.DropTable(
                name: "DiscountStatuses");

            migrationBuilder.DropTable(
                name: "TutorSubjects");

            migrationBuilder.DropTable(
                name: "CompanyAvailability");

            migrationBuilder.DropTable(
                name: "Subjects");

            migrationBuilder.DropTable(
                name: "TutorGrades");

            migrationBuilder.DropTable(
                name: "Grades");

            migrationBuilder.DropTable(
                name: "Tutors");

            migrationBuilder.DropTable(
                name: "TutorApplications");

            migrationBuilder.DropTable(
                name: "TutorTypes");

            migrationBuilder.DropTable(
                name: "TutorApplicationsStatuses");
        }
    }
}
