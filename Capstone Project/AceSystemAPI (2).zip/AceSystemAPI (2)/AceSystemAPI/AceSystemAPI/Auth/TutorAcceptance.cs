﻿using System.ComponentModel.DataAnnotations;

namespace AceSystemAPI.Auth
{
    public class TutorAcceptance
    {


        [Required]
        [EmailAddress]
        public string Email { get; set; }
    }
}
