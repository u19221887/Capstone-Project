﻿namespace AceSystemAPI.Auth
{
    public static class UserRoles
    {

        public const string Student = "Student";
        public const string Admin = "Admin";
        public const string Tutor = "Tutor";
    }
}
