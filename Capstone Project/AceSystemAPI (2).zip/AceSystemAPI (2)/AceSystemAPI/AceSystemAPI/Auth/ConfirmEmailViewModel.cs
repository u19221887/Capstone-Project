﻿namespace AceSystemAPI.Auth
{
    public class ConfirmEmailViewModel
    {

        public string? token { get; set; }

        public string? userId { get; set; }
    }
}
