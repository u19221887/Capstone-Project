﻿namespace AceSystemAPI.ViewModels
{
    public class DiscountViewModel
    {
        public int DiscountId { get; set; }
        public DateTime DiscountStartDate { get; set; }
        public DateTime DiscountEndDate { get; set; }
        public int NumberOfSessions { get; set; }
        public string DiscountCode { get; set; } = string.Empty;

        public int DiscountPercentage { get; set; }

        public int DiscountStatus { get; set; }
    }
}
