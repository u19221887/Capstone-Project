﻿namespace AceSystemAPI.ViewModels
{
    public class TutorViewModel
    {
        public string Title { get; set; }
        public string TutorName { get; set; } = string.Empty;
        public string TutorSurname { get; set; } = string.Empty;
        public string TutorPhoneNumber { get; set; } = string.Empty;
        public string TutorImage { get; set; } = string.Empty;
        public string TutorIdNumber { get; set; } = string.Empty;
        public string TutorEmail { get; set; } = string.Empty;
        public string TutorProvince { get; set; } = String.Empty;
        public string TutorCity { get; set; } = String.Empty;
        public string TutorAddress { get; set; } = String.Empty;
        public string TutorPostalCode { get; set; }

        public int TutorType { get; set; }
        public int TutorApplicationId { get; set; }
    }
}
