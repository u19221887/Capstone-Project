﻿namespace AceSystemAPI.ViewModels
{
    public class TutorSubjectListViewModel
    {
        public string TutorName { get; set; } = String.Empty;
        public string Grade { get; set; } = String.Empty;
        public string Subjects { get; set; } = String.Empty;
    }
}
