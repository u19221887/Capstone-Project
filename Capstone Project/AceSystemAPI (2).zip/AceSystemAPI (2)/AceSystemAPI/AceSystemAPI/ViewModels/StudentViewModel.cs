﻿namespace AceSystemBackend.ViewModels
{
    public class StudentViewModel
    {

        public string studentName { get; set; } = String.Empty;
        public string studentSurname { get; set; } = String.Empty;
        public string studentPhoneNumber { get; set; } = String.Empty;
        public string studentEmail { get; set; } = String.Empty;

        public int grade { get; set; } 
        //public string subject { get; set; } = String.Empty;
        public string dateOfBirth { get; set; } = String.Empty;
        public int studentAge { get; set; }
        //public string studentImage { get; set; } = String.Empty;

        public string parentTitle { get; set; } = String.Empty;
        public string parentName { get; set; } = String.Empty;

        public string parentSurname { get; set; } = String.Empty;
        public string parentPhoneNumber { get; set; } = String.Empty;


        public string parentEmail { get; set; } = String.Empty;

        public string studentProvince { get; set; } = String.Empty;
        public string studentCity { get; set; } = String.Empty;
        public string studentAddress { get; set; } = String.Empty;
        public string studentPostalCode { get; set; } = String.Empty;

    }
}
