﻿namespace AceSystemAPI.ViewModels
{
    public class SubjectViewModel
    {
        public int subTutorId { get; set; }

        public string SubjectName { get; set; } = string.Empty;

        public string SubjectDescription { get; set; } = string.Empty;

    }
}