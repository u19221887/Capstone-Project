﻿namespace AceSystemAPI.ViewModels
{
    public class AdminViewModel
    {
        public string adminName { get; set; } = String.Empty;
        public string adminSurname { get; set; } = String.Empty;
        public string adminPhoneNumber { get; set; } = String.Empty;
        public string adminEmail { get; set; } = String.Empty;

        public string adminIdNumber { get; set; } = String.Empty;
    }
}
