﻿using AceSystemAPI.Models;

namespace AceSystemAPI.ViewModels
{
    public class TutorApplicationViewModel
    {
        public int TutorApplicationId;
        public string TutorApplicationName { get; set; }
        public string TutorApplicationSurname { get; set; }
        public string TutorApplicationEmail { get; set; }
        public string TutorApplicationPhoneNumber { get; set; }
        public string? TutorApplicationCV { get; set; }

        public int TutorApplicationStatus { get; set; }

    }
}