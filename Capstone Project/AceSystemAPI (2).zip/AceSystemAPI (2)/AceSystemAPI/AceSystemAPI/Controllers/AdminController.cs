﻿using Microsoft.AspNetCore.Mvc;
using AceSystemAPI.Models;
using AceSystemBackend.ViewModels;
using AceSystemAPI.ViewModels;
using Microsoft.AspNetCore.Identity;
using AceSystemAPI.Auth;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : Controller
    {
        private readonly IAdminRepository _appDbContext;
        private readonly ILogger<AdminController> _logger;
        private readonly UserManager<IdentityUser> _userManager;
        public AdminController(IAdminRepository appDbContext, ILogger<AdminController> logger, UserManager<IdentityUser> userManager)
        {
            _appDbContext = appDbContext;
            _logger = logger;
            _userManager = userManager;
        }

        //Get all admins

        [HttpGet]
        [Route("GetAllAdmins")]
        public async Task<IActionResult> GetAllAdmins()
        {
            try
            {
                var results = await _appDbContext.GetAllAdminsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        //Get admin

        [HttpGet]
        [Route("GetAdmin/{adminId}")]
        public async Task<IActionResult> GetAdminAsync(int adminId)
        {
            try
            {
                var result = await _appDbContext.GetAdminAsync(adminId);

                if (result == null) return NotFound("Subject does not exist. You need to create it first");

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support");
            }
            //try
            //{
            //    var admin = await _appDbContext.GetAdminAsync(adminId);

            //    if (admin == null)
            //    {
            //        return NotFound(); // Return 404 Not Found if student not found
            //    }

            //    var result = new
            //    {
            //        admin.AdminId,
            //        admin.adminName,
            //        admin.adminSurname,
            //        admin.adminPhoneNumber,
            //        admin.adminEmail,
            //        admin.adminIdNumber,
            //    };

            //    return Ok(result);
            //}
            //catch (Exception)
            //{
            //    return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            //}
        }

        //Add admin

        [HttpPost]
        [Route("AddAdmin")]
        public async Task<IActionResult> AddAdminAsync(AdminViewModel admin)
        {
            try
            {
                var userExists = await _userManager.FindByEmailAsync(admin.adminEmail);
                if (userExists == null)
                {
                    _logger.LogInformation("User is not registered - Email does not exists: {Email}", admin.adminEmail);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
                }


                Admin newAdmin = new Admin
                {
                    adminName = admin.adminName,
                    adminSurname = admin.adminSurname,
                    adminPhoneNumber = admin.adminPhoneNumber,
                    adminEmail = admin.adminEmail,
                    adminIdNumber = admin.adminIdNumber
                };
                _appDbContext.Add(newAdmin);
                await _appDbContext.SaveChangesAsync();

                return Ok(newAdmin);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }


                _logger.LogError(ex, errorMessage);


                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
        }

        //Edit admin

        [HttpPut]
        [Route("EditAdmin/{adminId}")]
        public async Task<ActionResult<AdminViewModel>> EditAdmin(int adminId, AdminViewModel adminModel)
        {
            try
            {
                var existingAdmin = await _appDbContext.GetAdminAsync(adminId);
                if (existingAdmin == null) return NotFound($"The admin does not exist");

                var userExists = await _userManager.FindByEmailAsync(existingAdmin.adminEmail);
                if (userExists == null)
                {
                    _logger.LogInformation("User is not registered - Email does not exists: {Email}", existingAdmin.adminEmail);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
                }

                existingAdmin.adminName = adminModel.adminName;
                existingAdmin.adminSurname = adminModel.adminSurname;
                existingAdmin.adminPhoneNumber = adminModel.adminPhoneNumber;
                existingAdmin.adminEmail = adminModel.adminEmail;

                userExists.Email = adminModel.adminEmail;
                userExists.UserName = adminModel.adminEmail;
                userExists.NormalizedUserName = adminModel.adminEmail.ToUpper();
                userExists.NormalizedEmail = adminModel.adminEmail.ToUpper();

                existingAdmin.adminIdNumber = adminModel.adminIdNumber;

                if (await _appDbContext.SaveChangesAsync())
                {
                    return Ok(existingAdmin);
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpDelete]
        [Route("DeleteAdmin/{adminId}")]
        public async Task<IActionResult> DeleteAdmin(int adminId)
        {
            try
            {
                var existingadmin = await _appDbContext.GetAdminAsync(adminId);

                if (existingadmin == null) return NotFound($"The admin does not exist");

                _appDbContext.Delete(existingadmin);

                if (await _appDbContext.SaveChangesAsync()) return Ok(existingadmin);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("GetAdminProfile/{adminEmail}")]
        public async Task<IActionResult> GetAdminProfile(string adminEmail)
        {
            try
            {
                var admin = await _appDbContext.GetAdminProfileAsync(adminEmail);
                if (admin == null)
                {
                    return NotFound();
                }

                var result = new
                {
                    admin.AdminId,
                    admin.adminName,
                    admin.adminSurname,
                    admin.adminEmail,
                    admin.adminPhoneNumber,
                    admin.adminIdNumber

                };

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }
    }
}
