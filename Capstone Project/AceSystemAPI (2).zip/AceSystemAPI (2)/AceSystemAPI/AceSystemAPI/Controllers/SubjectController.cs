﻿using AceSystemAPI.Models;
using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Interfaces;
using AceSystemAPI.Models.ViewModels;
using AceSystemAPI.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using System.Diagnostics;
using System.Linq;
using System.Security.Claims;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SubjectController : ControllerBase
    {
        private readonly ISubjectRepository _appDbContext;
        private readonly ILogger<SubjectController> _logger;
        private readonly IRepository<Grade> _grade;
        private readonly IRepository<TutorAvailability> _tutavi;
        private readonly IRepository<Tutors> _tutorRepository;
        private readonly IRepository<CompanyAvailability> _db;
        //subjectTutorRepo

        private readonly IRepository<SubjectTutor> _subTutorRepository;

        private readonly IRepository<TutorSubject> _tutorSubjectRepository;

        private readonly IRepository<TutorGrade> _tutorGrades;



        public SubjectController(ISubjectRepository appDbContext, ILogger<SubjectController> logger, IRepository<SubjectTutor> subTutorRepository, IRepository<TutorSubject> tutorSubjectRepository, IRepository<TutorGrade> tutorsGrades, IRepository<Tutors> tutorrepository, IRepository<Grade> grade, IRepository<CompanyAvailability> db, IRepository<TutorAvailability> tutavi)
        {
            _appDbContext = appDbContext;
            _logger = logger;
            _subTutorRepository = subTutorRepository;
            _tutorSubjectRepository = tutorSubjectRepository;
            _tutorGrades = tutorsGrades;
            _tutorRepository = tutorrepository;
            _db = db;
            _grade = grade;
            _tutavi = tutavi;

        }


        //Get all subject

        [HttpGet]
        [Route("GetAllSubjects")]
        public async Task<IActionResult> GetAllSubejcts()
        {
            try
            {
                var results = await _appDbContext.GetAllSubjectsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        //Get subject
        //[HttpGet]
        //[Route("GetSubject/{subjectId}")]
        //public async Task<IActionResult> GetSubjectAsync(int subjectId)
        //{
        //    try
        //    {
        //        var subject = await _appDbContext.GetSubjectAsync(subjectId);

        //        if (subject == null)
        //        {
        //            return NotFound(); // Return 404 Not Found if student not found
        //        }

        //        var result = new
        //        {
        //            subject.Id,
        //            subject.SubjectName,
        //            subject.SubjectDescription
        //        };

        //        return Ok(result);
        //    }
        //    catch (Exception)
        //    {
        //        return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
        //    }
        //}


        //Add subject

        [HttpPost]
        [Route("AddSubject")]
        public async Task<IActionResult> AddSSubjectAsync([FromBody] SubjectViewModel subject)
        {
            try
            {



                Subject newSubject = new Subject
                {
                    SubjectName = subject.SubjectName,
                    SubjectDescription = subject.SubjectDescription
                };
                _appDbContext.Add(newSubject);
                await _appDbContext.SaveChangesAsync();

                return Ok(newSubject);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }


                _logger.LogError(ex, errorMessage);


                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
        }


        //[HttpPut]
        //[Route("EditSubject/{subjectId}")]
        //public async Task<ActionResult<SubjectViewModel>> EditSubject(int subjectId, SubjectViewModel subjectModel)
        //{
        //    try
        //    {
        //        var existingSubject = await _appDbContext.GetSubjectAsync(subjectId);
        //        if (existingSubject == null) return NotFound($"The subject does not exist");

        //        existingSubject.SubjectName = subjectModel.subjectName;
        //        existingSubject.SubjectDescription = subjectModel.subjectDescription;

        //        if (await _appDbContext.SaveChangesAsync())
        //        {
        //            return Ok(existingSubject);
        //        }
        //    }
        //    catch (Exception)
        //    {
        //        return StatusCode(500, "Internal Server Error. Please contact support.");
        //    }
        //    return BadRequest("Your request is invalid.");
        //}



        //link subject to tutor
        [HttpPost]
        [Route("LinkSubjectToTutor")]

        [Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<IActionResult> LinkSubjectToTutorAsync([FromBody] SubjectTutorViewModel subjectTutor)
        {
            try
            {
                //GET TUTOR
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
                var user = _tutorRepository.GetAllAsync().Result.Where(x => x.userId == userId).FirstOrDefault();



                //check if subject tutor already exist use subjectId and tutorId use get not getbyid
                var existingSubjectTutor = await _subTutorRepository.FindByListConditionAsync(x => x.SubjectId == subjectTutor.SubjectId && x.TutorId == user.Id);


                if (existingSubjectTutor.Count() > 0) return BadRequest($"The subject tutor already exist");

                SubjectTutor newSubjectTutor = new SubjectTutor
                {
                    SubjectId = subjectTutor.SubjectId,
                    TutorId = user.Id
                };
                _appDbContext.Add(newSubjectTutor);
                await _appDbContext.SaveChangesAsync();

                return Ok(newSubjectTutor);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }

                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
        }

        //unlink subject to tutor on subjecttutor
        [HttpDelete]
        [Route("UnlinkSubjectToTutor/{subjectTutorId}")]
        public async Task<IActionResult> UnlinkSubjectToTutorAsync(int subjectTutorId)
        {
            try
            {
                var existingSubjectTutor = await _subTutorRepository.GetByIdAsync(subjectTutorId);
                if (existingSubjectTutor == null) return NotFound($"The subject tutor does not exist");

                _subTutorRepository.Remove(existingSubjectTutor);

                if (await _subTutorRepository.SaveChangesAsync())
                {
                    return Ok(existingSubjectTutor);
                }

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet("GetSubjectsById/{id}")]
        public async Task<IActionResult> GetSubjectsById(int id)
        {
            var s = await _appDbContext.GetSubjectAsync(id);

            return Ok(s);
        }

        [HttpGet("GetSubjectsforTutorThatTheyCanAdd/{id}")]
        public async Task<IActionResult> GetAllSubjectsforTutorThatTheyCanAdd(int id)
        {
            try
            {
                var myTutorSubjects = await _tutorSubjectRepository.GetAllAsync();
                var mySubjects = await _appDbContext.GetAllSubjectsAsync();


                var subjectList = new List<int>();
                var subjectNum = new List<int>();
                var myTutorSubjectsToReturn = new List<int>();

                var returnedSubjectList = new List<Subject>();

                //return Ok(myTutorSubjects);
                //return Ok(mySubjects);


                foreach (var tutorSubject in myTutorSubjects)
                {
                    if (tutorSubject.TutorGradeId == id)
                    {
                        subjectNum.Add(tutorSubject.SubjectId);

                    }
                }

                foreach (var subject in mySubjects)
                {
                    subjectList.Add(subject.Id);
                    myTutorSubjectsToReturn.Add(subject.Id);
                }


                foreach (var subjectId in subjectList)
                {
                    foreach (var subject in subjectNum)
                    {
                        if (subjectId == subject)
                        {
                            myTutorSubjectsToReturn.Remove(subjectId);
                        }


                    }

                }

                foreach (var subjectName in myTutorSubjectsToReturn)
                {
                    foreach (var subjectId in mySubjects)
                    {
                        if (subjectId.Id == subjectName)
                        {
                            var subjectObj = new Subject();
                            subjectObj.Id = subjectId.Id;
                            subjectObj.SubjectName = subjectId.SubjectName;




                            returnedSubjectList.Add(subjectObj);
                        }
                    }

                }
                return Ok(returnedSubjectList);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPost("AddTutorGradeSubjects")]

        public async Task<ActionResult> AddTutorGradeSubjects([FromBody] TutorGradeSubjectViewModel tutorGradeSubjectVM)
        {
            try
            {
                if (tutorGradeSubjectVM == null)
                {
                    return BadRequest("Tutor Grade Subject object is null");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest("Invalid model object");
                }
                var tutorsubjects = new List<TutorSubject>();

                foreach (var subject in tutorGradeSubjectVM.Subjects)
                {
                    var tutorSubjectToAdd = new TutorSubject()
                    {
                        TutorGradeId = tutorGradeSubjectVM.TutorGradeId,
                        SubjectId = subject




                    };
                    _tutorSubjectRepository.Add(tutorSubjectToAdd);
                }
                _tutorSubjectRepository.SaveChanges();

                return Ok();



            }
            catch (Exception c)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetAllSubjectsforTutor/{id}")]
        public async Task<IActionResult> getAllSubjectsforTutor(int id)
        {
            try
            {
                var myTutorSubjects = await _tutorSubjectRepository.GetAllAsync();
                var mySubjects = await _appDbContext.GetAllSubjectsAsync();

                var subjectList = new List<int>();
                var subjectNum = new List<int>();
                var myTutorSubjectsToReturn = new List<int>();

                var returnedSubjectList = new List<Subject>();
                var returnedTutorGradeSubjectList = new List<TutorSubject>();

                foreach (var tutorSubject in myTutorSubjects)
                {
                    if (tutorSubject.TutorGradeId == id)
                    {
                        subjectNum.Add(tutorSubject.SubjectId);
                    }
                }

                foreach (var subject in mySubjects)
                {
                    subjectList.Add(subject.Id);

                }


                foreach (var subjectId in subjectList)
                {
                    foreach (var subject in subjectNum)
                    {
                        if (subjectId == subject)
                        {
                            myTutorSubjectsToReturn.Add(subjectId);
                        }


                    }

                }

                foreach (var subjectName in myTutorSubjectsToReturn)
                {
                    foreach (var subjectId in mySubjects)
                    {
                        if (subjectId.Id == subjectName)
                        {
                            var subObj = new Subject();
                            subObj.Id = subjectId.Id;
                            subObj.SubjectName = subjectId.SubjectName;



                            returnedSubjectList.Add(subObj);

                        }
                    }

                }
                return Ok(returnedSubjectList);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetTutorGradeforSubject/{gradeid}")]
        public async Task<IActionResult> GetTutorGradeforSubject(int gradeid)
        {
            try
            {
                var myTutorGrades = await _tutorGrades.GetAllAsync();
                var smallTutorGrades = new List<TutorGrade>();

                var myTutorSubjects = await _tutorSubjectRepository.GetAllAsync();
                var smallerList = new List<TutorSubject>();
                var val = 0;

                var tutList = new List<TutorSubject>();

                foreach (var tutGrade in myTutorGrades)
                {
                    var x = new TutorGrade();
                    x.TutorId = tutGrade.TutorId;
                    x.GradeId = tutGrade.GradeId;
                    x.Id = tutGrade.Id;

                    smallTutorGrades.Add(x);
                }

                foreach (var tutorSubject in myTutorSubjects)
                {
                    var t = new TutorSubject();
                    t.Id = tutorSubject.Id;
                    t.TutorGradeId = tutorSubject.TutorGradeId;
                    t.SubjectId = tutorSubject.SubjectId;

                    smallerList.Add(t);
                }

                foreach (var tutorGrade in smallTutorGrades)
                {
                    if (tutorGrade.Id == gradeid)
                    {
                        val = tutorGrade.Id;
                    }
                }

                foreach (var tutorSubject in smallerList)
                {
                    if (tutorSubject.TutorGradeId == val)
                    {
                        tutList.Add(tutorSubject);
                    }
                }

                return Ok(tutList);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }


        }

        [HttpDelete]
        [Route("DeleteTutorGradeSubject/{tutorgradeId, subjectId}")]
        public async Task<IActionResult> DeleteTutorGradeAsync(int tutorgradeId, int subjectId)
        {
            try
            {
                //var existingTutor = await _tutors.GetByIdAsync(tutorId);

                var TutorGradeSubjectList = await _tutorSubjectRepository.GetAllAsync();
                var smallerList = new List<TutorSubject>();

                var removedList = new List<TutorSubject>();

                var UpdatedList = await _tutorSubjectRepository.GetAllAsync(); ;



                foreach (var tutorgradeSubject in TutorGradeSubjectList)
                {
                    var t = new TutorSubject();
                    t.Id = tutorgradeSubject.Id;
                    t.TutorGradeId = tutorgradeId;
                    t.SubjectId = subjectId;

                    smallerList.Add(t);
                }


                var idNum = 0;

                foreach (var tutorSubject in smallerList)
                {
                    if (tutorSubject.TutorGradeId == tutorgradeId && tutorSubject.SubjectId == subjectId)
                    {
                        var id = tutorSubject.Id;
                        idNum = id;

                        var existingTutorSubject = await _tutorSubjectRepository.GetByIdAsync(idNum);
                        if (existingTutorSubject == null) return NotFound($"The subject does not exist");

                        _tutorGrades.Remove(existingTutorSubject);
                        smallerList.Remove(existingTutorSubject);

                        if (await _tutorGrades.SaveChangesAsync()) return Ok(existingTutorSubject);
                    }
                }








            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }


        [HttpGet("GetSubjectName/{id}")]
        public async Task<IActionResult> GetSubjectName(int id)
        {
            try
            {
                var myTutorSubjects = await _tutorSubjectRepository.GetAllAsync();
                var myTGSubjects = await _appDbContext.GetAllSubjectsAsync();
                var subjectNum = new List<int>();
                var myTutorSubjectsToReturn = new List<string>();

                foreach (var tutorSubject in myTutorSubjects)
                {
                    if (tutorSubject.TutorGradeId == id)
                    {
                        subjectNum.Add(tutorSubject.SubjectId);
                    }
                }

                foreach (var subject in subjectNum)
                {
                    foreach (var subjectId in myTGSubjects)
                    {
                        if (subjectId.Id == subject)
                        {
                            myTutorSubjectsToReturn.Add(subjectId.SubjectName);
                        }
                    }
                }
                return Ok(myTutorSubjectsToReturn);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


        [HttpGet("GetGradeSubjectId/{subjectid,gradeid}")]
        public async Task<IActionResult> GetGradeSubjectId(int subjectid, int gradeid)
        {
            try
            {
                var myTutorSubjects = await _tutorSubjectRepository.GetAllAsync();

                foreach (var sub in myTutorSubjects)
                {
                    if ((sub.SubjectId == subjectid) && (sub.TutorGradeId == gradeid))
                    {
                        return (Ok(sub.Id));
                    }
                }

                return Ok(myTutorSubjects);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetTutorThatTutorsThatSubject")]
        public async Task<IActionResult> GetGradeSubjectId(int subjectid, int grade, DateTime date)
        {
            try
            {
                var mySubjects = await _appDbContext.GetSubjectAsync(subjectid);
                var myGrades = await _grade.GetAllAsync();

                var gradeid = 0;

                foreach (var x in myGrades)
                {
                    if (x.Id == grade)
                    {
                        gradeid = x.Id;
                    }

                }

                var tutorgrades = await _tutorGrades.GetAllAsync();
                //return Ok(tutorgrades);


                var tutorgradelist = new List<TutorGrade>();



                foreach (var y in tutorgrades)
                {
                    if (y.GradeId == gradeid)
                    {
                        var gradethingtoadd = new TutorGrade();

                        gradethingtoadd.Id = y.Id;
                        gradethingtoadd.TutorId = y.TutorId;
                        gradethingtoadd.GradeId = y.GradeId;

                        tutorgradelist.Add(gradethingtoadd);

                    }
                }

                //return Ok(tutorgradelist);

                var tutorsubject = await _tutorSubjectRepository.GetAllAsync();
                var tutsubjectlist = new List<TutorSubject>();




                foreach (var i in tutorgradelist)
                {
                    foreach (var x in tutorsubject)
                    {
                        if ((i.Id == x.TutorGradeId) && (x.SubjectId == subjectid))
                        {
                            var addedthing = new TutorSubject();

                            addedthing.Id = x.Id;
                            addedthing.SubjectId = x.SubjectId;
                            addedthing.TutorGradeId = x.TutorGradeId;

                            tutsubjectlist.Add(addedthing);
                        }
                    }
                }


                //works to here
                // return Ok(tutsubjectlist);

                var newlist = new List<TutorGrade>();

                foreach (var t in tutsubjectlist)
                {
                    var tut = new TutorGrade();

                    var g = await _tutorGrades.GetByIdAsync(t.TutorGradeId);

                    tut.Id = g.Id;
                    tut.TutorId = g.TutorId;
                    tut.GradeId = g.GradeId;

                    //return Ok(tut);

                    newlist.Add(tut);
                }

                //return newlist
                //works until here
                //return Ok(newlist);

                var f = await _tutavi.GetAllAsync();
                var tutavail = new List<TutorAvailability>();

                foreach (var e in newlist)
                {


                    foreach (var x in f)
                    {
                        if (e.TutorId == x.TutorId)
                        {
                            var g = new TutorAvailability();

                            g.Id = x.Id;
                            g.TutorId = x.TutorId;
                            g.CompanyAvailabilityId = x.CompanyAvailabilityId;
                            g.Date = x.Date;
                            g.isTaken = x.isTaken;

                            tutavail.Add(g);
                        }
                    }


                }

                //return Ok(tutavail);

                var finallisttoreturn = new List<TutorVM>();

                //return Ok(tutavail);


                foreach (var p in tutavail)
                {
                    if ((p.Date.Date == date.Date) && (p.isTaken == false))
                    {
                        var Tutor = await _tutorRepository.GetByIdAsync(p.TutorId);

                        var companyavail = await _db.GetByIdAsync(p.CompanyAvailabilityId);

                        var vm = new TutorVM
                        {
                            Id = p.Id,
                            Name = Tutor.TutorName + " " + Tutor.TutorSurname,
                            TutorId = Tutor.Id,
                            StartTime = companyavail.startTime,
                            EndTime = companyavail.endTime,
                            Date = p.Date,
                            Subject = mySubjects.SubjectName,
                        };
                        finallisttoreturn.Add(vm);
                    }
                }

                return Ok(finallisttoreturn);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetTutorList")]
        public async Task<IActionResult> GetTutorList()
        {
            var tutorlist = await _tutorRepository.GetAllAsync();
            
            var tutsubjectlist = await _tutorSubjectRepository.GetAllAsync();

            var finallisttoreturn = new List<TutorSubjectListViewModel>();

            foreach(var tutor in tutorlist) 
            {
                var tutorName = tutor.TutorName + " "+ tutor.TutorSurname;
                var tutgradelist = await _tutorGrades.FindByListConditionAsync(grade => grade.TutorId == tutor.Id);

                foreach (var t in tutgradelist)
                {
                    var grade = await _grade.GetByIdAsync(t.GradeId);
                    var gradeName = grade.gradeName;

                    var subjectList = await _tutorSubjectRepository.FindByListConditionAsync(subject => subject.TutorGradeId == t.Id);

                    var newsubjectlist = "";

                    foreach(var s in subjectList)
                    {
                        var subject = await _appDbContext.GetSubjectAsync(s.SubjectId);
                        var subjectName = subject.SubjectName;

                        newsubjectlist += subjectName + ", ";
                    }

                    var vm = new TutorSubjectListViewModel
                    {
                        TutorName = tutorName,
                        Grade = gradeName,
                        Subjects = newsubjectlist
                    };
                    finallisttoreturn.Add(vm);
                    
                }
                return Ok(finallisttoreturn);
            }
            return Ok("i have nothing");
        }
    }
}

