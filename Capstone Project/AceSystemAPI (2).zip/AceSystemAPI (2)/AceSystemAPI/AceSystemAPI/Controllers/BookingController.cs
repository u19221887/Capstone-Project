﻿using AceSystemAPI.Models;
using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Bookings;
using AceSystemAPI.Models.Interfaces;
using AceSystemAPI.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using System.Security.Principal;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
  

    public class BookingController : ControllerBase
    {
        private readonly AppDbContext _appDbContext;
        private readonly IRepository<_Booking> _bookingRepository;

        private readonly IRepository<TutorAvailability> _tutorAvailabilityRepository;

        //tutorRepo
        private readonly IRepository<Tutors> _tutorRepository;

        //studentRepo

        private readonly IStudentRepository _studentRepository;

        //companyTimerepo

        private readonly IRepository<CompanyAvailability> _companyAvailability;

        //sessionRepo

        private readonly IRepository<SessionCost> _sessionCostRepository;

        //subjectTutorRepo
        private readonly IRepository<SubjectTutor> _subjectTutorRepository;

        private readonly IRepository<Subject> _subjectRepository;
        private readonly IRepository<Payment> _paymentRepository;

        

        public BookingController(IRepository<_Booking> bookingRepository,
            IRepository<TutorAvailability> tutorAvailabilityRepository,
            IRepository<Tutors> tutorRepository,
            IStudentRepository studentRepository,
            IRepository<CompanyAvailability> companyAvailability,
            IRepository<SessionCost> sessionCostRepository,
            IRepository<SubjectTutor> subjectTutorRepository,
            IRepository<Subject> subjectRepository,
            IRepository<Payment> paymentRepository,
            AppDbContext appDbContext, UserManager<IdentityUser> userManager

            )
        {
            _bookingRepository = bookingRepository;
            _tutorAvailabilityRepository = tutorAvailabilityRepository;
            _tutorRepository = tutorRepository;
            _studentRepository = studentRepository;
            _companyAvailability = companyAvailability;
            _sessionCostRepository = sessionCostRepository;
            _subjectTutorRepository = subjectTutorRepository;
            _subjectRepository = subjectRepository;
            _paymentRepository = paymentRepository;
            _appDbContext = appDbContext;
        }



        //show CompanyAvailability times
        [HttpGet("CompanyAvailability")]
        public IActionResult GetCompanyAvailability()
        {
            return Ok();
        }

        //post function to add a tutor availabilty

        

        //Make a booking

        [HttpPost("MakeBooking")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<ActionResult> MakeBooking([FromBody] _Booking booking)
        {
            try
            {
                if (booking == null)
                {
                    return BadRequest("Booking object is null");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest("Invalid model object");
                }

                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
                booking.userId = userId;

                //find student using userId
                //student = await _studentRepository

                TutorAvailability tutor = await _tutorAvailabilityRepository.GetByIdAsync(booking.TutorAvailabiltyId);
                tutor.isTaken = true;

                _tutorAvailabilityRepository.Update(tutor);

                _bookingRepository.Add(booking);
                return Ok(await _bookingRepository.SaveChangesAsync());
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        //student Viewbooking session with startDate,endDate, TutorName use TutorVM

        [HttpGet("ViewBookingSession/{studentId}")]
        //[Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<ActionResult> ViewBookingSession(int studentId)
        {
            try
            {
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;

                var bookings = await _bookingRepository.FindByListConditionAsync(booking => booking.StudentId == studentId);
                var bookingsToReturn = new List<TutorVM>();

                foreach (var booking in bookings)
                {

                        var tutorAvailability = await _tutorAvailabilityRepository.GetByIdAsync(booking.TutorAvailabiltyId);
                        var companyAvailability = await _companyAvailability.GetByIdAsync(tutorAvailability.CompanyAvailabilityId);
                        var tutor = await _tutorRepository.GetByIdAsync(tutorAvailability.TutorId);
                        //find the session cost 
                        var sessionCost = await _sessionCostRepository.GetByIdAsync(booking.SessionCostId);

                        //find just the subject name
                        var subjectTutor = await _subjectTutorRepository.GetByIdAsync(booking.TutorSubjectId);
                        //var subject = await _subjectRepository.GetByIdAsync(subjectTutor.SubjectId);
                        double price = sessionCost.Amount ;


                        var subject = await _subjectRepository.GetByIdAsync(booking.TutorSubjectId) ;

                        var subjectName = subject.SubjectName;


                        if(isDiscountApplied(userId))
                        {
                            //apply discount
                            price =  price - (price * 0.1); //add your  it to your needs 
                        }

                        var tutorVM = new TutorVM
                        {
                            Id  = booking.Id,
                            Name = tutor.TutorName + " " + tutor.TutorSurname,
                            StartTime = companyAvailability.startTime,
                            EndTime = companyAvailability.endTime,
                            Date = tutorAvailability.Date,
                            Subject = subjectName,
                            Price = sessionCost.Amount.ToString(),
                            isPayedUp = booking.isPayed,
                            isDiscountApplied = isDiscountApplied(userId),
                        };

                        bookingsToReturn.Add(tutorVM);
                    
                }

                return Ok(bookingsToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


        //do the same as the above for tutor viewbooking session, with stundent name, startDate, endDate

        [HttpGet("ViewBookingSessionTutor")]
        [Authorize(AuthenticationSchemes = "Bearer")]

        public async Task<ActionResult> ViewBookingSessionTutor()
        {
            try
            {

                var bookingForTutors = await _bookingRepository.GetAllAsync();
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
                int  tutorId =   _tutorRepository.GetAllAsync().Result.Where( r => r.userId == userId).FirstOrDefault().Id;

                List<TutorVM> bookingsToReturn = new List<TutorVM>();

                foreach (var booking in bookingForTutors)
                {
                   
                     
                    var tutorAvailability = await _tutorAvailabilityRepository.GetByIdAsync(booking.TutorAvailabiltyId);
                    var companyAvailability = await _companyAvailability.GetByIdAsync(tutorAvailability.CompanyAvailabilityId);
                    var student = await _studentRepository.GetStudentAsync((int)booking.StudentId);
                    //find the session cost 
                    var sessionCost = await _sessionCostRepository.GetByIdAsync(booking.SessionCostId);

                    //find just the subject name
                     //var subjectTutor = await _subjectTutorRepository.GetByIdAsync(booking.TutorSubjectId);
                    var subject = await _subjectRepository.GetByIdAsync(booking.TutorSubjectId);

                    var bookingprice = "";
                    var bookingtype = "";

                    if(booking.SessionCostId==1)
                    {
                        bookingprice = "R250";
                        bookingtype = "In-Person";
                    }
                    if (booking.SessionCostId == 2)
                    {
                        bookingprice = "R150";
                        bookingtype = "Online";
                    }


                    if ((tutorAvailability.TutorId == tutorId) && (booking.isPayed==true))
                    {
                        var tutorVM = new TutorVM
                        {
                            Id = booking.Id,
                            Name = student.StudentName + " " + student.StudentSurname,
                            Subject = subject.SubjectName,
                            Price = bookingprice,
                            Type = bookingtype,
                            StartTime = companyAvailability.startTime,
                            EndTime = companyAvailability.endTime,
                            Date = tutorAvailability.Date,
                            isPayedUp =  booking.isPayed

                        };

                        bookingsToReturn.Add(tutorVM);
                    }
                ;
                }
                return Ok(bookingsToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }



        [HttpGet("ViewAdminBookingSession")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<ActionResult> ViewAdminBookingSession()
        {
            try
            {
                var bookings = await _bookingRepository.GetAllAsync();
                var bookingsToReturn = new List<TutorVM>();

                foreach (var booking in bookings)
                {
                    // Check if the booking is paid
                    if (booking.isPayed)
                    {
                        var tutorAvailability = await _tutorAvailabilityRepository.GetByIdAsync(booking.TutorAvailabiltyId);
                        var companyAvailability = await _companyAvailability.GetByIdAsync(tutorAvailability.CompanyAvailabilityId);
                        var tutor = await _tutorRepository.GetByIdAsync(tutorAvailability.TutorId);
                        var sessionCost = await _sessionCostRepository.GetByIdAsync(booking.SessionCostId);
                        var student = await _studentRepository.GetStudentAsync((int)booking.StudentId);
                        
                        var tutorVM = new TutorVM
                        {
                            Id = booking.Id,
                            Name = tutor.TutorName + " " + tutor.TutorSurname,
                            StudentName = student.StudentName + " " + student.StudentSurname,
                            StartTime = companyAvailability.startTime,
                            EndTime = companyAvailability.endTime,
                            Date = tutorAvailability.Date,
                            Price = sessionCost.Amount.ToString(),
                            isPayedUp = booking.isPayed,
                            
                        };

                        bookingsToReturn.Add(tutorVM);
                    }
                }

                return Ok(bookingsToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }







        //update booking status isPayed and add payment to payment table

        [HttpPost("UpdateBookingStatus")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<ActionResult> UpdateBookingStatus([FromBody] PaymentVM payment)
        {
            try
            {
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
                //create new PaymentObject and add to payment table
                var paymentObject = new Payment
                {
                    userId = userId,
                    Amount = payment.Amount,
                    Date = DateTime.Now,
                    Ref = payment.Ref
                };

                _paymentRepository.Add(paymentObject);
                await _paymentRepository.SaveChangesAsync();


                var booking = await _bookingRepository.GetByIdAsync(payment.BookingId);
                booking.isPayed = true;
                _bookingRepository.Update(booking);
                return Ok(await _bookingRepository.SaveChangesAsync());
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }
        [HttpGet]
        public bool isDiscountApplied(string userId)
        {
            try
            {
                var bookings =  _bookingRepository.FindByListConditionAsync(booking => booking.userId == userId);

               if(bookings.Result.Count() > 8)
                {
                    return true;
                }
                else
                {
                    return false;
                }   

            }
            catch (Exception)
            {
                return false;
            }
        }

        [HttpGet]
        [Route("CountBookings")]
        public async Task<IActionResult> CountBookings()
        {
            try
            {
                int num = await _appDbContext.Booking.CountAsync();

                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("SessionCosts")]
        public async Task<ActionResult> SessionCosts()
        {
            try
            {
                var results = await _bookingRepository.GetSessionCostsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }

        }

        [HttpGet]
        [Route("CountOnline")]
        public async Task<IActionResult> CountOnline()
        {
            try
            {
                var results = await _bookingRepository.CountOnlineAsync();

                int num = results.Count();


                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CountInPerson")]
        public async Task<IActionResult> CountInPerson()
        {
            try
            {
                var results = await _bookingRepository.CountInPersonAsync();

                int num = results.Count();


                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CheckBookingStatus/{id}")]
        public async Task<IActionResult> CheckBookingStatus(int id)
        {
            bool result = false;

            try
            {
                var bookingForTutors = await _bookingRepository.GetAllAsync();
                foreach (var booking in bookingForTutors)
                {
                    if ((booking.StudentId == id) && (booking.isPayed == true))
                    {
                        result = true;
                        return Ok(result);
                    }

                }

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return Ok(result);
        }

        [HttpGet("ViewAllOnlineBookingSession")]
        public async Task<ActionResult> ViewAllBookingSession()
        {
            var bookings = await _bookingRepository.FindByListConditionAsync(booking=> booking.SessionCostId==2);
            var bookingsToReturn = new List<TutorVM>();

            foreach (var booking in bookings)
            {
                var tutorAvailability = await _tutorAvailabilityRepository.GetByIdAsync(booking.TutorAvailabiltyId);
                var companyAvailability = await _companyAvailability.GetByIdAsync(tutorAvailability.CompanyAvailabilityId);
                var student = await _studentRepository.GetStudentAsync((int)booking.StudentId);
                var tutor = await _tutorRepository.GetByIdAsync(tutorAvailability.TutorId);
                var subject = await _subjectRepository.GetByIdAsync(booking.TutorSubjectId);
                var sessionCost = await _sessionCostRepository.GetByIdAsync(booking.SessionCostId);
                var bookingprice = "";
                var bookingtype = "";

                if (booking.SessionCostId == 1)
                {
                    bookingprice = "R250";
                    bookingtype = "In-Person";
                }
                if (booking.SessionCostId == 2)
                {
                    bookingprice = "R150";
                    bookingtype = "Online";
                }


                var tutorVM = new TutorVM
                {
                    Id = booking.Id,
                    Name = tutor.TutorName + " " + tutor.TutorSurname,
                    StudentName = student.StudentName + " " + student.StudentSurname,
                    StartTime = companyAvailability.startTime,
                    EndTime = companyAvailability.endTime,
                    Date = tutorAvailability.Date,
                    Price = bookingprice,
                    isPayedUp = booking.isPayed,
                    Subject = subject.SubjectName,
                    Type = bookingtype,
                    

                };

                bookingsToReturn.Add(tutorVM);
            }
            return Ok(bookingsToReturn);
        }

        [HttpGet("ViewAllInPersonBookingSession")]
        public async Task<ActionResult> ViewAllInPersonBookingSession()
        {
            var bookings = await _bookingRepository.FindByListConditionAsync(booking => booking.SessionCostId == 1);
            var bookingsToReturn = new List<TutorVM>();

            foreach (var booking in bookings)
            {
                var tutorAvailability = await _tutorAvailabilityRepository.GetByIdAsync(booking.TutorAvailabiltyId);
                var companyAvailability = await _companyAvailability.GetByIdAsync(tutorAvailability.CompanyAvailabilityId);
                var student = await _studentRepository.GetStudentAsync((int)booking.StudentId);
                var tutor = await _tutorRepository.GetByIdAsync(tutorAvailability.TutorId);
                var subject = await _subjectRepository.GetByIdAsync(booking.TutorSubjectId);
                var sessionCost = await _sessionCostRepository.GetByIdAsync(booking.SessionCostId);
                var bookingprice = "";
                var bookingtype = "";

                if (booking.SessionCostId == 1)
                {
                    bookingprice = "R250";
                    bookingtype = "In-Person";
                }
                if (booking.SessionCostId == 2)
                {
                    bookingprice = "R150";
                    bookingtype = "Online";
                }


                var tutorVM = new TutorVM
                {
                    Id = booking.Id,
                    Name = tutor.TutorName + " " + tutor.TutorSurname,
                    StudentName = student.StudentName + " " + student.StudentSurname,
                    StartTime = companyAvailability.startTime,
                    EndTime = companyAvailability.endTime,
                    Date = tutorAvailability.Date,
                    Price = bookingprice,
                    isPayedUp = booking.isPayed,
                    Subject = subject.SubjectName,
                    Type = bookingtype,


                };

                bookingsToReturn.Add(tutorVM);
            }
            return Ok(bookingsToReturn);
        }

        [HttpGet("ViewTotal")]
        public async Task<ActionResult> ViewTotal()
        {
            var bookings = await _bookingRepository.FindByListConditionAsync(booking => booking.isPayed == true);
            var bookingsToReturn = new List<TutorVM>();

            var bookingprice = "";
            var bookingtype = "";
            var total = 0;

            foreach (var booking in bookings)
            {              
                

                if (booking.SessionCostId == 1)
                {
                    bookingprice = "R250";
                    bookingtype = "In-Person";
                    total = total + 250;
                }
                if (booking.SessionCostId == 2)
                {
                    bookingprice = "R150";
                    bookingtype = "Online";
                    total = total + 150;
                }


                
            }
            return Ok(total);
        }



    }
}
