using AceSystemAPI.Models;
using AceSystemAPI.ViewModels;
using Microsoft.AspNetCore.Mvc;
using System.Linq.Expressions;

namespace AceSystemAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class RecordingsController : Controller
  {
    private readonly IRecordingsRepository _recordingsRepository;
    private readonly IBlobRepository _blobRepository;

    private readonly IConfiguration _configuration;

    public RecordingsController(IRecordingsRepository recordingsRepository, IBlobRepository blobRepository, IConfiguration configuration)
    {
      _recordingsRepository = recordingsRepository;
      _blobRepository = blobRepository;
      _configuration = configuration;
    }

    [HttpGet]
    [Route("GetAllRecordingsDetails")]
    public async Task<IActionResult> GetAllRecordingsDetails()
    {
      try
      {
        var results = await _recordingsRepository.GetAllRecordingsDetailsAsync();
        return Ok(results);
      }
      catch (Exception)
      {
        return StatusCode(500, "Internal Server Error. Please Contact Support");
      }

    }

    [HttpGet]
    [Route("GetRecordingDetails/{subject_ID}")]
    public async Task<IActionResult> GetRecordingDetails(int subject_ID)
    {
      try
      {
        var answer = await _recordingsRepository.GetAllRecordingsDetailsAsync();

        var thingstoreturn = new List<Recordings>();

        if (answer == null) return NotFound("Recording does not exist");

        foreach(var ans in answer)
        {
          if (ans.Subject_Id == subject_ID)
          {
            thingstoreturn.Add(ans);
          }

        }

        return Ok(thingstoreturn);
      }
      catch (Exception)
      {
        return StatusCode(500, "Internal Server Error. Please Contact Support");
      }
    }

    [HttpGet]
    [Route("GetSearchedRecordingsDetails/{enteredQuery}")]
    public async Task<IActionResult> GetSearchedRecordingsDetails(string enteredQuery)
    {
      try
      {
        var result = await _recordingsRepository.GetSearchedRecordingsDetailsAsync(enteredQuery);
        if (result == null)
        {
          return NotFound("Recording Details does not exist.");
        }
        return Ok(result);
      }
      catch(Exception)
      {
        return StatusCode(500, "Internal Server Error. Please contact support");
      }
    }

    [HttpGet]
    [Route("GenerateBlobStreamLink/{fileName}")]
    public async Task<IActionResult> GenerateBlobStreamLink(string fileName)
    {

      try
      {
        string blobStreamLink = await _blobRepository.GenerateBlobStreamLinkAsync(fileName);
        return Content(blobStreamLink, "text/plain");
      }
      catch (Exception ex)
      {
        return BadRequest($"Error generating stream link: {ex.Message}");
      }

    }

    [HttpPost]
    [Route("AddRecordings")]
    public async Task<IActionResult> AddRecordings([FromForm] RecordingsViewModel rViewModel)
    {
      // Processing the uploaded File or Files
      var file = rViewModel.VideoFile;
      string fileName = file.FileName;

      try
      {
        // If the file is empty, notify the user that no file is uploaded
        if (file == null)
        {
          return BadRequest("No File uploaded.");
        }
        else
        {
          // If recording video with the same file name already exists, notify the user
          var existingRecordingBlob = await _recordingsRepository.GetABlobFile(file.FileName);
          if (existingRecordingBlob != null)
          {
            return BadRequest($"Recording already exists");
          }
          else
          {
            // If the file is not empty, then process the video and add a new recording
            if (file != null && file.Length > 0)
            {
              byte[] fileData;
              using (var memoryStream = new MemoryStream())
              {
                await file.CopyToAsync(memoryStream);
                fileData = memoryStream.ToArray();
              }


              // Assign rViewModel.Name as the new file name
              string newFileName = rViewModel.Name + Path.GetExtension(fileName);


              // Renaming video to a sanitized video name that doesn't cause errors when adding to Azure
              string sanitizedFileName =

                Path.GetFileNameWithoutExtension(newFileName)
                  .Replace(" ", "_")
                  .Replace("-", "_")
                  .Replace("...", "_")
                  + Path.GetExtension(fileName);

              // Upload the video file to the Blob Storage using BlobRepository
              string blobUrl = await _recordingsRepository.UploadBlobFile(sanitizedFileName, fileData);
              var filePath = blobUrl;

              var Recordings = new Recordings
              {
                Name = rViewModel.Name,
                Description = rViewModel.Description,
                Date = DateTime.Now.ToString("dd-MM-yyyy"),
                FilePath = filePath,
                FileName = sanitizedFileName, // Assign the new file name here
                Subject_Id = rViewModel.Subject_Id,
              };

              _recordingsRepository.Add(Recordings);
              await _recordingsRepository.SaveChangesAsync();

              return Ok(Recordings);
            }
            // Perform your desired logic with the received data
            return Ok("Data received successfully!");
          }
        }
      }
      catch (Exception ex)
      {
        return BadRequest($"Error uploading video: {ex.Message}");
      }
    }


    [HttpPut]
    [Route("EditRecording/{RecordingsID}")]
    public async Task<ActionResult<RecordingsViewModel>> EditRecordings(int RecordingsID, [FromForm] RecordingsViewModel recordingsViewModel)
    {
      try
      {
        var existingRecording = await _recordingsRepository.GetRecordingDetailsAsync(RecordingsID);
        if (existingRecording == null)
        {
          return NotFound("Recording Details does not exist.");

        }

        existingRecording.Name = recordingsViewModel.Name;
        existingRecording.Description = recordingsViewModel.Description;
        existingRecording.Date = DateTime.Now.ToString("dd-MM-yyyy");

        //if new video is uploaded
        var file = recordingsViewModel.VideoFile;
        if(file != null && file.Length > 0)
        {
          _blobRepository.DeleteHomeworkFile(existingRecording.FileName);
          //sanitize the file name
          string sanitzedFileName = Path.GetFileNameWithoutExtension(file.FileName)
            .Replace(" ", "_")
            .Replace("-", "_") // Replace hyphens with underscores if needed
            .Replace("...", "_") // Replace multiple dots with a single underscore if needed
            + Path.GetExtension(file.FileName);

          //convert video to file data
          byte[] fileData;
          using(var memoryStream = new MemoryStream())
          {
            await file.CopyToAsync(memoryStream);
            fileData = memoryStream.ToArray();
          }
          //assign sanitized file name
          string fileName = sanitzedFileName;
          //Upload the video file to Blob storage
          string blobUrl = await _blobRepository.UploadVideoFiles(fileName, fileData);
          //assign the videoUrl
          var filePath = blobUrl;

          //chnage the fileName and filePath
          existingRecording.FilePath = filePath;
          existingRecording.FileName = fileName;

        }
        if (await _recordingsRepository.SaveChangesAsync())
        {
          return Ok(existingRecording);
        }
      }
      catch (Exception)
      {
        return StatusCode(500, "Internal Server Error. Please contact support");
      }
      return BadRequest("Your request is invalid");

    }
    //Delete a Recording
    [HttpDelete]
    [Route("DeleteRecording/{RecordingID}")]
    public async Task<IActionResult> DeleteRecording(int RecordingID)
    {
      try
      {
        var existingRecording = await _recordingsRepository.GetRecordingDetailsAsync(RecordingID);
        if (existingRecording == null)
        {
          return NotFound($"The recording does not exist");
        }

        //_blobRepository.DeleteHomeworkFile(existingRecording.FileName);
        _recordingsRepository.DeleteBlob(existingRecording.FilePath);
        _recordingsRepository.Delete(existingRecording);

        if(await _recordingsRepository.SaveChangesAsync())
        {
          return Ok(existingRecording);
        }

      }
      catch (Exception)
      {
        return StatusCode(500, "Internal Server Error. Please contact support");
      }
      return BadRequest("Your request is invalid");
    }
  }
}
