﻿using AceSystemAPI.Models;
using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Interfaces;
using AceSystemAPI.Models.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Security.Claims;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace AceSystemAPI.Controllers
{
    //[Authorize(AuthenticationSchemes = "Bearer")]
    [Route("api/[controller]")]
    [ApiController]
    public class AvailabilityController : ControllerBase
    {


        private readonly IRepository<CompanyAvailability> _db;
        private readonly IRepository<TutorAvailability> _tutorAvailabilityRepository;
        //tutorRepo
        private readonly IRepository<Tutors> _tutorRepository;
        private readonly ITutorRepository _tutorrepos;
        private readonly UserManager<IdentityUser> _userManager;



        public AvailabilityController(IRepository<CompanyAvailability> db, IRepository<TutorAvailability> tutorAvailabilityRepository, ITutorRepository tutorrepos, UserManager<IdentityUser> userManager)
        {
            _db = db;
            _tutorAvailabilityRepository = tutorAvailabilityRepository;
            _userManager = userManager;
            _tutorrepos = tutorrepos;
        }

        //get all CompanyAvailability
        [HttpGet("GetAllCompanyAvailabilityTimes")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<IActionResult> GetCompanyAvailability()
        {
            var claimsIdentity = this.User.Identity as ClaimsIdentity;
            var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
            var CompanyAvailabilities = await _db.GetAllAsync();
            return Ok(CompanyAvailabilities);
        }

        //get tutor availability times where isTaken is false
        [HttpGet("GetTutorAvailabilityTimes/{tutorId}")]
        public async Task<IActionResult> GetTutorAvailabilityTimes(int tutorId)
        {
            try
            {
                var tutorAvailabilityTimes = await _tutorAvailabilityRepository.GetAllAsync();
                var tutorAvailabilityTimesToReturn = new List<int>();

                foreach (var tutorAvailabilityTime in tutorAvailabilityTimes)
                {
                    if (tutorAvailabilityTime.TutorId == tutorId && tutorAvailabilityTime.isTaken == false)
                    {
                        tutorAvailabilityTimesToReturn.Add(tutorAvailabilityTime.CompanyAvailabilityId);
                    }
                }

                return Ok(tutorAvailabilityTimesToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


        //get all availability times where isTaken is false, for a specific date  and show the tutor name and start time,end time and date
        [HttpGet("GetAllAvailabilityTimes/{date}")]
        
        public async Task<IActionResult> GetAllAvailabilityTimes(DateTime date)
        {
            try
            {
          
                var userid = User.Claims.Where(x => x.Type == "id").FirstOrDefault()?.Value;

                var tutorAvailabilityTimes = await _tutorAvailabilityRepository.GetAllAsync();
                var tutorAvailabilityTimesToReturn = new List<TutorVM>();

                foreach (var tutorAvailabilityTime in tutorAvailabilityTimes)
                {
                    if (tutorAvailabilityTime.Date.Date == date.Date && tutorAvailabilityTime.isTaken == false)
                    {
                        //get tutor name
                        var Tutor = await _tutorrepos.GetTutorById(tutorAvailabilityTime.TutorId);

                        //get company availability
                        var CompanyAvailability = await _db.GetByIdAsync(tutorAvailabilityTime.CompanyAvailabilityId);
                        var tutorAvailabilityTimeToReturn = new TutorVM
                        {
                            Id = tutorAvailabilityTime.Id,
                            Name = Tutor.TutorName + " " + Tutor.TutorSurname,
                            TutorId = Tutor.Id,
                            StartTime = CompanyAvailability.startTime,
                            EndTime = CompanyAvailability.endTime,
                            Date = tutorAvailabilityTime.Date
                        };

                        tutorAvailabilityTimesToReturn.Add(tutorAvailabilityTimeToReturn);
                    }
                }

                return Ok(tutorAvailabilityTimesToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }
        [HttpPost("AddTutorAvailabilityTimes")]
        [Authorize(AuthenticationSchemes = "Bearer")]
        public async Task<ActionResult> AddTutorAvailabilityTimes([FromBody] TutorAvailabilityVM tutorAvailability)
        {
           
            try
            {
                if (tutorAvailability == null)
                {
                    return BadRequest("Tutor Availability object is null");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest("Invalid model object");
                }


                //9b79fe76-c22e-44ad-81

                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
                var user = _tutorrepos.GetAllTutorsAsync().Result.Where(x => x.userId == userId).FirstOrDefault();
                var tutorAvailabilities = new List<TutorAvailability>();

                foreach (var availability in tutorAvailability.CompanyAvailabilities)
                {
                    var tutorAvailabilityToAdd = new TutorAvailability
                    {
                        TutorId = user.Id,
                        CompanyAvailabilityId = availability,
                        isTaken = false,
                        Date = tutorAvailability.Date
                    };

                    _tutorAvailabilityRepository.Add(tutorAvailabilityToAdd);

                }
                _tutorAvailabilityRepository.SaveChanges();

                return Ok();

            }
            catch (Exception c)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }



    }
}
