﻿using AceSystemAPI.Models;
using AceSystemAPI.Models.Interfaces;
using Microsoft.AspNetCore.Mvc;
using MimeKit.Encodings;
using System.Reflection.Metadata.Ecma335;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuditController : ControllerBase
    {
        private readonly IRepository<AuditTrail> _auditTrailRepository;
        private readonly IAdminRepository _admin;
        private readonly IStudentRepository _studentRepository;
        private readonly ITutorRepository _tutor;



        public AuditController(IRepository<AuditTrail> auditTrailRepository, IAdminRepository admin, ITutorRepository tutor, IStudentRepository student)
        { 
            _auditTrailRepository = auditTrailRepository;
            _admin = admin;
            _studentRepository = student;
            _tutor = tutor;

        }

        [HttpPost]
        [Route("AddAuditTrail")]
        public async Task<IActionResult> AddAuditTrail([FromForm] IFormCollection formData)
        {
            
                var audit = new AuditTrail
                {
                    Email = formData["Email"],
                    Date = DateTime.Now,
                    Action = formData["Action"]
                };
            try
            {
                _auditTrailRepository.Add(audit);
                await _auditTrailRepository.SaveChangesAsync();
            }
            catch (Exception ex) 
            {
                var errorMessage = ex.Message;
                if(errorMessage != null)
                {
                    errorMessage += "Inner exception" + ex.InnerException.Message;

                }
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
            return Ok(audit);
        }

        [HttpGet]
        [Route("GetAllAuditTrail")]
        public async Task<IActionResult> GetAllAuditTrail() 
        {
            try
            {
                var results = await _auditTrailRepository.GetAllAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetAuditTrailByUser/{role}")]
        public async Task<IActionResult> GetAuditTrailByUser(string role)
        {
            try
            {
                var results =await _auditTrailRepository.GetAllAsync();
                var a = await _admin.GetAllAdminsAsync();
                var t = await _tutor.GetAllTutorsAsync();
                var s = await _studentRepository.GetAllStudentsAsync();

                var x = new List<AuditTrail>();

                if(role == "Admin")
                {
                   foreach(var p in results)
                    {
                        foreach(var l in a)
                        {
                            if(p.Email==l.adminEmail)
                            {
                                x.Add(p);
                            }
                        }
                    }
                }
                if (role == "Student")
                {
                    foreach (var p in results)
                    {
                        foreach (var l in s)
                        {
                            if (p.Email == l.StudentEmail)
                            {
                                x.Add(p);
                            }
                        }
                    }
                }
                if (role == "Tutor")
                {
                    foreach (var p in results)
                    {
                        foreach (var l in t)
                        {
                            if (p.Email == l.TutorEmail)
                            {
                                x.Add(p);
                            }
                        }
                    }
                }

                return Ok(x);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (errorMessage != null)
                {
                    errorMessage += " Inner exception: " + ex.InnerException.Message;
                }
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
           
                    
        }
       
        
    }
}
