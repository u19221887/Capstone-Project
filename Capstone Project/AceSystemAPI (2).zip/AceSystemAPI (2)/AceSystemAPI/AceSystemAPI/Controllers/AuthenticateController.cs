﻿using AceSystemAPI.Auth;
using AceSystemAPI.Models;
using EmailService;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.WebUtilities;
using Microsoft.IdentityModel.Tokens;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Text;
using System.Web;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AuthenticateController : ControllerBase
    {
        private readonly UserManager<IdentityUser> _userManager;
        private readonly RoleManager<IdentityRole> _roleManager;
        private readonly IConfiguration _configuration;
        private readonly IEmailSender _emailSender;
        private readonly ITutorRepository _tutor;

        //for error handling
        private readonly ILogger<AuthenticateController> _logger;
        

        public AuthenticateController(
            UserManager<IdentityUser> userManager,
            RoleManager<IdentityRole> roleManager,
            IConfiguration configuration,
            ILogger<AuthenticateController> logger,
            ITutorRepository tutor,
             IEmailSender emailSender)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _configuration = configuration;
            _logger = logger;
            _emailSender = emailSender;
        }


        [HttpPost]
        [Route("login")]
        public async Task<IActionResult> Login([FromBody] LoginModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                var userRoles = await _userManager.GetRolesAsync(user);

                var authClaims = new List<Claim>
            {
                new Claim(ClaimTypes.Name,user.Id.ToString()),
                new Claim(ClaimTypes.Email,user.Email),

                new Claim(JwtRegisteredClaimNames.Jti, Guid.NewGuid().ToString()),
            };

                foreach (var userRole in userRoles)
                {
                    authClaims.Add(new Claim(ClaimTypes.Role, userRole));
                }

                var tokenResult = GenerateJWTToken(authClaims);
                return tokenResult;
            }
            return Unauthorized();
        }

        [HttpPost]
        [Route("student-login")]
        public async Task<IActionResult> StudentLogin([FromBody] LoginModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                // Check if the user has the student role
                if (await _userManager.IsInRoleAsync(user, UserRoles.Student))
                {
                    // Generate and return the token with the "Student" role claim
                    var tokenResult = GenerateJWTToken(new List<Claim> {
                     new Claim(ClaimTypes.Name,user.Id.ToString()),
                    new Claim(ClaimTypes.Email,user.Email),
                    new Claim(ClaimTypes.Role, UserRoles.Student)
            });
                    return tokenResult;
                }
                else
                {
                    return Unauthorized();
                }
            }
            return Unauthorized();
        }

        // Similar implementations for admin and tutor logins
        [HttpPost]
        [Route("admin-login")]
        public async Task<IActionResult> AdminLogin([FromBody] LoginModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                // Check if the user has the admin role
                if (await _userManager.IsInRoleAsync(user, UserRoles.Admin))
                {
                    // Generate and return the token with the "Admin" role claim
                    var tokenResult = GenerateJWTToken(new List<Claim> {
                 new Claim(ClaimTypes.Name,user.Id.ToString()),
                    new Claim(ClaimTypes.Email,user.Email),
                new Claim(ClaimTypes.Role, UserRoles.Admin)
            });
                    return tokenResult;
                }
                else
                {
                    return Unauthorized();
                }
            }
            return Unauthorized();
        }

        [HttpPost]
        [Route("tutor-login")]
        public async Task<IActionResult> TutorLogin([FromBody] LoginModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            if (user != null && await _userManager.CheckPasswordAsync(user, model.Password))
            {
                var check = await _userManager.IsInRoleAsync(user, UserRoles.Tutor);    
                if (check)
                {
                    // Generate and return the token with the "Tutor" role claim
                    var tokenResult = GenerateJWTToken(new List<Claim> {
                new Claim(ClaimTypes.Name,user.Id.ToString()),
                    new Claim(ClaimTypes.Email,user.Email),
                new Claim(ClaimTypes.Role, UserRoles.Tutor)
            });
                    return tokenResult;
                }
                else
                {
                    return Unauthorized();
                }
            }
            return Unauthorized();
        }




        // Register Student


        [HttpPost]
        [Route("registerStudent")]
        public async Task<IActionResult> RegisterStudent([FromBody] RegisterModel model)
        {
            try
            {
                var userExists = await _userManager.FindByEmailAsync(model.Email);
                if (userExists != null)
                {
                    _logger.LogInformation("User registration failed - Email already exists: {Email}", model.Email);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });
                }

                IdentityUser user = new IdentityUser
                {
                    Email = model.Email,
                    UserName = model.Email,
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString()
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                {
                    _logger.LogError("User registration failed - Error creating user: {Email}", model.Email);
                    foreach (var error in result.Errors)
                    {
                        _logger.LogError("Error: {ErrorMessage}", error.Description);
                    }
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User creation failed! Please check user details and try again." });
                }

                if (!await _roleManager.RoleExistsAsync(UserRoles.Student))
                {
                    await _roleManager.CreateAsync(new IdentityRole(UserRoles.Student));
                    _logger.LogInformation("Student role created.");
                }

                await _userManager.AddToRoleAsync(user, UserRoles.Student);
                _logger.LogInformation("User registered as a student: {Email}", model.Email);

                // Generate the JWT token with role claim
                var tokenResult = GenerateJWTToken(new List<Claim> {
            new Claim(ClaimTypes.Name, user.Email),
            new Claim(ClaimTypes.Role, UserRoles.Student)
        });
                return tokenResult;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during student registration: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "An unexpected error occurred during student registration." });
            }
        }



        //Register Admin

        [HttpPost]
        [Route("registerAdmin")]
        public async Task<IActionResult> RegisterAdmin([FromBody] RegisterModel model)
        {
            try
            {
                var userExists = await _userManager.FindByEmailAsync(model.Email);
                if (userExists != null)
                {
                    _logger.LogInformation("User registration failed - Email already exists: {Email}", model.Email);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });
                }

                IdentityUser user = new IdentityUser
                {
                    Email = model.Email,
                    UserName = model.Email,
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString()
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                {
                    _logger.LogError("User registration failed - Error creating user: {Email}", model.Email);
                    foreach (var error in result.Errors)
                    {
                        _logger.LogError("Error: {ErrorMessage}", error.Description);
                    }
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User creation failed! Please check user details and try again." });
                }

                if (!await _roleManager.RoleExistsAsync(UserRoles.Admin))
                {
                    await _roleManager.CreateAsync(new IdentityRole(UserRoles.Admin));
                    _logger.LogInformation("Admin role created.");
                }

                await _userManager.AddToRoleAsync(user, UserRoles.Admin);
                _logger.LogInformation("User registered as an admin: {Email}", model.Email);

                
                var tokenResult = GenerateJWTToken(new List<Claim> {
            new Claim(ClaimTypes.Name, user.Email),
            new Claim(ClaimTypes.Role, UserRoles.Admin)
        });
                return tokenResult;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during admin registration: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "An unexpected error occurred during admin registration." });
            }
        }

        //Register Tutor
        [HttpPost]
        [Route("registerTutor")]
        public async Task<IActionResult> RegisterTutor([FromBody] RegisterModel model)
        {
            try
            {
                var userExists = await _userManager.FindByEmailAsync(model.Email);
                if (userExists != null)
                {
                    _logger.LogInformation("User registration failed - Email already exists: {Email}", model.Email);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User already exists!" });
                }

                IdentityUser user = new IdentityUser
                {
                    Email = model.Email,
                    UserName = model.Email,
                    EmailConfirmed = true,
                    SecurityStamp = Guid.NewGuid().ToString()
                };

                var result = await _userManager.CreateAsync(user, model.Password);
                if (!result.Succeeded)
                {
                    _logger.LogError("User registration failed - Error creating user: {Email}", model.Email);
                    foreach (var error in result.Errors)
                    {
                        _logger.LogError("Error: {ErrorMessage}", error.Description);
                    }
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User creation failed! Please check user details and try again." });
                }

                if (!await _roleManager.RoleExistsAsync(UserRoles.Tutor))
                {
                    await _roleManager.CreateAsync(new IdentityRole(UserRoles.Tutor));
                    _logger.LogInformation("Tutor role created.");
                }

                await _userManager.AddToRoleAsync(user, UserRoles.Tutor);
                _logger.LogInformation("User registered as a tutor: {Email}", model.Email);

                // Generate the JWT token with role claim
                var tokenResult = GenerateJWTToken(new List<Claim> {
            new Claim(ClaimTypes.Name, user.Email),
            new Claim(ClaimTypes.Role, UserRoles.Tutor)
        });
                return tokenResult;

            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "An error occurred during tutor registration: {Message}", ex.Message);
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "An unexpected error occurred during tutor registration." });
            }
        }


        private ActionResult GenerateJWTToken(IEnumerable<Claim> claims)
        {
            
            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Tokens:Key"]));
            var credentials = new SigningCredentials(key, SecurityAlgorithms.HmacSha256);

            var token = new JwtSecurityToken(
                _configuration["Tokens:Issuer"],
                _configuration["Tokens:Audience"],
                claims,
                signingCredentials: credentials,
                expires: DateTime.UtcNow.AddHours(17)
            );

            return Created("", new
            {
                token = new JwtSecurityTokenHandler().WriteToken(token)
            });
        }


        
        [HttpPost]
        [Route("TutorAcceptance/{tutorEmail}")]
        public async Task<IActionResult> TutorAcceptanceAsync(string tutorEmail)
        {
            var tut = await _userManager.FindByEmailAsync(tutorEmail);

            //var user = await _tutor.GetTutorProfileAsync(tutorEmail);


            var uriBuilder = new UriBuilder(_configuration["ReturnPaths:TutorAcceptance"]);
            var query = HttpUtility.ParseQueryString(uriBuilder.Query);

            query["email"] = Convert.ToString(tut.Email);
            uriBuilder.Query = query.ToString();

            var link = uriBuilder.ToString();

            var message = new Message(new string[] { tut.Email }, "Acceptance Email", EmailBody.CreateBodyTutor(tut.Email, link));
            await _emailSender.SendEmailAsync(message);
            return Ok(new Response { Status = "Success", Message = "User found email sent!" });



        }


        [HttpPost]
        [Route("confirmEmail")]

        public async Task<IActionResult> ConfirmEmail(ConfirmEmailViewModel model)
        {
            var user = await _userManager.FindByIdAsync(model.userId);

            var result = await _userManager.ConfirmEmailAsync(user, model.token);

            if (result.Succeeded)
            {
                return Ok(new Response { Status = "Success", Message = "Email successfully confirmed!" });
            }
            return BadRequest();
        }

        [HttpPost]
        [Route("ForgotPassword")]
        public async Task<IActionResult> ForgotPasswordAsync(ForgotPasswordModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);

            var token = await _userManager.GeneratePasswordResetTokenAsync(user);

            if (!string.IsNullOrEmpty(token))
            {
                
                var uriBuilder = new UriBuilder(_configuration["ReturnPaths:ResetPassword"]);
                var query = HttpUtility.ParseQueryString(uriBuilder.Query);
                query["token"] = token;
                query["userId"] = user.Id;
                query["email"] = user.Email;
                uriBuilder.Query = query.ToString();
                var link = uriBuilder.ToString();

                
                var message = new Message(new string[] { user.Email }, "Reset password", EmailBody.CreateBodyForgotPassword(user.Email, link));
                await _emailSender.SendEmailAsync(message);
                return Ok(new Response { Status = "Success", Message = "User found email sent!" });
            }

            return BadRequest();
        }


        [HttpPost]
        [Route("ResetPassword")]
        public async Task<IActionResult> ResetPasswordAsync(ResetPasswordModel model)
        {
            try
            {
                _logger.LogInformation($"Attempting to reset password for email: {model.Email}");

                var user = await _userManager.FindByEmailAsync(model.Email);

                if (user == null)
                {
                    _logger.LogWarning($"User with email {model.Email} not found.");
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User not found!" });
                }

                // Generate the reset token
                var resetToken = await _userManager.GeneratePasswordResetTokenAsync(user);

                var result = await _userManager.ResetPasswordAsync(user, resetToken, model.Password);

                if (result.Succeeded)
                {
                    _logger.LogInformation($"Password reset successful for email: {model.Email}");
                    return Ok(new Response { Status = "Success", Message = "Password reset successful!" });
                }
                else
                {
                    _logger.LogWarning($"Password reset failed for email: {model.Email}");
                    foreach (var error in result.Errors)
                    {
                        _logger.LogError($"Error: {error.Code}, Description: {error.Description}");  
                    }
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "Password reset error!" });
                }
            }
            catch (Exception ex)
            {
                _logger.LogError($"An error occurred while resetting password: {ex.Message}");
                if (ex.InnerException != null)
                {
                    _logger.LogError($"Inner Exception: {ex.InnerException.Message}");
                }
                return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "An error occurred while resetting password." });
            }
        }


        [HttpPost("changepassword")]
        public async Task<IActionResult> ChangePasswordAsync(ChangePasswordModel model)
        {
            var user = await _userManager.FindByEmailAsync(model.Email);
            var result = await _userManager.ChangePasswordAsync(user, model.CurrentPassword, model.NewPassword);

            if (result.Succeeded)
            {
                return Ok(new Response { Status = "Success", Message = "Password change successful!" });
            }
            return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "Incorrect current password." });

        }

    }

}

