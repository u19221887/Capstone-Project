using Microsoft.AspNetCore.Mvc;
using AceSystemAPI.Models;
using AceSystemBackend.ViewModels;
using AceSystemAPI.ViewModels;

namespace AceSystemAPI.Controllers
{
  [Route("api/[controller]")]
  [ApiController]
  public class ParentFeedbackController : ControllerBase
  {
    private readonly IParentFeedbackRepository _appDbContext;


    public ParentFeedbackController(IParentFeedbackRepository appDbContext)
    {
      _appDbContext = appDbContext;

    }

    //[HttpPost]
    //[Route("AddFeedback")]
    //public async Task<IActionResult> AddFeedbackAsync(ParentFeedbackViewModel parentFeedback)
    //{
    //  try
    //  {
    //    ParentFeedback newParentFeedback = new ParentFeedback
    //    {
    //      ParentName = parentFeedback.ParentName,
    //      ParentSurname = parentFeedback.ParentSurname,
    //      ParentFeedbackDescription= parentFeedback.ParentFeedbackDescription,
    //      StudentName= parentFeedback.StudentName,
    //      StudentSurname= parentFeedback.StudentSurname,
    //      Subject = parentFeedback.Subject,

    //    };

    //    _appDbContext.Add(newParentFeedback);
    //    await _appDbContext.SaveChangesAsync();

    //    return Ok(newParentFeedback);
    //  }
    //  catch (Exception ex)
    //  {
    //    ILogger.LogError(ex, ex.Message);

    //    return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
    //  }
    //}

    [HttpPost]
    [Route("AddFeedback/{studentId}")]
    public async Task<IActionResult> AddFeedback(int studentId, [FromForm] IFormCollection formData)
    {
      var feedbackVar = new ParentFeedback
      {
        StudentName = formData["StudentName"],
        StudentSurname = formData["StudentSurname"],
        Subject = formData["Subject"],
        ParentName = formData["ParentName"],
        ParentSurname = formData["ParentSurname"],
        ParentFeedbackDescription = formData["ParentFeedbackDescription"]

      };
      try
      {
        _appDbContext.Add(feedbackVar);
        await _appDbContext.SaveChangesAsync();
      }
      catch (Exception ex)
      {
        var errorMessage = ex.Message;
        if (errorMessage != null)
        {
          errorMessage += " Inner exception: " + ex.InnerException.Message;
        }

        //_logger.LogError(ex, errorMessage);
        return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());

      }
      return Ok(feedbackVar);
    }

    //[HttpGet]
    //[Route("GetAllFeedback")]
    //public async Task<IActionResult> GetAllFeedback()
    //{
    //  try
    //  {
    //    var results = await _appDbContext.GetAllFeedbackAsync();
    //    return Ok(results);
    //  }
    //  catch (Exception ex)
    //  {
    //    return StatusCode(500, "Internal Server Error. Please Contact Support.");
    //  }
    //}

    [HttpGet]
    [Route("GetAllFeedback")]
    public async Task<IActionResult> GetAllFeedback()
    {
      try
      {
        var results = await _appDbContext.GetAllFeedbacksAsync();
        return Ok(results);
      }
      catch (Exception ex)
      {
        return StatusCode(500, "Internal Server Error. Please Contact Support.");
      }
    }

  }
}
