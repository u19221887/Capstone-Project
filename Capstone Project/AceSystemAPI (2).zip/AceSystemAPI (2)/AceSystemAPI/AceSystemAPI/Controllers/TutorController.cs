﻿using AceSystemAPI.Models;
using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Interfaces;
using AceSystemAPI.ViewModels;
using AceSystemBackend.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using AceSystemAPI.Models.ViewModels;
using AceSystemAPI.Auth;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Authorization;
using System.Security.Claims;
using System.Diagnostics.Eventing.Reader;
using Org.BouncyCastle.Bcpg;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TutorController : ControllerBase
    {
        private readonly IRepository<Tutors> _tutorRepository;
        private readonly AppDbContext _appDbContext;
        private readonly ITutorRepository _tutorrepos;
        private readonly ILogger<TutorController> _logger;
        private readonly IRepository<SubjectTutor> _subTutorRepository;
        private readonly IRepository<Subject> _subjectRepository;
        private readonly ITutorApplicationRepository _tutorApplicationRepository;
        private readonly IRepository<_Booking> _bookingRepository;
        private readonly IRepository<TutorAvailability> _tutorAvailabilityRepository;

        private readonly UserManager<IdentityUser> _userManager;

        public TutorController(IRepository<CompanyAvailability> db, 
            IRepository<TutorAvailability> tutorAvailabilityRepository,
            IRepository<Tutors> tutorRepository, 
            IRepository<SubjectTutor> subTutorRepository,
               IRepository<Subject> subjectRepository,
            ITutorRepository tutorrepos, 
            ILogger<TutorController> logger, 
            ITutorApplicationRepository tutorApplicationRepository,IRepository<_Booking> bookingrepository,
            IRepository<TutorAvailability> tutoravailabilityRepository,
            AppDbContext appDbContext, UserManager<IdentityUser> userManager
            )
        {
            _tutorrepos = tutorrepos;
            _logger = logger;
            _appDbContext = appDbContext;
            _tutorRepository = tutorRepository;
            _subTutorRepository = subTutorRepository;
            _userManager = userManager;
            _subjectRepository = subjectRepository;
            _tutorApplicationRepository = tutorApplicationRepository;
            _bookingRepository  = bookingrepository;  
            _tutorAvailabilityRepository= tutoravailabilityRepository;

        }


        //get all my tutor linked subjects
        [HttpGet("GetMyTutorSubjects")]
        [Authorize(AuthenticationSchemes = "Bearer")]

        public async Task<IActionResult> GetMyTutorSubjects(int tutorId)
        {
            try
            {
                //GET TUTOR
                var claimsIdentity = this.User.Identity as ClaimsIdentity;
                var userId = claimsIdentity.FindFirst(ClaimTypes.Name)?.Value;
                var user = _tutorrepos.GetAllTutorsAsync().Result.Where(x => x.userId == userId).FirstOrDefault();

                var myTutorSubjects = await _subTutorRepository.FindByListConditionAsync(r => r.TutorId == user.Id);
                var myTutorSubjectsToReturn = new List<SubjectVM>();

                foreach (var myTutorSubject in myTutorSubjects)
                {
                    var subject = await _subjectRepository.GetByIdAsync(myTutorSubject.SubjectId);
                    SubjectVM subjectVM = new SubjectVM();
                    subjectVM.subTutorId = myTutorSubject.Id;
                    subjectVM.SubjectName = subject.SubjectName;
                    subjectVM.SubjectDescription = subject.SubjectDescription;

                    myTutorSubjectsToReturn.Add(subjectVM);
                }

                return Ok(myTutorSubjectsToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


        [HttpGet("GetTutorSubjects/{tutorId}")]

        public async Task<IActionResult> GetTutorSubjects(int tutorId)
        {
            try
            {

                var myTutorSubjects = await _subTutorRepository.FindByListConditionAsync(r => r.TutorId == tutorId);
                var myTutorSubjectsToReturn = new List<SubjectVM>();

                foreach (var myTutorSubject in myTutorSubjects)
                {
                    var subject = await _subjectRepository.GetByIdAsync(myTutorSubject.SubjectId);
                    var tutor = await _tutorRepository.GetByIdAsync(myTutorSubject.TutorId);
                    SubjectVM subjectVM = new SubjectVM();
                    TutorVM tutorVM = new TutorVM();
                    tutorVM.Name = tutor.TutorName;
                    tutorVM.Name = tutor.TutorSurname;
                    subjectVM.subTutorId = myTutorSubject.Id;
                    subjectVM.SubjectName = subject.SubjectName;
                    subjectVM.SubjectDescription = subject.SubjectDescription;

                    myTutorSubjectsToReturn.Add(subjectVM);
                }

                return Ok(myTutorSubjectsToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetSubjectsLinkedToTutor/{tutorId}")]

        public async Task<IActionResult> GetSubjectsLinkedToTutor(int tutorId)
        {
            try
            {

                var myTutorSubjects = await _subTutorRepository.FindByListConditionAsync(r => r.TutorId == tutorId);
                var myTutorSubjectsToReturn = new List<SubjectVM>();

                foreach (var myTutorSubject in myTutorSubjects)
                {
                    var subject = await _subjectRepository.GetByIdAsync(myTutorSubject.SubjectId);
                    SubjectVM subjectVM = new SubjectVM();
                    subjectVM.subTutorId = myTutorSubject.Id;
                    subjectVM.SubjectName = subject.SubjectName;
                    subjectVM.SubjectDescription = subject.SubjectDescription;

                    myTutorSubjectsToReturn.Add(subjectVM);
                }

                return Ok(myTutorSubjectsToReturn);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPost]
        [Route("AddTutorByAdmin/{tutorApplicationId}")]
        public async Task<IActionResult> AddTutorByAdmin(int tutorApplicationId)
        {

            try
            {
                
                var tutorapplicationinfo = await _tutorApplicationRepository.GetTutorApplicationAsync(tutorApplicationId);
                //return Ok(tutorapplicationinfo);

                Tutors newTutor = new Tutors
                {
                    Title = null,
                    TutorName = tutorapplicationinfo.TutorApplicationName,
                    TutorSurname = tutorapplicationinfo.TutorApplicationSurname,
                    TutorPhoneNumber = tutorapplicationinfo.TutorApplicationPhoneNumber,
                    TutorEmail = tutorapplicationinfo.TutorApplicationEmail,
                    TutorApplicationId = tutorapplicationinfo.TutorApplicationId,
                    TutorImage = null,
                    TutorIdNumber = null,
                    TutorAddress = null,
                    TutorCity = null,
                    TutorPostalCode = null,
                    TutorProvince = null,
                    TutorTypeId = null,
                    Date = DateTime.Now,


                };
                _tutorrepos.Add(newTutor);
                await _tutorrepos.SaveChangesAsync();
                return Ok(newTutor);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                    Console.WriteLine("Inner Exception: " + ex.InnerException.Message);
                }


                _logger.LogError(ex, errorMessage);


                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
        }

        [HttpPost]
        [Route("AddTutor/{tutorApplicationId}")]
        public async Task<IActionResult> AddTutor(int tutorApplicationId, [FromForm] IFormCollection formData)
        {
            try
            {

                var userExists = await _userManager.FindByEmailAsync(formData["TutorEmail"]);

                if (userExists == null)
                {
                    _logger.LogInformation("User is not registered - Email does not exists: {Email}", formData["TutorEmail"]);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
                }

                Tutors tutVar = new Tutors
                {
                    Title = formData["Title"],
                    TutorName = formData["TutorName"],
                    TutorSurname = formData["TutorSurname"],
                    TutorAddress = formData["TutorAddress"],
                    TutorCity = formData["TutorCity"],
                    TutorProvince = formData["TutorProvince"],
                    TutorPostalCode = formData["TutorPostalCode"],
                    TutorEmail = formData["TutorEmail"],
                    TutorPhoneNumber = formData["TutorPhoneNumber"],
                    TutorIdNumber = formData["TutorIdNumber"],
                    TutorImage = "No Image",
                    TutorTypeId = Convert.ToInt32(formData["TutorType"]),
                    TutorApplicationId = tutorApplicationId,


                };
                _appDbContext.Add(tutVar);
                await _appDbContext.SaveChangesAsync();

                return Ok(tutVar);

            }

            //var tutorVar = new Tutors
            //{
            //    Title = formData["Title"],
            //    TutorName = formData["TutorName"],
            //    TutorSurname = formData["TutorSurname"],
            //    TutorAddress = formData["TutorAddress"],
            //    TutorCity = formData["TutorCity"],
            //    TutorProvince = formData["TutorProvince"],
            //    TutorPostalCode = formData["TutorPostalCode"],
            //    TutorEmail = formData["TutorEmail"],
            //    TutorPhoneNumber = formData["TutorPhoneNumber"],
            //    TutorIdNumber = formData["TutorIdNumber"],
            //    TutorImage = "No Image",
            //    TutorTypeId = Convert.ToInt32(formData["TutorType"]),
            //    TutorApplicationId = tutorApplicationId
            //};
            //try
            //{

            //    var userExists = await _userManager.FindByEmailAsync(formData["TutorEmail"]);

            //    if (userExists == null)
            //    {
            //        _logger.LogInformation("User is not registered - Email does not exists: {Email}", tutorVar.TutorEmail);
            //        return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
            //    }
            //    else
            //    {

            //        _tutorrepos.Add(tutorVar);
            //        await _tutorrepos.SaveChangesAsync();
            //    }

            //}
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (errorMessage != null)
                {
                    errorMessage += " Inner exception: " + ex.InnerException.Message;
                }

                _logger.LogError(ex, errorMessage);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }

        }

        [HttpPut]
        [Route("UpdateTutor/{TutorId}")]
        public async Task<IActionResult> UpdateTutor(int TutorId, [FromForm] IFormCollection formData)
        {
            try
            {   
                var existingTutor = await _tutorrepos.GetTutorProfileAsync(TutorId);
                if (existingTutor == null) return NotFound("This Tutor does not exist");

                

                var userExists = await _userManager.FindByEmailAsync(existingTutor.TutorEmail);
                if (userExists == null)
                {
                    _logger.LogInformation("User is not registered - Email does not exists: {Email}", existingTutor.TutorEmail);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
                }

                existingTutor.userId = userExists.Id;
                existingTutor.Title = formData["title"];
                existingTutor.TutorName = formData["tutorName"];
                existingTutor.TutorSurname = formData["tutorSurname"];
                existingTutor.TutorEmail = formData["tutorEmail"];
                existingTutor.TutorPhoneNumber = formData["tutorPhoneNumber"];
                existingTutor.TutorAddress = formData["tutorAddress"];
                existingTutor.TutorCity = formData["tutorCity"];
                existingTutor.TutorProvince = formData["tutorProvince"];
                existingTutor.TutorPostalCode = formData["tutorPostalCode"];
                existingTutor.TutorImage = existingTutor.TutorImage;
                existingTutor.TutorIdNumber = formData["tutorIdNumber"];
                existingTutor.TutorTypeId = Convert.ToInt32(formData["tutorType"]);

                userExists.Email = formData["tutorEmail"];
                userExists.UserName = formData["tutorEmail"];
                userExists.NormalizedUserName = userExists.UserName.ToUpper();
                userExists.NormalizedEmail = userExists.Email.ToUpper();

                if (await _tutorrepos.SaveChangesAsync())
                {
                    return Ok(existingTutor);
                }
            }
            catch (Exception ex)
            {

                var errorMessage = ex.Message;
                if (errorMessage != null)
                {
                    errorMessage += " Inner exception: " + ex.InnerException.Message;
                }

                _logger.LogError(ex, errorMessage);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
            return BadRequest("Your request is invalid");
        }


        [HttpGet]
        [Route("TutorTypes")]
        public async Task<ActionResult> TutorTypes()
        {
            try
            {
                var results = await _tutorrepos.GetTutorTypesAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }

        }

        [HttpGet]
        [Route("GetTutorApplication/{tutorApplicationId}")]
        public async Task<IActionResult> GetTutorApplication(int tutorApplicationId)
        {
            try
            {
                var tutorapp = await _tutorrepos.GetTutorApplicationAsync(tutorApplicationId);

                if (tutorapp == null)
                {
                    return NotFound();
                }

                var result = new
                {
                    tutorapp.TutorApplicationName,
                    tutorapp.TutorApplicationSurname,
                    tutorapp.TutorApplicationPhoneNumber,
                    tutorapp.TutorApplicationEmail,
                    tutorapp.TutorApplicationId,

                };

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetTutor/{tutorApplicationId}")]
        public async Task<IActionResult> GetTutor(int tutorApplicationId)
        {
            try
            {
                var tutor = await _tutorrepos.GetTutorFromTutorApplicationAsync(tutorApplicationId);

                if (tutor == null)
                {
                    return NotFound();
                }

                var result = new
                {
                    tutor.Id,
                    tutor.Title,
                    tutor.TutorName,
                    tutor.TutorSurname,
                    tutor.TutorEmail,
                    tutor.TutorApplicationId,
                    tutor.TutorPhoneNumber,
                    tutor.TutorIdNumber,
                    tutor.TutorAddress,
                    tutor.TutorCity,
                    tutor.TutorProvince,
                    tutor.TutorPostalCode,
                    tutor.TutorTypeId

                };

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetTutorById/{tutorId}")]
        public async Task<IActionResult> GetTutorById(int tutorId)
        {
            try
            {
                var tutor = await _tutorrepos.GetTutorById(tutorId);
                if (tutor == null)
                {
                    return NotFound();
                }

                var result = new
                {
                    tutor.Id,
                    tutor.TutorName,
                    tutor.TutorSurname,
                    tutor.TutorEmail,
                    tutor.TutorApplicationId,
                    tutor.TutorPhoneNumber,
                    tutor.TutorIdNumber,
                    tutor.TutorAddress,
                    tutor.TutorCity,
                    tutor.TutorProvince,
                    tutor.TutorPostalCode,
                    tutor.TutorTypeId

                };

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetTutorProfile/{tutorEmail}")]
        public async Task<IActionResult> GetTutorProfile(string tutorEmail)
        {
            try
            {
                var tutor = await _tutorrepos.GetTutorProfileAsync(tutorEmail);
                if (tutor == null)
                {
                    return NotFound();
                }

                var result = new
                {
                    tutor.Id,
                    tutor.TutorName,
                    tutor.TutorSurname,
                    tutor.TutorEmail,
                    tutor.TutorApplicationId,
                    tutor.TutorPhoneNumber,
                    tutor.TutorIdNumber,
                    tutor.TutorAddress,
                    tutor.TutorCity,
                    tutor.TutorProvince,
                    tutor.TutorPostalCode,
                    tutor.TutorTypeId

                };

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetAllTutors")]
        public async Task<IActionResult> GetAllTutors()
        {
            try
            {
                var results = await _tutorrepos.GetAllTutorsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpDelete]
        [Route("DeleteTutor/{TutorId}")]
        public async Task<IActionResult> DeleteTutorAsync(int TutorId)
        {
            try
            {
                var existingTutor = await _tutorrepos.GetTutorProfileAsync(TutorId);
                var booking = await _bookingRepository.GetAllAsync();

                var tutlist = new List<TutorAvailability>();

                foreach(var book in booking)
                {
                    var t = await _tutorAvailabilityRepository.GetByIdAsync(book.TutorAvailabiltyId);
                    tutlist.Add(t);
                    
                    

                }

                foreach(var y in tutlist) 
                { 
                 if(TutorId == y.TutorId)
                    {
                        return StatusCode(401,"Cannot be deleted");
                    }
                }
                
               

                if (existingTutor == null) return NotFound($"The tutor does not exist");
                
                //var useridx = existingTutor.userId;
               

                
                _tutorrepos.Delete(existingTutor);

                if (await _tutorrepos.SaveChangesAsync()) return Ok(existingTutor);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CountTutors")]
        public async Task<IActionResult> CountTutors()
        {
            try
            {
                int num = await _appDbContext.Tutors.CountAsync();

                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CountStudents")]
        public async Task<IActionResult> CountStudents()
        {
            try
            {
                int num = await _appDbContext.Students.CountAsync();

                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CountAdmins")]
        public async Task<IActionResult> CountAdmins()
        {
            try
            {
                int num = await _appDbContext.Admins.CountAsync();

                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CountFulltime")]
        public async Task<IActionResult> CountFulltime()
        {
            try
            {
                var results = await _tutorrepos.GetFullTimeTutorsAsync();

                int num = results.Count();


                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("CountParttime")]
        public async Task<IActionResult> CountParttime()
        {
            try
            {
                var results = await _tutorrepos.GetPartTimeTutorsAsync();

                int num = results.Count();


                return Ok(new { Count = num });

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }



    }
}
