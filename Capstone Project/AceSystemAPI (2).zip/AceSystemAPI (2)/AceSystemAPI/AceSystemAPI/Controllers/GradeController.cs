﻿
using AceSystemAPI.Models;
using AceSystemAPI.Models.Booking;
using AceSystemAPI.Models.Interfaces;
using AceSystemAPI.Models.ViewModels;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Routing;
using Microsoft.VisualBasic;
using System.Security.Cryptography.Xml;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class GradeController : ControllerBase
    {
        private readonly IRepository<Grade> _db;
        private readonly IRepository<Tutors> _tutors;
        private readonly IRepository<TutorGrade> _tutorGrades;


        public GradeController(IRepository<Grade> db, IRepository<Tutors> tutors, IRepository<TutorGrade> tutorsGrades)
        {
            _db = db;
            _tutors = tutors;
            _tutorGrades = tutorsGrades;
        }

        //get all CompanyAvailability
        [HttpGet("GetAllGrades")]
        public async Task<IActionResult> GetAllGrades()
        {
            var grades = await _db.GetAllAsync();
            return Ok(grades);
        }

        [HttpGet("GetGradeById/{gradeid}")]
        public async Task<IActionResult> GetGradeById(int gradeid)
        {
            try
            {
                var grade = await _db.GetByIdAsync(gradeid);

                if (grade == null)
                {
                    return NotFound();
                }
                var result = new
                {
                    grade.Id,
                    grade.gradeName
                };

                return Ok(result);


            }
            catch (Exception ex)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetAllGradesforTutor/{id}")]
        public async Task<IActionResult> getAllGradesforTutor(int id)
        {
            try
            {
                var myTutorGrades = await _tutorGrades.GetAllAsync();
                var myGrades = await _db.GetAllAsync();

                var gradeList = new List<int>();
                var gradeNum = new List<int>();
                var myTutorGradesToReturn = new List<int>();

                var returnedGradeList = new List<Grade>();
                var returnedTutorGradeList = new List<TutorGrade>();

                foreach (var tutorGrade in myTutorGrades)
                {
                    if (tutorGrade.TutorId == id)
                    {
                        gradeNum.Add(tutorGrade.GradeId);
                    }
                }

                foreach (var grade in myGrades)
                {
                    gradeList.Add(grade.Id);

                }


                foreach (var gradeId in gradeList)
                {
                    foreach (var grade in gradeNum)
                    {
                        if (gradeId == grade)
                        {
                            myTutorGradesToReturn.Add(gradeId);
                        }


                    }

                }

                foreach (var gradeName in myTutorGradesToReturn)
                {
                    foreach (var gradeId in myGrades)
                    {
                        if (gradeId.Id == gradeName)
                        {
                            var gradeObj = new Grade();
                            gradeObj.Id = gradeId.Id;
                            gradeObj.gradeName = gradeId.gradeName;

                            var tutorGradeObj = new TutorGrade();
                            tutorGradeObj.GradeId = gradeId.Id;
                            tutorGradeObj.TutorId = id;

                            returnedGradeList.Add(gradeObj);
                            returnedTutorGradeList.Add(tutorGradeObj);
                        }
                    }

                }
                return Ok(returnedGradeList);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPost("AddTutorGrades")]

        public async Task<ActionResult> AddTutorGrades([FromBody] TutorGradeViewModel tutorGradeVM)
        {
            try
            {
                if (tutorGradeVM == null)
                {
                    return BadRequest("Tutor Grade object is null");
                }

                if (!ModelState.IsValid)
                {
                    return BadRequest("Invalid model object");
                }
                var tutorgrades = new List<TutorGrade>();

                foreach (var grade in tutorGradeVM.Grades)
                {
                    var tutorGradeToAdd = new TutorGrade()
                    {
                        TutorId = tutorGradeVM.TutorId,
                        GradeId = grade,



                    };
                    _tutorGrades.Add(tutorGradeToAdd);
                }
                _tutorGrades.SaveChanges();

                return Ok();



            }
            catch (Exception c)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetGradeName/{id}")]
        public async Task<IActionResult> GetGradeName(int id)
        {
            try
            {
                var myTutorGrades = await _tutorGrades.GetAllAsync();
                var myTGrades = await _db.GetAllAsync();
                var gradeNum = new List<int>();
                var myTutorGradesToReturn = new List<string>();

                foreach (var tutorGrade in myTutorGrades)
                {
                    if (tutorGrade.TutorId == id)
                    {
                        gradeNum.Add(tutorGrade.GradeId);
                    }
                }

                foreach (var grade in gradeNum)
                {
                    foreach (var gradeId in myTGrades)
                    {
                        if (gradeId.Id == grade)
                        {
                            myTutorGradesToReturn.Add(gradeId.gradeName);
                        }
                    }
                }
                return Ok(myTutorGradesToReturn);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


        [HttpGet("GetGradesforTutorThatTheyCanAdd/{id}")]
        public async Task<IActionResult> getAllGradesforTutorThatTheyCanAdd(int id)
        {
            try
            {


                var myTutorGrades = await _tutorGrades.GetAllAsync();
                var myGrades = await _db.GetAllAsync();

                var gradeList = new List<int>();
                var gradeNum = new List<int>();
                var myTutorGradesToReturn = new List<int>();

                var returnedGradeList = new List<Grade>();


                foreach (var tutorGrade in myTutorGrades)
                {
                    if (tutorGrade.TutorId == id)
                    {
                        gradeNum.Add(tutorGrade.GradeId);
                    }
                }

                foreach (var grade in myGrades)
                {
                    gradeList.Add(grade.Id);
                    myTutorGradesToReturn.Add(grade.Id);
                }


                foreach (var gradeId in gradeList)
                {
                    foreach (var grade in gradeNum)
                    {
                        if (gradeId == grade)
                        {
                            myTutorGradesToReturn.Remove(gradeId);
                        }


                    }

                }

                foreach (var gradeName in myTutorGradesToReturn)
                {
                    foreach (var gradeId in myGrades)
                    {
                        if (gradeId.Id == gradeName)
                        {
                            var gradeObj = new Grade();
                            gradeObj.Id = gradeId.Id;
                            gradeObj.gradeName = gradeId.gradeName;




                            returnedGradeList.Add(gradeObj);
                        }
                    }

                }
                return Ok(returnedGradeList);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


        [HttpDelete]
        [Route("DeleteTutorGrade/{tutorId, gradeId}")]
        public async Task<IActionResult> DeleteTutorGradeAsync(int tutorId, int gradeId)
        {
            try
            {
                //var existingTutor = await _tutors.GetByIdAsync(tutorId);

                var TutorGradeList = await _tutorGrades.GetAllAsync();
                var smallerList = new List<TutorGrade>();

                var removedList = new List<TutorGrade>();

                var UpdatedList = await _tutorGrades.GetAllAsync(); ;



                foreach (var tutorgrade in TutorGradeList)
                {
                    var t = new TutorGrade();
                    t.Id = tutorgrade.Id;
                    t.TutorId = tutorId;
                    t.GradeId = gradeId;

                    smallerList.Add(t);
                }


                var idNum = 0;

                foreach (var tutorGrade in smallerList)
                {
                    if (tutorGrade.TutorId == tutorId && tutorGrade.GradeId == gradeId)
                    {
                        var id = tutorGrade.Id;
                        idNum = id;

                        var existingTutorGrade = await _tutorGrades.GetByIdAsync(idNum);
                        if (existingTutorGrade == null) return NotFound($"The grade does not exist");

                        _tutorGrades.Remove(existingTutorGrade);
                        smallerList.Remove(existingTutorGrade);

                        if (await _tutorGrades.SaveChangesAsync()) return Ok(existingTutorGrade);
                    }
                }








            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet("GetTutorGrade/{id}")]
        public async Task<IActionResult> GetTutorGrade(int id)
        {
            try
            {
                var myTutorGrades = await _tutorGrades.GetAllAsync();
                var returnedTutorGrade = new TutorGrade();



                foreach (var tutorGrade in myTutorGrades)
                {
                    if (tutorGrade.Id == id)
                    {
                        returnedTutorGrade.Id = tutorGrade.Id;
                        returnedTutorGrade.GradeId = tutorGrade.GradeId;
                        returnedTutorGrade.TutorId = tutorGrade.TutorId;

                    }
                }

                return Ok(returnedTutorGrade);




            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet("GetTutorGradefromGradeId/{id}")]
        public async Task<IActionResult> GetTutorGradefromGradeId(int id)
        {
            try
            {
                var myTutorGrades = await _tutorGrades.GetAllAsync();
                var returnedTutorGrade = new TutorGrade();



                foreach (var tutorGrade in myTutorGrades)
                {
                    if (tutorGrade.GradeId == id)
                    {
                        returnedTutorGrade.Id = tutorGrade.Id;
                        returnedTutorGrade.GradeId = tutorGrade.GradeId;
                        returnedTutorGrade.TutorId = tutorGrade.TutorId;

                    }
                }

                return Ok(returnedTutorGrade);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }


    }
}
