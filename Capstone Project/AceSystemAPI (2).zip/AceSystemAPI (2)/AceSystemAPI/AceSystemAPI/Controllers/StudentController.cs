﻿using AceSystemAPI.Auth;
using AceSystemAPI.Models;
using AceSystemAPI.Models.Booking;
using AceSystemBackend.ViewModels;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentController : ControllerBase
    {
        private readonly IStudentRepository _appDbContext;
        private readonly ILogger<StudentController> _logger;
        private readonly UserManager<IdentityUser> _userManager;// add this
        private readonly AppDbContext _appDb;
        public StudentController(IStudentRepository appDbContext, ILogger<StudentController> logger, UserManager<IdentityUser> userManager, AppDbContext appDb)
        {
            _appDbContext = appDbContext;
            _logger = logger;
            _userManager = userManager;
            _appDb = appDb;
        }


        //Get all student

        [HttpGet]
        [Route("GetAllStudents")]
        public async Task<IActionResult> GetAllStudents()
        {
            try
            {
                var results = await _appDbContext.GetAllStudentsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        //Get student
        [HttpGet]
        [Route("GetStudent/{studentId}")]
        public async Task<IActionResult> GetStudentAsync(int studentId)
        {
          
            try
            {
                var student = await _appDbContext.GetStudentAsync(studentId);

                if (student == null)
                {
                    return NotFound(); // Return 404 Not Found if student not found
                }

                var result = new
                {
                    student.Id,
                    student.StudentName,
                    student.StudentSurname,
                    student.StudentPhoneNumber,
                    student.StudentEmail,
                    student.Grade,
                    //student.Subject,
                    student.DateOfBirth,
                    student.StudentAge,
                    //student.StudentImage,
                    student.ParentTitle,
                    student.ParentName,
                    student.ParentSurname,
                    student.ParentPhoneNumber,
                    student.ParentEmail,
                    student.StudentProvince,
                    student.StudentCity,
                    student.StudentAddress,
                    student.StudentPostalCode,


                };

                return Ok(result);
            }
            catch (Exception)
            {
                return StatusCode(StatusCodes.Status500InternalServerError, "Internal Server Error. Please contact support.");
            }
        }


        //Add student

        [HttpPost]
        [Route("AddStudent")]
        public async Task<IActionResult> AddStudentAsync(StudentViewModel student)
        {
   
            var user = await _userManager.FindByEmailAsync(student.studentEmail);
            try
            {
                // what i added
                var userExists = await _userManager.FindByEmailAsync(student.studentEmail);
                if (userExists == null)
                {
                    _logger.LogInformation("User is not registered - Email does not exists: {Email}", student.studentEmail);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
                }

                Student newStudent = new Student
                {
                    StudentName = student.studentName,
                    StudentSurname = student.studentSurname,
                    StudentPhoneNumber = student.studentPhoneNumber,
                    StudentEmail = student.studentEmail,
                    Grade = student.grade,
                    //Subject = student.subject,
                    DateOfBirth = student.dateOfBirth,
                    StudentAge = student.studentAge,
                    //StudentImage = student.studentImage,
                    ParentTitle = student.parentTitle,
                    ParentName = student.parentName,
                    ParentSurname = student.parentSurname,
                    ParentPhoneNumber = student.parentPhoneNumber,
                    ParentEmail = student.parentEmail,
                    StudentProvince = student.studentProvince,
                    StudentCity = student.studentCity,
                    StudentAddress = student.studentAddress,
                    StudentPostalCode = student.studentPostalCode,
                    userId = user.Id



                };
                _appDbContext.Add(newStudent);
                await _appDbContext.SaveChangesAsync();

                return Ok(newStudent);
            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (ex.InnerException != null)
                {
                    errorMessage += " Inner Exception: " + ex.InnerException.Message;
                }


                _logger.LogError(ex, errorMessage);


                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
        }


        [HttpPut]
        [Route("EditStudent/{studentId}")]
        public async Task<ActionResult<StudentViewModel>> EditStudent(int studentId, StudentViewModel studentModel)
        {
            try
            {

              

                var existingStudent = await _appDbContext.GetStudentAsync(studentId);
                if (existingStudent == null) return NotFound($"The student does not exist");

                // what i added

                var userExists = await _userManager.FindByEmailAsync(existingStudent.StudentEmail);
                if (userExists == null)
                {
                    _logger.LogInformation("User is not registered - Email does not exists: {Email}", existingStudent.StudentEmail);
                    return StatusCode(StatusCodes.Status500InternalServerError, new Response { Status = "Error", Message = "User is not registered " });
                }

                existingStudent.StudentName = studentModel.studentName;
                existingStudent.StudentSurname = studentModel.studentSurname;
                existingStudent.StudentPhoneNumber = studentModel.studentPhoneNumber;
                existingStudent.StudentEmail = studentModel.studentEmail;
                // what i added
                userExists.Email = studentModel.studentEmail;// Update users table
                userExists.UserName = studentModel.studentEmail;
                userExists.NormalizedUserName = studentModel.studentEmail.ToUpper();
                userExists.NormalizedEmail = studentModel.studentEmail.ToUpper();
                existingStudent.Grade = studentModel.grade;
                //existingStudent.Subject = studentModel.subject;
                existingStudent.DateOfBirth = studentModel.dateOfBirth;
                existingStudent.StudentAge = studentModel.studentAge;
                //existingStudent.StudentImage = studentModel.studentImage;
                existingStudent.ParentTitle = studentModel.parentTitle;
                existingStudent.ParentName = studentModel.parentName;
                existingStudent.ParentSurname = studentModel.parentSurname;
                existingStudent.ParentPhoneNumber = studentModel.parentPhoneNumber;
                existingStudent.ParentEmail = studentModel.parentEmail;
                existingStudent.StudentProvince = studentModel.studentProvince;
                existingStudent.StudentCity = studentModel.studentCity;
                existingStudent.StudentAddress = studentModel.studentAddress;
                existingStudent.StudentPostalCode = studentModel.studentPostalCode;



                if (await _appDbContext.SaveChangesAsync())
                {
                    return Ok(existingStudent);
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }



        [HttpGet]
        [Route("CountStudents")]
        public async Task<IActionResult> CountStudents()
        {
            try
            {
                int num = await _appDb.Students.CountAsync();
                return Ok(new { Count = num });
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error, Please contact support");
            }
            return BadRequest("Your request in invalid ");
        }

    }
}
