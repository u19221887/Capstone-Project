﻿using AceSystemAPI.Models;
using AceSystemAPI.Models.Interfaces;
using AceSystemAPI.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TutorApplicationController : ControllerBase
    {
        private readonly ITutorApplicationRepository _tutorApplicationrepos;
        private readonly ILogger<DiscountController> _logger;
        private readonly IRepository<TutorGrade> _tutorGradeRepository;
        private readonly IRepository<TutorSubject> _tutorSubjectRepository;
        private readonly IRepository<Grade> _gradeRepository;
        private readonly IRepository<Subject> _subjectRepository;
        private readonly ITutorRepository _tutRepository;

        public TutorApplicationController(ITutorApplicationRepository tutorapplicationrepos, ILogger<DiscountController> logger, IRepository<TutorSubject> tutorSubjectRepository, IRepository<TutorGrade> tutorGradeRepository, IRepository<Grade> gradeRepository, IRepository<Subject> subjectRepository, ITutorRepository tutRepository)
        {
            _tutorApplicationrepos = tutorapplicationrepos;
            _logger = logger;
            _tutorSubjectRepository = tutorSubjectRepository;   
            _tutorGradeRepository = tutorGradeRepository;
            _subjectRepository = subjectRepository;
            _gradeRepository = gradeRepository;
            _tutRepository = tutRepository;
        }


        [HttpPost, DisableRequestSizeLimit]
        [Route("AddTutorApplication")]
        public async Task<IActionResult> AddTutorApplication([FromForm] IFormCollection formData)
        {

            try
            {
                var formCollection = await Request.ReadFormAsync();
                var file = formCollection.Files.First();

                if (file.Length > 0)
                {
                    using (var ms = new MemoryStream())
                    {
                        file.CopyTo(ms);
                        var fileBytes = ms.ToArray();
                        string base64 = Convert.ToBase64String(fileBytes);

                        var tutorApplication = new TutorApplication
                        {
                            TutorApplicationName = formData["name"],
                            TutorApplicationSurname = formData["lname"],
                            TutorApplicationEmail = formData["email"],
                            TutorApplicationPhoneNumber = formData["pnumber"],
                            Subject = formData["subject"],
                            Grade = formData["grade"],
                            TutorApplicationCV = base64,
                            TutorApplicationStatusId = 1
                        };

                        _tutorApplicationrepos.Add(tutorApplication);
                        await _tutorApplicationrepos.SaveChangesAsync();
                    }
                    return Ok();
                }
                else
                {
                    return BadRequest();
                }
            }
            catch (Exception ex)
            {
                return StatusCode(500, $"Internal server error: {ex}");
            }
        }

        [HttpDelete]
        [Route("DeleteTutorApplication/{TutorApplicationId}")]
        public async Task<IActionResult> DeleteTutorApplicationAsync(int TutorApplicationId)
        {
            try
            {
                var existingTA = await _tutorApplicationrepos.GetTutorApplicationAsync(TutorApplicationId);

                if (existingTA == null) return NotFound($"The application does not exist");

                _tutorApplicationrepos.Delete(existingTA);

                if (await _tutorApplicationrepos.SaveChangesAsync()) return Ok(existingTA);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }


        [HttpGet]
        [Route("GetAllTutorApplications")]
        public async Task<IActionResult> GetAllTutorApplicationsAsync()
        {
            try
            {
                var results = await _tutorApplicationrepos.GetAllTutorApplicationsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetPendingTutorApplications")]
        public async Task<IActionResult> GetPendingTutorApplicationsAsync()
        {
            try
            {
                var results = await _tutorApplicationrepos.GetPendingTutorApplicationsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetApprovedTutorApplications")]
        public async Task<IActionResult> GetApprovedTutorApplicationsAsync()
        {
            try
            {
                var results = await _tutorApplicationrepos.GetAcceptedTutorApplicationsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPatch]
        [Route("AcceptTutorApplication/{TutorApplicationId}")]
        public async Task<IActionResult> AcceptTutorApplication(int TutorApplicationId)
        {
            try
            {
                var existingTA = await _tutorApplicationrepos.GetTutorApplicationAsync(TutorApplicationId);
                if (existingTA == null) return NotFound("This application does not exist");


                existingTA.TutorApplicationStatusId = 2;

                if (await _tutorApplicationrepos.SaveChangesAsync())
                {
                    return Ok(existingTA);
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid");

        }

        [HttpPatch]
        [Route("RejectTutorApplication/{TutorApplicationId}")]
        public async Task<IActionResult> RejectTutorApplication(int TutorApplicationId)
        {
            try
            {
                var existingTA = await _tutorApplicationrepos.GetTutorApplicationAsync(TutorApplicationId);
                if (existingTA == null) return NotFound("This application does not exist");


                existingTA.TutorApplicationStatusId = 3;

                if (await _tutorApplicationrepos.SaveChangesAsync())
                {
                    return Ok(existingTA);
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid");

        }

        [HttpPost]
        [Route("AddInitialGradeAndSubject/{email}")]
        public async Task<IActionResult> AddInitialGradeAndSubject(string email)
        {
            var existinguser = await _tutorApplicationrepos.GetTutorApplicationAsyncByEmail(email);
            var tutprofile = await _tutRepository.GetTutorProfileAsync(email);
            return Ok(existinguser);




            try
            {

                var glist = await _gradeRepository.GetAllAsync();
                var sList = await _subjectRepository.GetAllAsync();
                var i = 0;
                var k = 0;

                foreach (var g in glist)
                {
                    if (existinguser.Grade == g.gradeName)
                    {
                        i = g.Id;
                        return Ok(g);
                    }
                }

                foreach (var s in sList)
                {
                    if (existinguser.Subject == s.SubjectName)
                    {
                        k = s.Id; 
                    }
                }

                var TutGrade = new TutorGrade
                {
                    TutorId = tutprofile.Id,
                    GradeId = i
                };
                _tutorGradeRepository.Add(TutGrade);
                _tutorGradeRepository.SaveChanges();

                var alltutggrades = await _tutorGradeRepository.GetAllAsync();
                var mytutgrade = new TutorGrade();

                foreach (var m in alltutggrades)
                {
                    if ((m.TutorId == tutprofile.Id) && (m.GradeId == i))
                    {
                        mytutgrade.Id = m.Id;
                        mytutgrade.TutorId = m.TutorId;
                        mytutgrade.GradeId = m.GradeId;
                    }
                }

                var TutSub = new TutorSubject
                {
                    TutorGradeId = mytutgrade.Id,
                    SubjectId = k

                };
                _tutorSubjectRepository.Add(TutSub);
                _tutorSubjectRepository.SaveChanges();




                return Ok("Added to both");

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid");
        }



    }

}
