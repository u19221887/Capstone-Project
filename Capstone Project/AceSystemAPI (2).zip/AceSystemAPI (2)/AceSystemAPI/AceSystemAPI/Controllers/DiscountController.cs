﻿using AceSystemAPI.Models;
using AceSystemAPI.ViewModels;
using AceSystemBackend.ViewModels;
using Microsoft.AspNetCore.Mvc;

namespace AceSystemAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DiscountController : ControllerBase
    {
        private readonly IDiscountRepository _discountrepos;
        private readonly ILogger<DiscountController> _logger;

        public DiscountController(IDiscountRepository discountrepos, ILogger<DiscountController> logger)
        {
            _discountrepos = discountrepos;
            _logger = logger;
        }

        [HttpPost]
        [Route("AddDiscount")]
        public async Task<IActionResult> AddDiscount([FromForm] IFormCollection formData)
        {
            var discountVar = new Discount
            {
                DiscountCode = formData["DiscountCode"],
                DiscountStartDate = Convert.ToDateTime(formData["DiscountStartDate"]),
                DiscountEndDate = Convert.ToDateTime(formData["DiscountEndDate"]),
                NumberOfSessions = Convert.ToInt16(formData["NumberOfSessions"]),
                DiscountStatusId = Convert.ToInt16(formData["DiscountStatus"]),
                DiscountPercentage = Convert.ToInt16(formData["DiscountPercentage"])

            };
            try
            {
                _discountrepos.Add(discountVar);
                await _discountrepos.SaveChangesAsync();

            }
            catch (Exception ex)
            {
                var errorMessage = ex.Message;
                if (errorMessage != null)
                {
                    errorMessage += " Inner exception: " + ex.InnerException.Message;
                }

                _logger.LogError(ex, errorMessage);
                return StatusCode(StatusCodes.Status500InternalServerError, ex.Message.ToString());
            }
            return Ok(discountVar);
        }

        [HttpDelete]
        [Route("DeleteDiscount/{DiscountId}")]
        public async Task<IActionResult> DeleteDiscountAsync(int DiscountId)
        {
            try
            {
                var existingDiscount = await _discountrepos.GetDiscountAsync(DiscountId);

                if (existingDiscount == null) return NotFound($"The discount does not exist");

                _discountrepos.Delete(existingDiscount);

                if (await _discountrepos.SaveChangesAsync()) return Ok(existingDiscount);

            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid.");
        }

        [HttpGet]
        [Route("GetActiveDiscounts")]
        public async Task<IActionResult> GetActiveDiscountsAsync()
        {
            try
            {
                var results = await _discountrepos.GetActiveDiscountsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetInactiveDiscounts")]
        public async Task<IActionResult> GetInactiveDiscountsAsync()
        {
            try
            {
                var results = await _discountrepos.GetInactiveDiscountsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpPut]
        [Route("UpdateDiscount/{discountId}")]
        public async Task<IActionResult> UpdateDiscount(int discountId, DiscountViewModel dvm)
        {
            try
            {
                var existingDiscount = await _discountrepos.GetDiscountAsync(discountId);
                if (existingDiscount == null) return NotFound("This Discount does not exist");

                existingDiscount.discountId = discountId;
                existingDiscount.DiscountCode = dvm.DiscountCode;
                existingDiscount.DiscountStartDate = dvm.DiscountStartDate;
                existingDiscount.DiscountEndDate = dvm.DiscountEndDate;
                existingDiscount.NumberOfSessions = dvm.NumberOfSessions;
                existingDiscount.DiscountStatusId = dvm.DiscountStatus;
                existingDiscount.DiscountPercentage = dvm.DiscountPercentage;

                if (await _discountrepos.SaveChangesAsync())
                {
                    return Ok(existingDiscount);
                }
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
            return BadRequest("Your request is invalid");
        }

        [HttpGet]
        [Route("GetAllDiscounts")]
        public async Task<IActionResult> GetAllDiscounts()
        {
            try
            {
                var results = await _discountrepos.GetAllDiscountsAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetDiscountStatuses")]
        public async Task<IActionResult> GetDiscountStatuses()
        {
            try
            {
                var results = await _discountrepos.GetDiscountStatusesAsync();
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

        [HttpGet]
        [Route("GetDiscount/{discountId}")]
        public async Task<IActionResult> GetDiscount(int discountId)
        {
            try
            {
                var results = await _discountrepos.GetDiscountAsync(discountId);
                return Ok(results);
            }
            catch (Exception)
            {
                return StatusCode(500, "Internal Server Error. Please contact support.");
            }
        }

    }
}
