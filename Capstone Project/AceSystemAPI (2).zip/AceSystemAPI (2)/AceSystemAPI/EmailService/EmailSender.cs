﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MimeKit;
using MailKit.Net.Smtp;

namespace EmailService
{
    public class EmailSender:IEmailSender
    {

        private readonly EmailConfiguration _emailConfig;


        public EmailSender(EmailConfiguration emailConfig)
        {
            _emailConfig = emailConfig;
        }
        public async Task SendTextWithAttachmentEmailAsync(Message message, string base64)
        {
            var emailMessage = CreateTextEmailMessageWithAttachment(message, base64);
            await SendAsync(emailMessage);
        }
        public async Task SendTextEmailAsync(Message message)
        {
            var emailMessage = CreateTextEmailMessage(message);
            await SendAsync(emailMessage);
        }

        public void SendEmail(Message message)
        {
            var emailMessage = CreateEmailMessage(message);
            Send(emailMessage);
        }

        public async Task SendEmailAsync(Message message)
        {
            var mailMessage = CreateEmailMessage(message);

            await SendAsync(mailMessage);
        }

        private MimeMessage CreateTextEmailMessageWithAttachment(Message message, string base64)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress(_emailConfig.From));
            emailMessage.To.AddRange(message.To);
            emailMessage.Subject = message.Subject;

            //var base64BinaryStr = base64;
            byte[] sPDFDecoded = Convert.FromBase64String(base64);
            var dir = AppDomain.CurrentDomain.BaseDirectory;
            File.WriteAllBytes(@$"{dir}\Prescription.png", sPDFDecoded);


            var builder = new BodyBuilder();
            builder.TextBody = "Hello";
            builder.Attachments.Add(@$"{dir}\Prescription.png");
            emailMessage.Body = builder.ToMessageBody();

            return emailMessage;
        }
        private MimeMessage CreateTextEmailMessage(Message message)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress(_emailConfig.From));
            emailMessage.To.AddRange(message.To);
            emailMessage.Subject = message.Subject;
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Text)
            {
                Text = message.Content
            };

            return emailMessage;
        }


        
        private MimeMessage CreateEmailMessage(Message message)
        {
            var emailMessage = new MimeMessage();
            emailMessage.From.Add(new MailboxAddress(_emailConfig.From));
            emailMessage.To.AddRange(message.To);
            emailMessage.Subject = message.Subject;
            emailMessage.Body = new TextPart(MimeKit.Text.TextFormat.Html)
            {
                Text = string.Format("<body>{0}</body>", message.Content)
            };

            return emailMessage;
        }

        private void Send(MimeMessage mailMessage)
        {
            using (var client = new SmtpClient())
            {
                try
                {
                    client.Connect(_emailConfig.SmtpServer, _emailConfig.Port, true);
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    client.Authenticate(_emailConfig.Email, _emailConfig.Password);

                    client.Send(mailMessage);
                }
                catch
                {

                    throw;
                }
                finally
                {
                    client.Disconnect(true);
                    client.Dispose();
                }
            }
        }
        
        private async Task SendAsync(MimeMessage mailMessage)
        {
            using (var client = new SmtpClient())
            {
                try
                {
                    await client.ConnectAsync(_emailConfig.SmtpServer, _emailConfig.Port, true);
                    client.AuthenticationMechanisms.Remove("XOAUTH2");
                    await client.AuthenticateAsync(_emailConfig.Email, _emailConfig.Password);

                    await client.SendAsync(mailMessage);
                }
                catch
                {

                    throw;
                }
                finally
                {
                    await client.DisconnectAsync(true);
                    client.Dispose();
                }
            }
        }
    }
}

