﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService
{
    public interface IEmailSender
    {
        void SendEmail(Message message);
        Task SendTextEmailAsync(Message message);
        Task SendEmailAsync(Message message);
        Task SendTextWithAttachmentEmailAsync(Message message, string base64);
    }
}
