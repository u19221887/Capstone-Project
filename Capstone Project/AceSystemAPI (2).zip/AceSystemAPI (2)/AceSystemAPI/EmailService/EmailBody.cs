﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmailService
{
    public static class EmailBody
    {

        //Build Html body for announcements
        public static string Announcement(string title, string content)
        {
            string dir = Environment.CurrentDirectory;
            string body = string.Empty;
            using (StreamReader reader = new StreamReader($"{dir}\\Assets/EmailTemplates/announcement.html"))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{title}", title);
            body = body.Replace("{content}", content);
            return body;
        }


        //Build Html body for VerificationCode
        public static string CreateBodyVerificationCode(string code)
        {
            string dir = Environment.CurrentDirectory;
            string body = string.Empty;
            using (StreamReader reader = new StreamReader($"{dir}\\Assets/EmailTemplates/verifyCode.html"))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{code}", code);
            return body;
        }

        //Build Html body for ConfirmEmail
        public static string CreateBodyConfirmEmail(string name, string link)
        {
            string dir = Environment.CurrentDirectory;
            string body = string.Empty;
            using (StreamReader reader = new StreamReader($"{dir}\\Assets/EmailTemplates/verifyemail.html"))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{mylink}", link);
            body = body.Replace("{name}", name);
            return body;
        }

        //Build Html body for forgot password email
        public static string CreateBodyForgotPassword(string name, string link)
        {
            string dir = Environment.CurrentDirectory;
            string body = string.Empty;
            using (StreamReader reader = new StreamReader($"{dir}\\Assets/EmailTemplates/forgotpassword.html"))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{link}", link);
            body = body.Replace("{name}", name);
            return body;
        }

        //Build Html body for tutor  email
        public static string CreateBodyTutor(string name, string link)
        {
            string dir = Environment.CurrentDirectory;
            string body = string.Empty;
            using (StreamReader reader = new StreamReader($"{dir}\\Assets/EmailTemplates/tutoracceptance.html"))
            {
                body = reader.ReadToEnd();
            }
            body = body.Replace("{link}", link);
            body = body.Replace("{name}", name);
            return body;
        }



        public static string Base64Encode(string plainText)
        {
            var plainTextBytes = System.Text.Encoding.UTF8.GetBytes(plainText);
            return System.Convert.ToBase64String(plainTextBytes);
        }

        public static string Base64Decode(string base64EncodedData)
        {
            var base64result = base64EncodedData.Substring(base64EncodedData.IndexOf(',') + 1);


            var base64EncodedBytes = System.Convert.FromBase64String(base64result);
            return System.Text.Encoding.UTF8.GetString(base64EncodedBytes);
        }


        public static string CreatePassword(int length)
        {
            const string valid = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ";
            const string symb = "!@#$%&*";
            const string digits = "1234567890";
            StringBuilder res = new StringBuilder();
            Random rnd = new Random();
            int stringpart = length / 2;
            while (0 < stringpart--)
            {
                res.Append(valid[rnd.Next(valid.Length)]);
            }
            res.Append(symb[rnd.Next(symb.Length)]);
            int digitspart = length / 2;
            while (0 < digitspart--)
            {
                res.Append(digits[rnd.Next(digits.Length)]);
            }

            return res.ToString();
        }
    }
}
