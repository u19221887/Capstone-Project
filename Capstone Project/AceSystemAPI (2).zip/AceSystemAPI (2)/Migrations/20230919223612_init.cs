﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace AceSystemAPI.Migrations
{
    public partial class init : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "3d701945-acb3-4096-903a-419c5dfd1052");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "50fb9f70-fd37-4a21-8ded-a80a50462594");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "78aad253-b45b-43b6-9970-4534403de627");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "e3178054-dc75-4865-bba7-38776bebb32d", "2", "Student", "Student" },
                    { "e4ef35f4-4a2e-401d-948b-b3a4be2f1fe3", "3", "Tutor", "Tutor" },
                    { "e5b01960-303f-4473-8370-29a02ff898d1", "1", "Admin", "Admin" }
                });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -12,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 20, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 19, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -11,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 19, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 18, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -10,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 18, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 17, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -9,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 17, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 16, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -8,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 16, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 15, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -7,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 15, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 14, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -6,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 14, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 13, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -5,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 13, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 12, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -4,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 12, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 11, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -3,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 11, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 10, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -2,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 10, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 9, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -1,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 20, 9, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 20, 8, 0, 0, 0, DateTimeKind.Local) });
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e3178054-dc75-4865-bba7-38776bebb32d");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e4ef35f4-4a2e-401d-948b-b3a4be2f1fe3");

            migrationBuilder.DeleteData(
                table: "AspNetRoles",
                keyColumn: "Id",
                keyValue: "e5b01960-303f-4473-8370-29a02ff898d1");

            migrationBuilder.InsertData(
                table: "AspNetRoles",
                columns: new[] { "Id", "ConcurrencyStamp", "Name", "NormalizedName" },
                values: new object[,]
                {
                    { "3d701945-acb3-4096-903a-419c5dfd1052", "2", "Student", "Student" },
                    { "50fb9f70-fd37-4a21-8ded-a80a50462594", "1", "Admin", "Admin" },
                    { "78aad253-b45b-43b6-9970-4534403de627", "3", "Tutor", "Tutor" }
                });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -12,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 20, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 19, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -11,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 19, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 18, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -10,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 18, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 17, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -9,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 17, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 16, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -8,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 16, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 15, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -7,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 15, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 14, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -6,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 14, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 13, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -5,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 13, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 12, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -4,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 12, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 11, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -3,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 11, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 10, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -2,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 10, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 9, 0, 0, 0, DateTimeKind.Local) });

            migrationBuilder.UpdateData(
                table: "CompanyAvailability",
                keyColumn: "Id",
                keyValue: -1,
                columns: new[] { "endTime", "startTime" },
                values: new object[] { new DateTime(2023, 9, 3, 9, 0, 0, 0, DateTimeKind.Local), new DateTime(2023, 9, 3, 8, 0, 0, 0, DateTimeKind.Local) });
        }
    }
}
