import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentLoginRegComponent } from './student-login-reg.component';

describe('StudentLoginRegComponent', () => {
  let component: StudentLoginRegComponent;
  let fixture: ComponentFixture<StudentLoginRegComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentLoginRegComponent]
    });
    fixture = TestBed.createComponent(StudentLoginRegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
