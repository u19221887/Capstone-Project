import { Component, OnInit, TemplateRef } from '@angular/core';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';

import { MatDialog } from '@angular/material/dialog';

import { StudentService } from 'src/app/services/student.service';
import { ActivatedRoute, Router } from '@angular/router';
import { Student } from 'src/app/shared/student';

import { MatSnackBar } from '@angular/material/snack-bar';

import { RegistrationEmailErrorComponent } from 'src/app/utilities/modals/registration-email-error/registration-email-error.component';
import { SuccessRegisterModelComponent } from 'src/app/utilities/modals/success-register-model/success-register-model.component';

@Component({
  selector: 'app-student-registration',
  templateUrl: './student-registration.component.html',
  styleUrls: ['./student-registration.component.scss'],
})
export class StudentRegistrationComponent implements OnInit {
  registration!: FormGroup;

  constructor(
    private formBuilder: FormBuilder,
    private dialog: MatDialog,
    private studentService: StudentService,
    private router: Router,
    private snackBar: MatSnackBar,
    private route: ActivatedRoute

  ) {}

  ngOnInit() {
    const email = this.route.snapshot.paramMap.get('email');

    this.registration = this.formBuilder.group({
      studentName: ['', Validators.required],
      parentTitle: ['', Validators.required],
      studentLastName: ['', Validators.required],
      parentName: ['', Validators.required],
      studentNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
      ]),
      parentLastName: ['', Validators.required],
      studentEmail: [email, [Validators.required, Validators.email]],
      parentNumber: new FormControl('', [
        Validators.required,
        Validators.minLength(10),
        Validators.maxLength(10),
      ]),
      grade: ['', Validators.required],
      parentEmail: ['', [Validators.required, Validators.email]],
      //subject: ['', Validators.required],
      province: ['', Validators.required],
      birthday: ['', Validators.required],
      city: ['', Validators.required],
      address: ['', Validators.required],
      postalCode: ['', Validators.required],
      age: ['', Validators.required],
    });
  }

  register(): void {
    //this.showSuccessModal();
    if (this.registration.valid) {
      let student = new Student();
      student.studentName = this.registration.value.studentName;
      student.parentTitle = this.registration.value.parentTitle;
      student.studentSurname = this.registration.value.studentLastName;
      student.parentName = this.registration.value.parentName;
      student.studentPhoneNumber = this.registration.value.studentNumber;
      student.studentEmail = this.registration.value.studentEmail;
      student.parentSurname = this.registration.value.parentLastName;
      student.parentPhoneNumber = this.registration.value.parentNumber;
      student.grade = this.registration.value.grade;
      student.parentEmail = this.registration.value.parentEmail;
      //student.subject = this.registration.value.subject;
      student.studentProvince = this.registration.value.province;
      student.dateOfBirth = this.registration.value.birthday;
      student.studentCity = this.registration.value.city;
      student.studentAddress = this.registration.value.address;
      student.studentPostalCode = this.registration.value.postalCode;
      student.studentAge = this.registration.value.age;

      this.studentService.addStudent(student).subscribe(
        (response: any) => {
          this.showSuccessModal();
          this.router.navigate(['/student-login']);
          console.log('Success:', response);
        },
        (error: any) => {
          if (error.status === 500) {
            this.registrationEmailError();
          } else {
            this.snackBar.open(`An error occurred: ${error.message}`, 'X', {
              duration: 5000,
            });
          }
        }
      );
    } else {
      this.validateAllFormFields(this.registration);
    }
  }

  showSuccessModal() {
    const dialogRef = this.dialog.open(SuccessRegisterModelComponent, {
      width: '700px',
      height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {
     // this.registration.reset();
    });
  }

  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });
  }

  registrationEmailError() {
    const dialogRef = this.dialog.open(RegistrationEmailErrorComponent, {
      width: '700px',
      height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {
      this.registration.reset();
    });
  }
  emailValidator(control: FormControl): { [key: string]: boolean } | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (control.value && !emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }

    return null;
  }

  maxLengthValidator(maxLength: number) {
    return (control: FormControl) => {
      if (control.value && control.value.length > maxLength) {
        return { maxlength: true };
      }
      return null;
    };
  }
}

// this.studentService.addStudent(student).subscribe((response: any) => {
//   if (response.statusCode == 200) {
//     this.router.navigate(['/']);
//   } else {
//     alert(response.message);
//   }
// });
// } else {
// this.validateAllFormFields(this.registration);
// }

//[routerLink]="'/student-login'" routerLinkActive="active"
