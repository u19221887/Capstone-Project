import { Component, OnInit } from '@angular/core';
import {
  FormBuilder,
  FormControl,
  FormGroup,
  Validators,
} from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { RegisterService } from 'src/app/services/register.service';
import { TutorService } from 'src/app/services/tutor.service';
import { Tutor } from 'src/app/shared/tutor';
import { TutorType } from 'src/app/shared/tutorType';
import { EditSuccessModalComponent } from 'src/app/utilities/modals/edit-success-modal/edit-success-modal.component';

@Component({
  selector: 'app-tutor-registration',
  templateUrl: './tutor-registration.component.html',
  styleUrls: ['./tutor-registration.component.scss'],
})
export class TutorRegistrationComponent implements OnInit {
  formsData = new FormData();
  tutorTypeData: TutorType[] =[]
  num : Number =0





  tutEmail : FormGroup = this.fb.group({
    email : ['',[Validators.required, Validators.email]]
  })


  registrationForm: FormGroup= this.fb.group({
    title : ['', Validators.required],
    tutorName : ['', Validators.required],
    tutorSurname : ['', Validators.required],
    tutorPhoneNumber : ['', Validators.required],
    tutorIdNumber : ['', Validators.required],
    tutorEmail : ['', Validators.required],
    tutorProvince : ['', Validators.required],
    tutorCity : ['', Validators.required],
    tutorAddress : ['', Validators.required],
    tutorPostalCode : ['', Validators.required],
    tutorType: [null, Validators.required],
    tutorApplicationId : 0

    
    


  })
  

  
  constructor(private apiService: APIService,private registerService: RegisterService, private tutorService: TutorService  ,private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute, private dialog: MatDialog){}
  tutorinfo: any
   
  temail? : any

  ngOnInit(): void {
    
    this.temail = this.route.snapshot.queryParams['email'];
    
    console.log("I MAKE IT TO HERE")
    
    this.apiService.getTutorProfile(this.temail).subscribe(result=>{
      this.tutorinfo = result
      console.log(this.tutorinfo)
      this.registrationForm.patchValue({
        tutorName: this.tutorinfo.tutorName,
        tutorSurname: this.tutorinfo.tutorSurname,
        tutorEmail: this.tutorinfo.tutorEmail,
        tutorPhoneNumber : this.tutorinfo.tutorPhoneNumber, 
        tutorApplicationId: this.tutorinfo.tutorApplicationId,

        
        
      });
       
      this.num= this.tutorinfo.id;
       console.log(this.num)

       
    })
    this.GetTutorTypes();
    
    
  }

  Tutor: any

  //tutAcc! : TutorAcceptance

  onSubmit(){
    console.log(this.num)

    
  
      
     
      if (this.registrationForm.valid)
          {
            this.formsData.append('title', this.registrationForm.get('title')!.value);
            this.formsData.append('tutorName', this.registrationForm.get('tutorName')!.value);
            this.formsData.append('tutorSurname', this.registrationForm.get('tutorSurname')!.value);
            this.formsData.append('tutorPhoneNumber', this.registrationForm.get('tutorPhoneNumber')!.value);
            this.formsData.append('tutorEmail', this.registrationForm.get('tutorEmail')!.value);
            this.formsData.append('tutorIdNumber', this.registrationForm.get('tutorIdNumber')!.value);
            this.formsData.append('tutorProvince', this.registrationForm.get('tutorProvince')!.value);
            this.formsData.append('tutorCity', this.registrationForm.get('tutorCity')!.value);
            this.formsData.append('tutorAddress', this.registrationForm.get('tutorAddress')!.value);
            this.formsData.append('tutorPostalCode', this.registrationForm.get('tutorPostalCode')!.value);
            this.formsData.append('tutorType', this.registrationForm.get('tutorType')!.value);


            

            console.log('Lets add it');
            console.log(this.num)
            console.log(this.formsData)
            this.apiService.editTutor(this.num, this.formsData).subscribe(()=> {
              this.addInitial(this.registrationForm.get('tutorEmail')!.value);
              this.clearData()
              this.router.navigate(['/user']).then((navigated:boolean)=>{
              this.UpdateModal();

            
          })})}


      
    
      

      


        
    }
           
    addInitial(email: string){
      this.apiService.addInitialGradeAndSubject(email).subscribe(()=>{
        console.log("added to both")
      })
      
      }

  clearData() {
    this.formsData.delete('Title');
    this.formsData.delete('TutorName');
    this.formsData.delete('TutorSurname');
    this.formsData.delete('TutorEmail');
    this.formsData.delete('TutorIdNumber');
    this.formsData.delete('TutorProvince');
    this.formsData.delete('TutorCity');
    this.formsData.delete('TutorAddress');
    this.formsData.delete('TutorPostalCode');
    this.formsData.delete('TutorType');
  }

  GetTutorTypes(){
    this.apiService.getTutorTypes().subscribe(result => {
      let tutorTypeList:any[] = result
      tutorTypeList.forEach((element) => {
        this.tutorTypeData.push(element)
      });

      
    });
  }

  sendEmail(email: string){
    this.registerService.tutorEmail(email).subscribe(()=>{
      this.snackBar.open('email sent')})
    }

    UpdateModal(){
      const dialogRef = this.dialog.open(EditSuccessModalComponent,{
        width: '700px',
        height: '400px',
        disableClose:true,
      });
    }
}
