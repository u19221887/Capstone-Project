import { Component, NgModule, OnInit } from '@angular/core';
import { ActivatedRoute, RouterModule } from '@angular/router';
import {
  FormBuilder,
  Validators,
  FormControl,
  FormGroup,
} from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { RegisterService } from 'src/app/services/register.service';
import { UserExistModalComponent } from 'src/app/utilities/modals/user-exist-modal/user-exist-modal.component';
import { ValidLoginModalComponent } from 'src/app/utilities/modals/valid-login-modal/valid-login-modal.component';
import { MatDialog } from '@angular/material/dialog';

@Component({
  selector: 'app-tutor-register',
  templateUrl: './tutor-register.component.html',
  styleUrls: ['./tutor-register.component.scss']
})
export class TutorRegisterComponent implements OnInit {

  showPassword: boolean = false;

  login!: FormGroup;
  renderer: any;

  constructor(
    private dialog: MatDialog,
    private formBuilder: FormBuilder,
    private router: Router,
    private registerService: RegisterService,
    private snackBar: MatSnackBar,

  ) {}
  ngOnInit() {
    this.login = this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
      password: [
        '',
        [
          Validators.required,
          Validators.minLength(6),

          this.passwordPatternValidator(),
        ],
      ],
    });
  }

  RegisterUser() {

    if (this.login.valid) {
      this.registerService.RegisterTutor(this.login.value).subscribe(
        () => {

          this.router
            .navigate(['/student-registration', this.login.value.email])

            .then((navigated: boolean) => {
              if (navigated) {
                this.router.navigate(['/login'])

              }
            });
        },
        (error: any) => {
          if (error.status === 500) {
            this.userExistModal();
          } else {
            this.snackBar.open(`An error occurred: ${error.message}`, 'X', {
              duration: 5000,
            });
          }
        }
      );
    }
  }

  emailValidator(control: FormControl): { [key: string]: boolean } | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (control.value && !emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }

    return null;
  }

  maxLengthValidator(maxLength: number) {
    return (control: FormControl) => {
      if (control.value && control.value.length > maxLength) {
        return { maxlength: true };
      }
      return null;
    };
  }

  onSubmit(): void {
    if (this.login.valid) {
      console.log(this.login.value);
    } else {
      this.validateAllFormFields(this.login);
    }
  }

  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach((field) => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });
  }

  passwordPatternValidator() {
    return (control: FormControl) => {
      const password = control.value;
      const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{6,}$/;

      if (passwordPattern.test(password)) {
        return null;
      } else {
        return { invalidPassword: true };
      }
    };
  }

  userExistModal() {
    const dialogRef = this.dialog.open(UserExistModalComponent, {
      width: '700px',
      height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {
      this.login.reset();
    });
  }

  validLoginModal() {
    const dialogRef = this.dialog.open(ValidLoginModalComponent, {
      width: '700px',
      height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {
      this.login.reset();
    });
  }
}
