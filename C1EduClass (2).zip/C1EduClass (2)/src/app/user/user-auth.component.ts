import { Component, NgModule, OnInit } from '@angular/core';
import { RouterModule } from '@angular/router';


@Component({
  selector: 'app-user',
  templateUrl: './user-auth.component.html',
  styleUrls: ['./user-auth.component.scss']
})

export class UserAuthComponent implements OnInit {

  constructor() {

  }
  ngOnInit(){

  }
}
