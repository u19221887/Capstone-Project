import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminLoginRegComponent } from './admin-login-reg.component';

describe('AdminLoginRegComponent', () => {
  let component: AdminLoginRegComponent;
  let fixture: ComponentFixture<AdminLoginRegComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminLoginRegComponent]
    });
    fixture = TestBed.createComponent(AdminLoginRegComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
