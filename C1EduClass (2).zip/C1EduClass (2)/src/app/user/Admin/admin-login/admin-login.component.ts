import { Component, NgModule, OnInit} from '@angular/core';
import { RouterModule } from '@angular/router';
import { FormBuilder,Validators,FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { LoginService } from 'src/app/services/login.service';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ForgotPasswordComponent } from 'src/app/utilities/modals/forgot-password/forgot-password.component';
import { MatDialog } from '@angular/material/dialog';
import { LoginModalComponent } from 'src/app/utilities/modals/login-modal/login-modal.component';
import { UnauthorizedAccessLoginComponent } from 'src/app/utilities/modals/unauthorized-access-login/unauthorized-access-login.component';



@Component({
  selector: 'app-admin-login',
  templateUrl: './admin-login.component.html',
  styleUrls: ['./admin-login.component.scss']
})
export class AdminLoginComponent implements OnInit{

  showPassword: boolean = false;

  login!: FormGroup;
  renderer: any;

  constructor(private formBuilder: FormBuilder, private router: Router, private loginService: LoginService,  private snackBar: MatSnackBar, private dialog: MatDialog)  {}

  ngOnInit(){

    this.login = this.formBuilder.group({

      email: ['', [Validators.required, Validators.email]],
      password: ['', [
        Validators.required,
        Validators.minLength(6),

        this.passwordPatternValidator()
      ]]
    });



  }


  LoginUser() {
    if (this.login.valid) {
      this.loginService.LoginAdmin(this.login.value).subscribe(
        result => {
          let o: any={
            username: this.login.value.email,
            token:result
          }
          localStorage.setItem('User', JSON.stringify(o));
          this.login.reset();
          this.loginModal();
          this.router.navigate(['/admin-dashboard']).then((navigated: boolean) => {
            if (navigated) {

            }
          });
        },
        (error: any) => {
          if (error.status === 401) {
            this.unauthorizedModal();}

            else {
              this.snackBar.open(`An error occurred: ${error.message}`, 'X', { duration: 5000 });
            }
          },
      );
    }
  }

  emailValidator(control: FormControl): { [key: string]: boolean } | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (control.value && !emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }

    return null;
  }

  maxLengthValidator(maxLength: number) {
    return (control: FormControl) => {
      if (control.value && control.value.length > maxLength) {
        return { maxlength: true };
      }
      return null;
    };
  }

  onSubmit(): void {
    if (this.login.valid) {

      console.log(this.login.value);

    } else {

      this.validateAllFormFields(this.login);
    }


  }

  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });


}

passwordPatternValidator() {
  return (control: FormControl) => {
    const password = control.value;
    const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{6,}$/;

    if (passwordPattern.test(password)) {
      return null;
    } else {
      return { invalidPassword: true };
    }
  };


}



forgotModal(): void {
  this.showSuccessModal();


}

showSuccessModal() {
  const dialogRef = this.dialog.open(ForgotPasswordComponent, {
    width: '700px',
  height: '300px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    this.login.reset();
  });
}


loginModal() {
  const dialogRef = this.dialog.open(LoginModalComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    this.login.reset();
  });
}

unauthorizedModal() {
  const dialogRef = this.dialog.open(UnauthorizedAccessLoginComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    this.login.reset();
  });
}


}
