import { Injectable, Injector } from '@angular/core';
import { HttpInterceptor, HttpHandler, HttpRequest } from '@angular/common/http';
import { TokenStorageService } from './TokenStorageService';

@Injectable()

export class TokenInterceptor implements HttpInterceptor {
  constructor(private tokenStorageService: TokenStorageService) { }
  intercept(req: HttpRequest<any>, next: HttpHandler) {
    //convert the token to a json object
    var obj  =  JSON.parse(this.tokenStorageService.getToken()!)?.token??{};
    const tokenizedReq = req.clone({
      setHeaders: {
        // eslint-disable-next-line @typescript-eslint/naming-convention
        Authorization: `Bearer ${obj.token}`
      }
    });
    return next.handle(tokenizedReq);
  }
}
