import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-unauthorized-access',
  templateUrl: './unauthorized-access.component.html',
  styleUrls: ['./unauthorized-access.component.scss']
})
export class UnauthorizedAccessComponent {


  constructor(public dialogRef: MatDialogRef<UnauthorizedAccessComponent>) { }

  close(): void {
    this.dialogRef.close();
  }
}