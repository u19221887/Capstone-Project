import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessfultutoremailComponent } from './successfultutoremail.component';

describe('SuccessfultutoremailComponent', () => {
  let component: SuccessfultutoremailComponent;
  let fixture: ComponentFixture<SuccessfultutoremailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuccessfultutoremailComponent]
    });
    fixture = TestBed.createComponent(SuccessfultutoremailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
