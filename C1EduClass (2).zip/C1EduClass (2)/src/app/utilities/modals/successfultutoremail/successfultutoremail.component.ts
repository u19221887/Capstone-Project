import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-successfultutoremail',
  templateUrl: './successfultutoremail.component.html',
  styleUrls: ['./successfultutoremail.component.scss']
})
export class SuccessfultutoremailComponent {
  constructor(public dialogRef: MatDialogRef<SuccessfultutoremailComponent>) { }

  close(): void {
    this.dialogRef.close();
  }
}
