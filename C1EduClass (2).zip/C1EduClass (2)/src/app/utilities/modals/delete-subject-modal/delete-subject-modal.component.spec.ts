import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteSubjectModalComponent } from './delete-subject-modal.component';

describe('DeleteSubjectModalComponent', () => {
  let component: DeleteSubjectModalComponent;
  let fixture: ComponentFixture<DeleteSubjectModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteSubjectModalComponent]
    });
    fixture = TestBed.createComponent(DeleteSubjectModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
