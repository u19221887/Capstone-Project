import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-subject-modal',
  templateUrl: './delete-subject-modal.component.html',
  styleUrls: ['./delete-subject-modal.component.scss']
})
export class DeleteSubjectModalComponent {

  constructor(public dialogRef: MatDialogRef<DeleteSubjectModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }


}
