import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-discount-modal',
  templateUrl: './delete-discount-modal.component.html',
  styleUrls: ['./delete-discount-modal.component.scss']
})
export class DeleteDiscountModalComponent {
  constructor(public dialogRef: MatDialogRef<DeleteDiscountModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
