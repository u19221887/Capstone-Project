import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessfulEmailUpdateComponent } from './successful-email-update.component';

describe('SuccessfulEmailUpdateComponent', () => {
  let component: SuccessfulEmailUpdateComponent;
  let fixture: ComponentFixture<SuccessfulEmailUpdateComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuccessfulEmailUpdateComponent]
    });
    fixture = TestBed.createComponent(SuccessfulEmailUpdateComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
