import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-successful-email-update',
  templateUrl: './successful-email-update.component.html',
  styleUrls: ['./successful-email-update.component.scss']
})
export class SuccessfulEmailUpdateComponent {


  constructor(public dialogRef: MatDialogRef<SuccessfulEmailUpdateComponent>) { }

  close(): void {
    this.dialogRef.close();
  }
}
