import { ComponentFixture, TestBed } from '@angular/core/testing';

import { RegistrationEmailErrorComponent } from './registration-email-error.component';

describe('RegistrationEmailErrorComponent', () => {
  let component: RegistrationEmailErrorComponent;
  let fixture: ComponentFixture<RegistrationEmailErrorComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [RegistrationEmailErrorComponent]
    });
    fixture = TestBed.createComponent(RegistrationEmailErrorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
