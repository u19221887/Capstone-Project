import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-registration-email-error',
  templateUrl: './registration-email-error.component.html',
  styleUrls: ['./registration-email-error.component.scss']
})
export class RegistrationEmailErrorComponent {


  constructor(public dialogRef: MatDialogRef<RegistrationEmailErrorComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
