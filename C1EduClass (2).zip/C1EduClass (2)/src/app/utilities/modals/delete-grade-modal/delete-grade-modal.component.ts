import { Component } from '@angular/core';

import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-grade-modal',
  templateUrl: './delete-grade-modal.component.html',
  styleUrls: ['./delete-grade-modal.component.scss']
})
export class DeleteGradeModalComponent {
  constructor(public dialogRef: MatDialogRef<DeleteGradeModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }
}
