import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteGradeModalComponent } from './delete-grade-modal.component';

describe('DeleteGradeModalComponent', () => {
  let component: DeleteGradeModalComponent;
  let fixture: ComponentFixture<DeleteGradeModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteGradeModalComponent]
    });
    fixture = TestBed.createComponent(DeleteGradeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
