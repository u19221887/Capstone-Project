import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-subject-modal',
  templateUrl: './add-subject-modal.component.html',
  styleUrls: ['./add-subject-modal.component.scss']
})
export class AddSubjectModalComponent {

  constructor(public dialogRef: MatDialogRef<AddSubjectModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
