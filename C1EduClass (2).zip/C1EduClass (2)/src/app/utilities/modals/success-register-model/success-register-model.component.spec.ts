import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessRegisterModelComponent } from './success-register-model.component';

describe('SuccessRegisterModelComponent', () => {
  let component: SuccessRegisterModelComponent;
  let fixture: ComponentFixture<SuccessRegisterModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuccessRegisterModelComponent]
    });
    fixture = TestBed.createComponent(SuccessRegisterModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
