import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-success-register-model',
  templateUrl: './success-register-model.component.html',
  styleUrls: ['./success-register-model.component.scss']
})
export class SuccessRegisterModelComponent {

  constructor(public dialogRef: MatDialogRef<SuccessRegisterModelComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
