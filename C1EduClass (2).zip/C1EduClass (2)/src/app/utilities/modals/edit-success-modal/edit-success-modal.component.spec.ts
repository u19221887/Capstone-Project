import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EditSuccessModalComponent } from './edit-success-modal.component';

describe('EditSuccessModalComponent', () => {
  let component: EditSuccessModalComponent;
  let fixture: ComponentFixture<EditSuccessModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EditSuccessModalComponent]
    });
    fixture = TestBed.createComponent(EditSuccessModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
