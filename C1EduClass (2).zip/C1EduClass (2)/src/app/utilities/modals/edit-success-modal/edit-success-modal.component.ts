import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-edit-success-modal',
  templateUrl: './edit-success-modal.component.html',
  styleUrls: ['./edit-success-modal.component.scss']
})
export class EditSuccessModalComponent {

  constructor(public dialogRef: MatDialogRef<EditSuccessModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
