import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-add-discount-modal',
  templateUrl: './add-discount-modal.component.html',
  styleUrls: ['./add-discount-modal.component.scss']
})
export class AddDiscountModalComponent {

  constructor(public dialogRef: MatDialogRef<AddDiscountModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }


}
