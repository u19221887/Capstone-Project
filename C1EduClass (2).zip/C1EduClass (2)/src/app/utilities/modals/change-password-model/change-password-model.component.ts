import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-change-password-model',
  templateUrl: './change-password-model.component.html',
  styleUrls: ['./change-password-model.component.scss']
})
export class ChangePasswordModelComponent {

  constructor(public dialogRef: MatDialogRef<ChangePasswordModelComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}

