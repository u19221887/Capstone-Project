import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';

@Component({
  selector: 'app-successful-booking',
  templateUrl: './successful-booking.component.html',
  styleUrls: ['./successful-booking.component.scss']
})
export class SuccessfulBookingComponent {

  constructor(public dialogRef: MatDialogRef<SuccessfulBookingComponent>, private router : Router) { }

  close(): void {
    this.dialogRef.close();
  }

  book(): void{

    this.router.navigate(['/student-dashboard/booking']);
    this.dialogRef.close();
  }

}
