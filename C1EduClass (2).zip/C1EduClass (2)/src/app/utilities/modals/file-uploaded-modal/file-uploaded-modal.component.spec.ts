import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileUploadedModalComponent } from './file-uploaded-modal.component';

describe('FileUploadedModalComponent', () => {
  let component: FileUploadedModalComponent;
  let fixture: ComponentFixture<FileUploadedModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FileUploadedModalComponent]
    });
    fixture = TestBed.createComponent(FileUploadedModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
