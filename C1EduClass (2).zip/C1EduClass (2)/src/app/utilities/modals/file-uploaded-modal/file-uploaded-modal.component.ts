import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-file-uploaded-modal',
  templateUrl: './file-uploaded-modal.component.html',
  styleUrls: ['./file-uploaded-modal.component.scss']
})
export class FileUploadedModalComponent {

  constructor(public dialogRef: MatDialogRef<FileUploadedModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
