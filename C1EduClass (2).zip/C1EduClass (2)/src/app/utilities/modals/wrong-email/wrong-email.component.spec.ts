import { ComponentFixture, TestBed } from '@angular/core/testing';

import { WrongEmailComponent } from './wrong-email.component';

describe('WrongEmailComponent', () => {
  let component: WrongEmailComponent;
  let fixture: ComponentFixture<WrongEmailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [WrongEmailComponent]
    });
    fixture = TestBed.createComponent(WrongEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
