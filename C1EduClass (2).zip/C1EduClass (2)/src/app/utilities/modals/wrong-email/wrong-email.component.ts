import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-wrong-email',
  templateUrl: './wrong-email.component.html',
  styleUrls: ['./wrong-email.component.scss']
})
export class WrongEmailComponent {

  constructor(public dialogRef: MatDialogRef<WrongEmailComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
