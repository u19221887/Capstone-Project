import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UnauthorizedAccessLoginComponent } from './unauthorized-access-login.component';

describe('UnauthorizedAccessLoginComponent', () => {
  let component: UnauthorizedAccessLoginComponent;
  let fixture: ComponentFixture<UnauthorizedAccessLoginComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UnauthorizedAccessLoginComponent]
    });
    fixture = TestBed.createComponent(UnauthorizedAccessLoginComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
