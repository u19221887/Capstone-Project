import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-unauthorized-access-login',
  templateUrl: './unauthorized-access-login.component.html',
  styleUrls: ['./unauthorized-access-login.component.scss']
})
export class UnauthorizedAccessLoginComponent {

  constructor(public dialogRef: MatDialogRef<UnauthorizedAccessLoginComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
