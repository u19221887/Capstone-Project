import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';


@Component({
  selector: 'app-add-grade-modal',
  templateUrl: './add-grade-modal.component.html',
  styleUrls: ['./add-grade-modal.component.scss']
})
export class AddGradeModalComponent {
  constructor(public dialogRef: MatDialogRef<AddGradeModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
