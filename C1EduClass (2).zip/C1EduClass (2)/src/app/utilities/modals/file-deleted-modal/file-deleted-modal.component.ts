import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-file-deleted-modal',
  templateUrl: './file-deleted-modal.component.html',
  styleUrls: ['./file-deleted-modal.component.scss']
})
export class FileDeletedModalComponent {


  constructor(public dialogRef: MatDialogRef<FileDeletedModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }
}
