import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FileDeletedModalComponent } from './file-deleted-modal.component';

describe('FileDeletedModalComponent', () => {
  let component: FileDeletedModalComponent;
  let fixture: ComponentFixture<FileDeletedModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FileDeletedModalComponent]
    });
    fixture = TestBed.createComponent(FileDeletedModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
