import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-update-student-model',
  templateUrl: './update-student-model.component.html',
  styleUrls: ['./update-student-model.component.scss']
})
export class UpdateStudentModelComponent {

  constructor(public dialogRef: MatDialogRef<UpdateStudentModelComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
