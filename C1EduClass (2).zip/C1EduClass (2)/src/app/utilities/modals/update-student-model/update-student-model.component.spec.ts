import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UpdateStudentModelComponent } from './update-student-model.component';

describe('UpdateStudentModelComponent', () => {
  let component: UpdateStudentModelComponent;
  let fixture: ComponentFixture<UpdateStudentModelComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UpdateStudentModelComponent]
    });
    fixture = TestBed.createComponent(UpdateStudentModelComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
