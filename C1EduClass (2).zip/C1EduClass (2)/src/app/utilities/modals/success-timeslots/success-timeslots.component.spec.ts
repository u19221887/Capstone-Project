import { ComponentFixture, TestBed } from '@angular/core/testing';

import { SuccessTimeslotsComponent } from './success-timeslots.component';

describe('SuccessTimeslotsComponent', () => {
  let component: SuccessTimeslotsComponent;
  let fixture: ComponentFixture<SuccessTimeslotsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [SuccessTimeslotsComponent]
    });
    fixture = TestBed.createComponent(SuccessTimeslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
