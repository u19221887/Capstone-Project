import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-success-timeslots',
  templateUrl: './success-timeslots.component.html',
  styleUrls: ['./success-timeslots.component.scss']
})
export class SuccessTimeslotsComponent {

  constructor(public dialogRef: MatDialogRef<SuccessTimeslotsComponent>) { }
  close(): void {
    this.dialogRef.close();
  }
}
