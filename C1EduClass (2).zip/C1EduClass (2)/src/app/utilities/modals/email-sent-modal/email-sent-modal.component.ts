import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-email-sent-modal',
  templateUrl: './email-sent-modal.component.html',
  styleUrls: ['./email-sent-modal.component.scss']
})
export class EmailSentModalComponent {


  
  constructor(public dialogRef: MatDialogRef<EmailSentModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }
}

