import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ValidLoginModalComponent } from './valid-login-modal.component';

describe('ValidLoginModalComponent', () => {
  let component: ValidLoginModalComponent;
  let fixture: ComponentFixture<ValidLoginModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ValidLoginModalComponent]
    });
    fixture = TestBed.createComponent(ValidLoginModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
