import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-valid-login-modal',
  templateUrl: './valid-login-modal.component.html',
  styleUrls: ['./valid-login-modal.component.scss']
})
export class ValidLoginModalComponent {


  constructor(public dialogRef: MatDialogRef<ValidLoginModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
