import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-tutor-modal',
  templateUrl: './delete-tutor-modal.component.html',
  styleUrls: ['./delete-tutor-modal.component.scss']
})
export class DeleteTutorModalComponent {

  constructor(public dialogRef: MatDialogRef<DeleteTutorModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
