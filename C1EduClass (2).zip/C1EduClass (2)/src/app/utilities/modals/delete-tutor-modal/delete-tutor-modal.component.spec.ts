import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteTutorModalComponent } from './delete-tutor-modal.component';

describe('DeleteTutorModalComponent', () => {
  let component: DeleteTutorModalComponent;
  let fixture: ComponentFixture<DeleteTutorModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteTutorModalComponent]
    });
    fixture = TestBed.createComponent(DeleteTutorModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
