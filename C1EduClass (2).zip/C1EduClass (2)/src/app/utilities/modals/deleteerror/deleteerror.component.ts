import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-deleteerror',
  templateUrl: './deleteerror.component.html',
  styleUrls: ['./deleteerror.component.scss']
})
export class DeleteerrorComponent {
  constructor(public dialogRef: MatDialogRef<DeleteerrorComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
