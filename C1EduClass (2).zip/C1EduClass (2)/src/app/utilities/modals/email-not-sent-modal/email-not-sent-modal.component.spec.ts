import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailNotSentModalComponent } from './email-not-sent-modal.component';

describe('EmailNotSentModalComponent', () => {
  let component: EmailNotSentModalComponent;
  let fixture: ComponentFixture<EmailNotSentModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [EmailNotSentModalComponent]
    });
    fixture = TestBed.createComponent(EmailNotSentModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
