import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-email-not-sent-modal',
  templateUrl: './email-not-sent-modal.component.html',
  styleUrls: ['./email-not-sent-modal.component.scss']
})
export class EmailNotSentModalComponent {

  constructor(public dialogRef: MatDialogRef<EmailNotSentModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
