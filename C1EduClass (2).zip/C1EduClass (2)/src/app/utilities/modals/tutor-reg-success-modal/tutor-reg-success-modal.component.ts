import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-tutor-reg-success-modal',
  templateUrl: './tutor-reg-success-modal.component.html',
  styleUrls: ['./tutor-reg-success-modal.component.scss']
})
export class TutorRegSuccessModalComponent {


  constructor(public dialogRef: MatDialogRef<TutorRegSuccessModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
