import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorRegSuccessModalComponent } from './tutor-reg-success-modal.component';

describe('TutorRegSuccessModalComponent', () => {
  let component: TutorRegSuccessModalComponent;
  let fixture: ComponentFixture<TutorRegSuccessModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorRegSuccessModalComponent]
    });
    fixture = TestBed.createComponent(TutorRegSuccessModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
