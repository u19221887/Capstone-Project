import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
@Component({
  selector: 'app-delete-admin-modal',
  templateUrl: './delete-admin-modal.component.html',
  styleUrls: ['./delete-admin-modal.component.scss']
})
export class DeleteAdminModalComponent {

  constructor(public dialogRef: MatDialogRef<DeleteAdminModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }


}
