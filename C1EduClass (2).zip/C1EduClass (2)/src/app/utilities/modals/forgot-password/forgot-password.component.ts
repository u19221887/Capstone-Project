import { Component, OnInit  } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';
import { HttpErrorResponse } from '@angular/common/http';
import { FormBuilder,Validators,FormControl, FormGroup } from '@angular/forms';
import { Router } from '@angular/router';
import { ForgotPasswordService } from 'src/app/services/forgot-password.service';
import { MatDialog } from '@angular/material/dialog';
import { EmailSentModalComponent } from '../email-sent-modal/email-sent-modal.component';
import { EmailNotSentModalComponent } from '../email-not-sent-modal/email-not-sent-modal.component';
import { MatSnackBar } from '@angular/material/snack-bar';


@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.scss']
})
export class ForgotPasswordComponent implements OnInit {
  forgotPassword!: FormGroup
 

  constructor(private snackBar: MatSnackBar, private dialog: MatDialog,public dialogRef: MatDialogRef<ForgotPasswordComponent>, private formBuilder: FormBuilder, private forgotPasswordService: ForgotPasswordService,) { }

  ngOnInit(){
    this.forgotPassword =this.formBuilder.group({
      email: ['', [Validators.required, Validators.email]],
    })
  }
  emailValidator(control: FormControl): { [key: string]: boolean } | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (control.value && !emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }

    return null;
  }

  onSubmit(): void {
    if (this.forgotPassword.valid) {
     
      console.log(this.forgotPassword.value);
      
       
    } else {
      
      this.validateAllFormFields(this.forgotPassword);
    }

  
  }

  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });

  

}

close(): void {
  this.dialogRef.close();

//code for email submission

if (this.forgotPassword.valid) {
  this.forgotPasswordService.forgotPassword(this.forgotPassword.value).subscribe(
    result => {
      localStorage.setItem('User', JSON.stringify(result));
      this.forgotPassword.reset();
      this.successModal();
      
    },
    (error: any) => {
      if (error.status === 500) {
        this.unsuccessModal();}

        else {
          this.snackBar.open(`An error occurred: ${error.message}`, 'X', { duration: 5000 });
        }
      },
  );
}


}

successModal() {
  const dialogRef = this.dialog.open(EmailSentModalComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {
    
    this.forgotPassword.reset();
  });
}


unsuccessModal() {
  const dialogRef = this.dialog.open(EmailNotSentModalComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {
    
    this.forgotPassword.reset();
  });
}

closeModel(): void {
  this.dialogRef.close();
}



}