import { ComponentFixture, TestBed } from '@angular/core/testing';

import { FailedBookingComponent } from './failed-booking.component';

describe('FailedBookingComponent', () => {
  let component: FailedBookingComponent;
  let fixture: ComponentFixture<FailedBookingComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [FailedBookingComponent]
    });
    fixture = TestBed.createComponent(FailedBookingComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
