import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-failed-booking',
  templateUrl: './failed-booking.component.html',
  styleUrls: ['./failed-booking.component.scss']
})
export class FailedBookingComponent {

  constructor(public dialogRef: MatDialogRef<FailedBookingComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
