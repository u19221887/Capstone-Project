import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-user-exist-modal',
  templateUrl: './user-exist-modal.component.html',
  styleUrls: ['./user-exist-modal.component.scss']
})
export class UserExistModalComponent {

  constructor(public dialogRef: MatDialogRef<UserExistModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
