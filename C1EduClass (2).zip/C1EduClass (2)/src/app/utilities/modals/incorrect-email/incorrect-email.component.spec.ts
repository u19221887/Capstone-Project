import { ComponentFixture, TestBed } from '@angular/core/testing';

import { IncorrectEmailComponent } from './incorrect-email.component';

describe('IncorrectEmailComponent', () => {
  let component: IncorrectEmailComponent;
  let fixture: ComponentFixture<IncorrectEmailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [IncorrectEmailComponent]
    });
    fixture = TestBed.createComponent(IncorrectEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
