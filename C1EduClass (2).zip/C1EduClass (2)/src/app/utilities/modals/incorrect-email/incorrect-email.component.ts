import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-incorrect-email',
  templateUrl: './incorrect-email.component.html',
  styleUrls: ['./incorrect-email.component.scss']
})
export class IncorrectEmailComponent {

  constructor(public dialogRef: MatDialogRef<IncorrectEmailComponent>) { }

  close(): void {
    this.dialogRef.close();
  }

}
