import { Component } from '@angular/core';
import { MatDialogRef } from '@angular/material/dialog';

@Component({
  selector: 'app-delete-subject-grade-modal',
  templateUrl: './delete-subject-grade-modal.component.html',
  styleUrls: ['./delete-subject-grade-modal.component.scss']
})
export class DeleteSubjectGradeModalComponent {

  constructor(public dialogRef: MatDialogRef<DeleteSubjectGradeModalComponent>) { }

  close(): void {
    this.dialogRef.close();
  }


}
