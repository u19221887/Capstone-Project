import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DeleteSubjectGradeModalComponent } from './delete-subject-grade-modal.component';

describe('DeleteSubjectGradeModalComponent', () => {
  let component: DeleteSubjectGradeModalComponent;
  let fixture: ComponentFixture<DeleteSubjectGradeModalComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [DeleteSubjectGradeModalComponent]
    });
    fixture = TestBed.createComponent(DeleteSubjectGradeModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
