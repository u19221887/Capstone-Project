import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { AboutUsComponent } from './pages/about-us/about-us.component';
import { SubjectsComponent } from './pages/subjects/subjects.component';
import { TestimonialsComponent } from './pages/testimonials/testimonials.component';
import { ContactComponent } from './pages/contact/contact.component';
import { ApplicationComponent } from './pages/application/application.component';
import { UserAuthComponent } from './user/user-auth.component';
import { StudentDashboardComponent } from './dashboards/student-dashboard/student-dashboard.component';
import { AdminDashboardComponent } from './dashboards/admin-dashboard/admin-dashboard.component';
import { AdminFeedbackComponent } from './dashboards/admin-dashboard/admin-feedback/admin-feedback.component';
import { AdminMyprofileComponent } from './dashboards/admin-dashboard/admin-myprofile/admin-myprofile.component';
import { AdminSettingsComponent } from './dashboards/admin-dashboard/admin-settings/admin-settings.component';
import { AdminStudentsComponent } from './dashboards/admin-dashboard/admin-students/admin-students.component';
import { AdminTimeslotsComponent } from './dashboards/admin-dashboard/admin-timeslots/admin-timeslots.component';
import { DiscountsComponent } from './dashboards/admin-dashboard/discounts/discounts.component';
import { PaymentsComponent } from './dashboards/admin-dashboard/payments/payments.component';
import { ReportsComponent } from './dashboards/admin-dashboard/reports/reports.component';
import { TutorsComponent } from './dashboards/admin-dashboard/tutors/tutors.component';
import { AddDiscountComponent } from './dashboards/admin-dashboard/discounts/add-discount/add-discount.component';
import { TutorApplicationsComponent } from './dashboards/admin-dashboard/tutors/tutor-applications/tutor-applications.component';
import { TutorProfilesComponent } from './dashboards/admin-dashboard/tutors/tutor-profiles/tutor-profiles.component';
import { TutorRegistrationComponent } from './user/Tutor/tutor-registration/tutor-registration.component';
import { EditDiscountComponent } from './dashboards/admin-dashboard/discounts/edit-discount/edit-discount.component';
import { StudentLoginComponent } from './user/Student/student-login/student-login.component';
import { AdminLoginComponent } from './user/Admin/admin-login/admin-login.component';
import { TutorLoginComponent } from './user/Tutor/tutor-login/tutor-login.component';
import { StudentRegistrationComponent } from './user/Student/student-registration/student-registration.component';
import { AdminSubjectsComponent } from './dashboards/admin-dashboard/admin-subjects/admin-subjects/admin-subjects.component';
import { TutorReportComponent } from './dashboards/admin-dashboard/reports/tutor-report/tutor-report.component';
// import {PrimaryAfrikaansComponent} from './tutor-dashboard/tutor-primary/primary-afrikaans';
import { ForgotPasswordComponent } from './utilities/modals/forgot-password/forgot-password.component';
import { StudentLoginRegComponent } from './user/Student/student-login-reg/student-login-reg.component';
import { SuccessRegisterModelComponent } from './utilities/modals/success-register-model/success-register-model.component';
import { UpdateStudentModelComponent } from './utilities/modals/update-student-model/update-student-model.component';
import { StudentProfileComponent } from './dashboards/student-dashboard/student-profile/student-profile.component';
import { StudentReportComponent } from './dashboards/admin-dashboard/reports/student-report/student-report.component';
import { ParentfeedbackReportComponent } from './dashboards/admin-dashboard/reports/parentfeedback-report/parentfeedback-report.component';
import { PfeedbackReportComponent } from './dashboards/admin-dashboard/reports/pfeedback-report/pfeedback-report.component';
import { UserReportComponent } from './dashboards/admin-dashboard/reports/user-report/user-report.component';

import { ContractComponent } from './pages/contract/contract.component';
import { ResetPasswordComponent } from './pages/reset-password/reset-password.component';
import { ChangePasswordModelComponent } from './utilities/modals/change-password-model/change-password-model.component';
import { EmailNotSentModalComponent } from './utilities/modals/email-not-sent-modal/email-not-sent-modal.component';
import { EmailSentModalComponent } from './utilities/modals/email-sent-modal/email-sent-modal.component';
import { IncorrectEmailComponent } from './utilities/modals/incorrect-email/incorrect-email.component';
import { LoginModalComponent } from './utilities/modals/login-modal/login-modal.component';
import { RegistrationEmailErrorComponent } from './utilities/modals/registration-email-error/registration-email-error.component';
import { SuccessfulEmailUpdateComponent } from './utilities/modals/successful-email-update/successful-email-update.component';
import { UnauthorizedAccessComponent } from './utilities/modals/unauthorized-access/unauthorized-access.component';
import { UnauthorizedAccessLoginComponent } from './utilities/modals/unauthorized-access-login/unauthorized-access-login.component';
import { UserExistModalComponent } from './utilities/modals/user-exist-modal/user-exist-modal.component';
import { ValidLoginModalComponent } from './utilities/modals/valid-login-modal/valid-login-modal.component';
import { StudentChangePasswordComponent } from './services/student-change-password/student-change-password.component';
import { StudentUpdateEmailComponent } from './dashboards/student-dashboard/student-update-email/student-update-email.component';
import { StudentSettingsComponent } from './dashboards/student-dashboard/student-settings/student-settings/student-settings.component';
import { AdminLoginRegComponent } from './user/Admin/admin-login-reg/admin-login-reg.component';
import { MakeBookingComponent } from './dashboards/student-dashboard/make-booking/make-booking.component';
import { ViewBookingStudentComponent } from './dashboards/student-dashboard/view-booking/view-booking.component';
import {TutorMyprofileComponent} from "./dashboards/tutor-dashboard/tutor-myprofile/tutor-myprofile.component";
import {TutorHomeworkComponent} from "./dashboards/tutor-dashboard/tutor-homework/tutor-homework.component";
import {TutorOnlinevideoComponent} from "./dashboards/tutor-dashboard/tutor-onlinevideo/tutor-onlinevideo.component";
import {TutorDashboardComponent} from "./dashboards/tutor-dashboard/tutor-dashboard.component";
import {TutorSettingsComponent} from "./dashboards/tutor-dashboard/tutor-settings/tutor-settings.component";
import {TutorTimeslotsComponent} from "./dashboards/tutor-dashboard/tutor-timeslots/tutor-timeslots.component";
import {TutorGradesComponent} from "./dashboards/tutor-dashboard/tutor-grades/tutor-grades.component";
import {AddGradeComponent} from "./dashboards/tutor-dashboard/tutor-grades/add-grade/add-grade.component";
import {
  TutorGradeSubjectComponent
} from "./dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/tutor-grade-subject.component";
import {AddSubjectComponent} from "./dashboards/admin-dashboard/admin-subjects/add-subject/add-subject.component";
import {
  TutorAddSubjectComponent
} from "./dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/tutor-add-subject/tutor-add-subject.component";
import {TutorSubjectsComponent} from "./dashboards/tutor-dashboard/tutor-subjects/tutor-subjects.component";
import { ViewMyBookingComponent } from './dashboards/tutor-dashboard/view-my-booking/view-my-booking.component';
import { HomeworkscreenComponent } from './dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/homeworkscreen/homeworkscreen.component';
import { VideoscreenComponent } from './dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/videoscreen/videoscreen.component';
import { FileDeleteComponent } from './dashboards/student-dashboard/student-homework-rec/file-delete/file-delete.component';
import { DownloadComponent } from './dashboards/student-dashboard/student-homework-rec/download/download.component';
import { UploadComponent } from './dashboards/student-dashboard/student-homework-rec/upload/upload.component';
import { UploadRecordingsComponent } from './upload-recordings/upload-recordings.component';
import { ViewrecordingsComponent } from './upload-recordings/viewrecordings/viewrecordings.component';
import { UprecordingsComponent } from './upload-recordings/uprecordings/uprecordings.component';
import { TdownloadComponent } from './dashboards/tutor-dashboard/tutor-homework-rec/tdownload/tdownload.component';
import { TfileDeleteComponent } from './dashboards/tutor-dashboard/tutor-homework-rec/tfile-delete/tfile-delete.component';
import { TuploadComponent } from './dashboards/tutor-dashboard/tutor-homework-rec/tupload/tupload.component';
import { VideoDeleteComponent } from './upload-recordings/video-delete/video-delete.component';
import { VideoDownloadComponent } from './upload-recordings/video-download/video-download.component';
import { VideoUploadComponent } from './upload-recordings/video-upload/video-upload.component';
import { AuditReportComponent } from './dashboards/admin-dashboard/reports/audit-report/audit-report.component';
import { BookingReportComponent } from './dashboards/admin-dashboard/reports/booking-report/booking-report.component';
import { HelpDocumentComponent } from './pages/help-facility/help-document/help-document.component';
import { HelpFacilityComponent } from './pages/help-facility/help-facility.component';
import { TutorAndSubjectsComponent } from './dashboards/admin-dashboard/tutors/tutor-and-subjects/tutor-and-subjects.component';


const routes: Routes = [
  {path: 'welcome', component: WelcomeComponent},
  // {path:'',redirectTo:'/welcome', pathMatch:'full'},
  {path:'',component:WelcomeComponent},
  {path: 'about-us', component:AboutUsComponent},
  {path: 'subjects', component:SubjectsComponent},
  {path: 'contact', component:ContactComponent},
  {path: 'testimonials', component:TestimonialsComponent},
  {path: 'user', component:UserAuthComponent},
  {path: 'application', component:ApplicationComponent},

  {path: 'admin-dashboard', component:AdminDashboardComponent},
  {path: 'admin-feedback', component:AdminFeedbackComponent},
  {path: 'admin-myprofile', component:AdminMyprofileComponent},
  {path: 'admin-settings', component:AdminSettingsComponent},
  {path: 'admin-students', component:AdminStudentsComponent},
  {path: 'admin-timeslots', component:AdminTimeslotsComponent},
  {path: 'admin-discount', component:DiscountsComponent},
  {path: 'payments', component:PaymentsComponent},
  {path: 'admin-reports', component:ReportsComponent},
  {path: 'admin-tutors', component:TutorsComponent},


  {path: 'add-discount', component: AddDiscountComponent},
  {path: 'tutor-applications', component: TutorApplicationsComponent},
  {path: 'tutor-profiles', component: TutorProfilesComponent},
  {path: 'tutorhomework', component:TutorHomeworkComponent},
  {path: 'tutoronlinevideo', component:TutorOnlinevideoComponent},
  {path: 'tutor-registration/:id', component: TutorRegistrationComponent},
  {path:'tutor-dashboard/:id',component:TutorDashboardComponent},
  {path:'tutor-dashboard',component:TutorDashboardComponent},
  {path: 'edit-discount/:id', component: EditDiscountComponent},
  {path: 'student-login', component: StudentLoginComponent},
  {path: 'admin-login', component: AdminLoginComponent},
  {path: 'tutor-login', component: TutorLoginComponent},

  {path: 'admin-subjects', component: AdminSubjectsComponent},
  {path: 'admin-timeslots', component: AdminTimeslotsComponent},
  {path: 'tutor-myprofile/:id', component: TutorMyprofileComponent},
  {path: 'tutor-settings/:id', component: TutorSettingsComponent},
  {path: 'tutor-report', component : TutorReportComponent},
  {path: 'forgot-password', component:ForgotPasswordComponent},
  {path: 'student-dashboard', component:StudentDashboardComponent},
  {path:'student-login-reg', component:StudentLoginRegComponent},
  {path: 'student-registration/:email', component: StudentRegistrationComponent},
  {path: 'tutor-registration', component: TutorRegistrationComponent},

  {path:'success-register-model', component:SuccessRegisterModelComponent},
  {path:'update-student-model', component:UpdateStudentModelComponent},
  {path:'student-profile', component:StudentProfileComponent},
  {path: 'student-report',component:StudentReportComponent},
  {path: 'parent-feedback/:id', component:ParentfeedbackReportComponent},
  {path: 'pfeedback-report', component:PfeedbackReportComponent},
  {path: 'user-report', component: UserReportComponent},
  {path: 'tutor-timeslots', component: TutorTimeslotsComponent},
  {path: 'tutor-grades/:id', component: TutorGradesComponent},
  {path: 'tutor-addGrade/:id', component: AddGradeComponent},
  {path: 'tutor-grade-subject/:id', component: TutorGradeSubjectComponent},
  {path: 'add-subject', component: AddSubjectComponent},
  {path: 'tutor-addSubject/:id', component: TutorAddSubjectComponent},
  {path:'contract',component:ContractComponent},
  {path:'reset-password',component:ResetPasswordComponent},
  {path:'change-password-model', component:ChangePasswordModelComponent},
  {path:'incorrect-email', component:IncorrectEmailComponent},
  {path:'unauthorized-access', component:UnauthorizedAccessComponent},
  {path:'unauthorized-access-login', component:UnauthorizedAccessLoginComponent},
  {path:'successful-email-update', component:SuccessfulEmailUpdateComponent},
  {path:'registration-email-error', component:RegistrationEmailErrorComponent},
  {path:'email-sent-modal',component:EmailSentModalComponent},
  {path:'email-not-sent-modal', component:EmailNotSentModalComponent},
  {path:'login-modal',component:LoginModalComponent},
  {path:'valid-login-modal', component:ValidLoginModalComponent},
  {path:'user-exist-modal', component:UserExistModalComponent},
  {path:'student-change-password',component:StudentChangePasswordComponent},
  {path:'student-update-email',component:StudentUpdateEmailComponent},
  {path:'update-student-model',component:UpdateStudentModelComponent },
  {path:'student-settings',component:StudentSettingsComponent},
  {path:'admin-login-reg', component:AdminLoginRegComponent},
  // //////////////////////////
    //
    {path: 'student-dashboard/booking', component: MakeBookingComponent},
    {path: 'student-dashboard/view-booking', component: ViewBookingStudentComponent    },


    {path: 'tutor-dashboard', component: TutorDashboardComponent},
    {path: 'tutor-dashboard/timeslot', component: TutorTimeslotsComponent    },
    {path: 'tutor-dashboard/view-booking', component: ViewMyBookingComponent    },
    {path: 'tutor-subjects', component: TutorSubjectsComponent    },
    {path: 'view-booking', component: ViewMyBookingComponent    },
    {path: 'AddTutor', component: TutorRegistrationComponent},
    {path: 'homework/:id', component: HomeworkscreenComponent},
    {path: 'video/:id',component: VideoscreenComponent},

    {path: 'student-download/:containerName', component:DownloadComponent},
    {path: 'student-upload', component:UploadComponent},
    {path: 'student-delete', component:FileDeleteComponent},
    {path: 'upload-recordings/:id', component:UploadRecordingsComponent},
    {path: 'view-recordings/:containerName', component:ViewrecordingsComponent},
    {path: 'upload-recordings', component:UploadRecordingsComponent},
    {path: 'tutor-download/:containerName', component:TdownloadComponent},
    {path: 'tutor-upload', component:TuploadComponent},
    {path: 'tutor-delete', component:TfileDeleteComponent},
    {path: 'video-upload', component:VideoUploadComponent},
    {path: 'video-delete', component:VideoDeleteComponent},
    {path: 'video-download/:containerName', component:VideoDownloadComponent},
    {path:'up-recordings/:containerName',component:UprecordingsComponent},
    {path: 'audit-report', component: AuditReportComponent},
    {path: 'booking-report', component: BookingReportComponent},
    {path: 'help-f', component:HelpFacilityComponent},
    {path: 'help-d', component:HelpDocumentComponent},
    {path: 'tutor-and-subjects', component:TutorAndSubjectsComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
exports: [RouterModule]
})
export class AppRoutingModule { }
