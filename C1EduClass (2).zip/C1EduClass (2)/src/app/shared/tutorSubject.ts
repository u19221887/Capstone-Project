export class TutorSubject{
    myTutorSubjectId: Number=0;
    tutorName: string="";
    tutorSurname:string="";
    subjectName:string="";
    subjectDescription:string="";
}