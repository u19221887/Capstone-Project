export class Student {
        id: number = 0;
        studentName:String = "";
        studentSurname:String = "";
        studentPhoneNumber:String = "";
        studentEmail:String = "";
        grade:Number = 0;
        subject: String="";
        dateOfBirth:String = "";
        studentAge: String ="";
        //studentImage:String = "";
        parentTitle:String = "";
        parentName:String = "";
        parentSurname:String = "";
        parentPhoneNumber:String = "";
        parentEmail:String = "";
        studentProvince:String = "";
        studentCity:String = "";
        studentAddress:String = "";
        studentPostalCode: Number = 0;
    }