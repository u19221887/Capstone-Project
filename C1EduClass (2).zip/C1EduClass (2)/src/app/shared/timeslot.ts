export interface Timeslot {
    timeslotId: Number;
    timeslotDay:string;
    timeslotStartTime:string;
    timeslotEndTime:string;
}