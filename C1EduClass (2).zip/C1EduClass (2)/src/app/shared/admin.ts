export class Admin{
    adminId : Number = 0;
    adminName: string  = "";
    adminSurname: string = "";
    adminPhoneNumber: string = "";
    adminIdNumber : string = "";
    adminEmail: string  = "";
    
     

    
}