export interface ParentFeedback {
    parentName : string;
    parentSurname : string;
    parentFeedbackDescription : string;
    studentName : string;
    studentSurname: string;
    subject :string;
}