export interface RegisterUser {
    email: string;
    password: string;
}