export interface Grade{
    gradeId: number;
    gradeName: string;
}