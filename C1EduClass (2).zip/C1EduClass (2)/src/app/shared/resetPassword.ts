export class ResetPassword {
    Password: string= "";
    ConfirmPassword: string= "";
    Email: string= "";
    Token: string= "";
}