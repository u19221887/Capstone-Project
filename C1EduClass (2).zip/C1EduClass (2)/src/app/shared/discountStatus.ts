export interface DiscountStatus{
    discountStatusId : Number;
    discountStatusDescription : string;
}