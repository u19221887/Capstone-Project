export interface User {
    token?: string
    user?: string
}