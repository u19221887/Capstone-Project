export class TutorAvailabilityTime {
    CompanyAvailabilities!:number[];
    TutorId!: number;
    isTaken?: boolean = false;
}