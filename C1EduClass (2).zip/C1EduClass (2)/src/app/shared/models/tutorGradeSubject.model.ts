export class TutorGradeSubject {
    Subjects!:number[];
    TutorGradeId!: number;
    //isTaken?: boolean = false;
}