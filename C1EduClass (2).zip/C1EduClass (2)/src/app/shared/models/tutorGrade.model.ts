export class TutorGrade {
    Grades!:number[];
    TutorId!: number;
    //isTaken?: boolean = false;
}