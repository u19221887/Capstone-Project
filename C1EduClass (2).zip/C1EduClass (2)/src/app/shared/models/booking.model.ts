
export class Booking {
    TutorAvailabiltyId!: number;
    StudentId!: number;
    SessionCostId!: number;
    TutorSubjectId!: number;

}
