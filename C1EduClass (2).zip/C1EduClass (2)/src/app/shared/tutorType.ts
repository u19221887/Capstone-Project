export interface TutorType{
    tutorTypeId: number;
    tutorTypeDescription: string;
}