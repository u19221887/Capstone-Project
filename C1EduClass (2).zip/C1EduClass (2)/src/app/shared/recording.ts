export class Recording{

    recording_ID: number = 0;
    name: string = "";
    description: string = "";
    date: string = "";
    filePath: string = "";
    fileName: string = "";
    VideoFile!: File;
    subject_Id: number = 0;

}