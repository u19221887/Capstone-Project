export class ChangePassword {
    Email: string= "";
    CurrentPassword: string= "";
    NewPassword: string= "";
}