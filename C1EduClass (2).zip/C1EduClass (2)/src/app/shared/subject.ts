export class Subject {
    subjectId: Number=0;
    subjectName:string="";
    subjectDescription:string="";
}