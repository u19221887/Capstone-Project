export interface Discount {
    discountId : Number;
    discountCode : string;
    discountStartDate : Date;
    discountEndDate : Date;
    numberOfSessions : Number;
    discountPercentage : Number;
    discountStatus : Number;
}