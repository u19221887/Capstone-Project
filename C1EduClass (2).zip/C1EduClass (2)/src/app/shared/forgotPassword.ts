export interface ForgotPassword {
    Email: string;
   
}