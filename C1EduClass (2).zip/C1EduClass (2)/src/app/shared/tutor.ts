export interface Tutor{
    id : Number,
    title : string,
    tutorName: string,
    tutorSurname: string,
    tutorPhoneNumber: string,
    //TutorImage: string,
    tutorIdNumber : string,
    tutorEmail: string,
    tutorProvince: string,
    tutorCity: string,
    tutorAddress: string,
    tutorPostalCode : string,
    TutorApplicationId : Number
     

    
}