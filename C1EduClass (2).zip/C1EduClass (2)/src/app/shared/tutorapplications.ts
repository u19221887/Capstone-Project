export interface TutorApplication {
    tutorApplicationName : string;
    tutorApplicationSurname : string;
    tutorApplicationPhoneNumber : string;
    tutorApplicationEmail : string;
    tutorApplicationCV: string;
    tutorApplicationId :Number;
    subject : string;
    grade : string;
}