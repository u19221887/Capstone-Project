import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UprecordingsComponent } from './uprecordings.component';

describe('UprecordingsComponent', () => {
  let component: UprecordingsComponent;
  let fixture: ComponentFixture<UprecordingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UprecordingsComponent]
    });
    fixture = TestBed.createComponent(UprecordingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
