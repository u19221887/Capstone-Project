import { Component, OnInit } from '@angular/core';
import { FileService } from 'src/app/services/file.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-video-download',
  templateUrl: './video-download.component.html',
  styleUrls: ['./video-download.component.scss']
})
export class VideoDownloadComponent implements OnInit {
  fileList: string[] = [];
  videoBlobUrl: string | null = null; // Variable to store the video Blob URL
  imageUrl: string | null = null; // Variable to store the image URL
  containerName: string = 'videocontainer'; // container name
  searchQuery: string = '';
  selectedVideoFileName: string | null = null;
  videoElement: HTMLVideoElement | null = null; // Reference to the video element

  selectedGrade: string = ''; // Initialize the selectedGrade property as an empty string

  filteredFileList: string[] = []; // Initialize the filteredFileList property

  constructor(
    private fileService: FileService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Read the 'containerName' route parameter and set the containerName accordingly
    this.route.params.subscribe(params => {
      const containerName = params['containerName'];
      if (containerName === 'videocontainer' || containerName === 'studentcontainer') {
        this.containerName = containerName;
        this.fetchFileList();
      } else {
        // Handle invalid containerName
        console.error('Invalid containerName:', containerName);
        // You might want to redirect or show an error message here
      }
    });

    // Initialize the filteredFileList with all files initially
    this.filteredFileList = this.fileList; // Initialize filteredFileList
    this.applyFilter(); // Call applyFilter to filter files initially
  }

  onSearchQueryChange() {
    this.applyFilter();
  }

  fetchFileList(): void {
    // Load files from the specified container
    this.fileService.getFilesList(this.containerName).subscribe(
      (fileList) => {
        this.fileList = fileList;
        this.filteredFileList = fileList; // Update the filteredFileList with fetched data
      },
      (error) => {
        console.error('Error fetching file list:', error);
        alert('Error fetching file list. Please try again later.');
      }
    );
  }

  // Add this filter function inside your component class
applyFilter() {
  if (this.searchQuery.trim() === '') {
    // If the search query is empty, show all files
    this.filteredFileList = this.fileList;
  } else {
    // Otherwise, filter files based on the search query
    this.filteredFileList = this.fileList.filter(file => {
      return file.toLowerCase().includes(this.searchQuery.toLowerCase());
    });
  }
}


  // Function to open the modal and display the video
  openModal() {
    const modal = document.getElementById('videoModal')!;
    modal.style.display = 'block';
    this.playVideo(); // Play the video
  }

  // Function to play the video
  playVideo() {
    if (this.videoElement) {
      this.videoElement.play();
    }
  }

  // Function to close the modal and stop the video
  closeModal() {
    const modal = document.getElementById('videoModal')!;
    modal.style.display = 'none';

    // Stop and reset the video element
    this.stopVideo();

    window.location.reload();
    
  }

  // Function to stop the video
  stopVideo() {
    if (this.videoElement) {
      this.videoElement.pause();
      this.videoElement.currentTime = 0;
    }
  }

  // Function to navigate to DownloadComponent with a specific containerName
  navigateToDownload(containerName: string) {
    // Use the router to navigate to the DownloadComponent
    this.router.navigate(['/student-download', containerName]);
  }

  // fetchFileList(): void {
  //   // Load files from the specified container
  //   this.fileService.getFilesList(this.containerName).subscribe(
  //     (fileList) => {
  //       this.fileList = fileList;
  //     },
  //     (error) => {
  //       console.error('Error fetching file list:', error);
  //       alert('Error fetching file list. Please try again later.');
  //     }
  //   );
  // }

  onDownload(filename: string): void {
    this.fileService.downloadFile(filename, this.containerName).subscribe(
      (data) => {
        if (filename.endsWith('.mp4')) {
          // Download video files by creating a link and triggering a click event
          const blob = new Blob([data], { type: 'video/mp4' });
          const url = window.URL.createObjectURL(blob);

          const link = document.createElement('a');
          link.href = url;
          link.download = filename;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        } else {
          // For other file types, trigger the file download as before
          this.downloadFile(data, filename);
        }
      },
      (error) => {
        console.error('Error downloading file:', error);
        alert('Error downloading file. Please try again later.');
      }
    );
  }

  private downloadFile(data: any, filename: string) {
    const blob = new Blob([data], { type: 'application/octet-stream' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  onView(filename: string): void {
    this.selectedVideoFileName = filename; // Store the selected file name
  
    this.fileService.downloadFile(filename, this.containerName).subscribe(
      (data) => {
        if (filename.endsWith('.mp4')) {
          // Convert the ArrayBuffer to a Blob
          const blob = new Blob([data], { type: 'video/mp4' });
  
          // Set the video Blob URL using the Blob
          this.setVideoBlobUrl(blob);
  
          console.log('Selected Filename:', filename);
          console.log('Selected Video Blob URL:', this.videoBlobUrl);
  
          // Open the modal after setting the video URL
          this.openModal();
        } else if (filename.endsWith('.png') || filename.endsWith('.jpg') || filename.endsWith('.jpeg')) {
          // Set the image URL for image files
          this.imageUrl = window.URL.createObjectURL(new Blob([data], { type: 'image/*' }));
  
          // Clear the videoBlobUrl when viewing an image
          this.videoBlobUrl = null;
  
          // Open the modal for image files
          this.openModal();
        } else {
          // For other file types, trigger the file download as before
          this.downloadFile(data, filename);
        }
      },
      (error) => {
        console.error('Error viewing file:', error);
        alert('Error viewing file. Please try again later.');
      }
    );
  }
  

  // Create a separate function to set the video Blob URL
  private setVideoBlobUrl(blob: Blob): void {
    if (this.videoBlobUrl) {
      window.URL.revokeObjectURL(this.videoBlobUrl); // Revoke the previous URL if it exists
    }
    this.videoBlobUrl = window.URL.createObjectURL(blob);
  }

  // This function will be called when the component is destroyed
  ngOnDestroy(): void {
    this.revokeUrls();
  }

  // Helper function to revoke the video URL and image URL when they are no longer needed
  revokeUrls(): void {
    if (this.videoBlobUrl) {
      window.URL.revokeObjectURL(this.videoBlobUrl);
      this.videoBlobUrl = null;
    }
    if (this.imageUrl) {
      window.URL.revokeObjectURL(this.imageUrl);
      this.imageUrl = null;
    }
  }

  openPDF(pdfUrl: string) {
    // Implement your logic to open the PDF document here
    // You can use a library like pdf.js or open it in a new browser tab
    window.open(pdfUrl, '_blank');
}
}
