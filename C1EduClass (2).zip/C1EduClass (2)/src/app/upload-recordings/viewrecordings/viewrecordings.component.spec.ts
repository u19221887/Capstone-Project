import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ViewrecordingsComponent } from './viewrecordings.component';

describe('ViewrecordingsComponent', () => {
  let component: ViewrecordingsComponent;
  let fixture: ComponentFixture<ViewrecordingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ViewrecordingsComponent]
    });
    fixture = TestBed.createComponent(ViewrecordingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
