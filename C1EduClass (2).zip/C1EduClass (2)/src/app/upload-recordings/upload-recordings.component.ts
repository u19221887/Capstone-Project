import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { APIService } from '../services/api.service';
import Swal from 'sweetalert2';
import { ActivatedRoute } from '@angular/router';


@Component({
  selector: 'app-upload-recordings',
  templateUrl: './upload-recordings.component.html',
  styleUrls: ['./upload-recordings.component.scss']
})
export class UploadRecordingsComponent implements OnInit {
  formAddRecording: FormGroup;
  selectedFile: File | undefined;

  constructor(private formBuilder: FormBuilder, private apiService: APIService, private route: ActivatedRoute) {
    this.formAddRecording = this.formBuilder.group({
      name: [''],
      description: [''],
      video: ['']
    });
  }

  ngOnInit(): void {}

  handleVideoUpload(event: Event) {
    this.selectedFile = (event.target as HTMLInputElement).files?.[0];
  }
  idvaluetopass = this.route.snapshot.params['id'];

  addRecording() {
    if (this.selectedFile) {
      const newRecording = new FormData();
      newRecording.append('Name', this.formAddRecording.value.name);
      newRecording.append('Description', this.formAddRecording.value.description);
      newRecording.append('VideoFile', this.selectedFile, this.selectedFile.name);
      newRecording.append('Subject_Id', this.idvaluetopass);
  
      this.apiService.addRecordings(newRecording).subscribe(
        (result) => {
          Swal.fire('Success!', 'File uploaded successfully', 'success');
          // Rest of your code
        },
        (error) => {
          Swal.fire('Error', 'Error uploading recording', 'error');
          // Handle error here
          console.error('Error uploading recording:', error);
        }
      );
    } else {
      Swal.fire('No File', 'Please select a video file', 'error');
      // Handle the case when no video file is selected
      console.error('No video file selected');
    }
  }
  
}
