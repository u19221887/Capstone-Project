import { Component } from '@angular/core';

@Component({
  selector: 'app-video-delete',
  templateUrl: './video-delete.component.html',
  styleUrls: ['./video-delete.component.scss']
})
export class VideoDeleteComponent {

}
