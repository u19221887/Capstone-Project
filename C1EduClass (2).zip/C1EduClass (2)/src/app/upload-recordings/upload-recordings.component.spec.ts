import { ComponentFixture, TestBed } from '@angular/core/testing';

import { UploadRecordingsComponent } from './upload-recordings.component';

describe('UploadRecordingsComponent', () => {
  let component: UploadRecordingsComponent;
  let fixture: ComponentFixture<UploadRecordingsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [UploadRecordingsComponent]
    });
    fixture = TestBed.createComponent(UploadRecordingsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
