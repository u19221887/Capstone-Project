import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { MaterialModule } from './shared/material.module';
import { WelcomeComponent } from './pages/welcome/welcome.component';
import { AboutUsComponent } from './pages/about-us/about-us.component';
import { SubjectsComponent } from './pages/subjects/subjects.component';
import { ContactComponent } from './pages/contact/contact.component';
import { TestimonialsComponent } from './pages/testimonials/testimonials.component';
import { ApplicationComponent } from './pages/application/application.component';
import { UserAuthComponent } from './user/user-auth.component';
import {FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AdminDashboardComponent } from './dashboards/admin-dashboard/admin-dashboard.component';
import { StudentDashboardComponent } from './dashboards/student-dashboard/student-dashboard.component';
import { RouterModule } from '@angular/router';
import { DiscountsComponent } from './dashboards/admin-dashboard/discounts/discounts.component';
import { PaymentsComponent } from './dashboards/admin-dashboard/payments/payments.component';
import { TutorsComponent } from './dashboards/admin-dashboard/tutors/tutors.component';
import { ReportsComponent } from './dashboards/admin-dashboard/reports/reports.component';
import { AdminFeedbackComponent } from './dashboards/admin-dashboard/admin-feedback/admin-feedback.component';
import { AdminSettingsComponent } from './dashboards/admin-dashboard/admin-settings/admin-settings.component';
import { AdminMyprofileComponent } from './dashboards/admin-dashboard/admin-myprofile/admin-myprofile.component';
import { AdminStudentsComponent } from './dashboards/admin-dashboard/admin-students/admin-students.component';
import { AdminTimeslotsComponent } from './dashboards/admin-dashboard/admin-timeslots/admin-timeslots.component';
import { AddDiscountComponent } from './dashboards/admin-dashboard/discounts/add-discount/add-discount.component';
import {HTTP_INTERCEPTORS, HttpClientModule} from '@angular/common/http';
import { EditDiscountComponent } from './dashboards/admin-dashboard/discounts/edit-discount/edit-discount.component';
import { TutorApplicationsComponent } from './dashboards/admin-dashboard/tutors/tutor-applications/tutor-applications.component';
import { TutorProfilesComponent } from './dashboards/admin-dashboard/tutors/tutor-profiles/tutor-profiles.component';

import { Component } from '@angular/core';
import { SocialAuthService, GoogleLoginProvider, SocialUser, SocialAuthServiceConfig } from '@abacritt/angularx-social-login';
import { TutorRegistrationComponent } from './user/Tutor/tutor-registration/tutor-registration.component';
import { TutorLoginComponent } from './user/Tutor/tutor-login/tutor-login.component';
import { StudentLoginComponent } from './user/Student/student-login/student-login.component';
import { StudentRegistrationComponent } from './user/Student/student-registration/student-registration.component';
import { AdminLoginComponent } from './user/Admin/admin-login/admin-login.component';
import { AddTimeslotComponent } from './dashboards/admin-dashboard/admin-timeslots/add-timeslot/add-timeslot.component';
import { EditTimeslotComponent } from './dashboards/admin-dashboard/admin-timeslots/edit-timeslot/edit-timeslot.component';
import { SuccessModalComponent } from './utilities/success-modal/success-modal.component';
import { StudentSettingsComponent } from './dashboards/student-dashboard/student-settings/student-settings/student-settings.component';
import { AdminSubjectsComponent } from './dashboards/admin-dashboard/admin-subjects/admin-subjects/admin-subjects.component';
import { AddSubjectComponent } from './dashboards/admin-dashboard/admin-subjects/add-subject/add-subject.component';
import { EditSubjectComponent } from './dashboards/admin-dashboard/admin-subjects/edit-subject/edit-subject.component';

import { TutorReportComponent } from './dashboards/admin-dashboard/reports/tutor-report/tutor-report.component';
import { StudentReportComponent } from './dashboards/admin-dashboard/reports/student-report/student-report.component';
import { ForgotPasswordComponent } from './utilities/modals/forgot-password/forgot-password.component';
import { StudentLoginRegComponent } from './user/Student/student-login-reg/student-login-reg.component';
import { SuccessRegisterModelComponent } from './utilities/modals/success-register-model/success-register-model.component';
import { UpdateStudentModelComponent } from './utilities/modals/update-student-model/update-student-model.component';
import { StudentProfileComponent } from './dashboards/student-dashboard/student-profile/student-profile.component';
import { ParentfeedbackReportComponent } from './dashboards/admin-dashboard/reports/parentfeedback-report/parentfeedback-report.component';
import { PfeedbackReportComponent } from './dashboards/admin-dashboard/reports/pfeedback-report/pfeedback-report.component';
import { UserReportComponent } from './dashboards/admin-dashboard/reports/user-report/user-report.component';
import { TuiRootModule, TuiDialogModule, TuiAlertModule, TuiCalendarModule, TuiNotificationModule, TuiButtonModule } from '@taiga-ui/core';
import { TuiRadioListModule, TuiBadgeModule } from '@taiga-ui/kit';

import { ContractComponent } from './pages/contract/contract.component';
import { ResetPasswordComponent } from './pages/reset-password/reset-password.component';
import { ChangePasswordModelComponent } from './utilities/modals/change-password-model/change-password-model.component';
import { EmailNotSentModalComponent } from './utilities/modals/email-not-sent-modal/email-not-sent-modal.component';
import { EmailSentModalComponent } from './utilities/modals/email-sent-modal/email-sent-modal.component';
import { IncorrectEmailComponent } from './utilities/modals/incorrect-email/incorrect-email.component';
import { LoginModalComponent } from './utilities/modals/login-modal/login-modal.component';
import { RegistrationEmailErrorComponent } from './utilities/modals/registration-email-error/registration-email-error.component';
import { SuccessfulEmailUpdateComponent } from './utilities/modals/successful-email-update/successful-email-update.component';
import { UnauthorizedAccessComponent } from './utilities/modals/unauthorized-access/unauthorized-access.component';
import { UnauthorizedAccessLoginComponent } from './utilities/modals/unauthorized-access-login/unauthorized-access-login.component';
import { UserExistModalComponent } from './utilities/modals/user-exist-modal/user-exist-modal.component';
import { ValidLoginModalComponent } from './utilities/modals/valid-login-modal/valid-login-modal.component';
import { StudentChangePasswordComponent } from './services/student-change-password/student-change-password.component';
import { StudentUpdateEmailComponent } from './dashboards/student-dashboard/student-update-email/student-update-email.component';
import { AddDiscountModalComponent } from './utilities/modals/add-discount-modal/add-discount-modal.component';
import { EditSuccessModalComponent } from './utilities/modals/edit-success-modal/edit-success-modal.component';
import { DeleteTutorModalComponent } from './utilities/modals/delete-tutor-modal/delete-tutor-modal.component';
import { DeleteSubjectModalComponent } from './utilities/modals/delete-subject-modal/delete-subject-modal.component';
import { DeleteDiscountModalComponent } from './utilities/modals/delete-discount-modal/delete-discount-modal.component';
import { DeleteSubjectGradeModalComponent } from './utilities/modals/delete-subject-grade-modal/delete-subject-grade-modal.component';
import { TutorRegSuccessModalComponent } from './utilities/modals/tutor-reg-success-modal/tutor-reg-success-modal.component';
import { AddGradeModalComponent } from './utilities/modals/add-grade-modal/add-grade-modal.component';
import { AddSubjectModalComponent } from './utilities/modals/add-subject-modal/add-subject-modal.component';
import { DeleteAdminModalComponent } from './utilities/modals/delete-admin-modal/delete-admin-modal.component';
import { WrongEmailComponent } from './utilities/modals/wrong-email/wrong-email.component';
import { FileDeletedModalComponent } from './utilities/modals/file-deleted-modal/file-deleted-modal.component';
import { FileUploadedModalComponent } from './utilities/modals/file-uploaded-modal/file-uploaded-modal.component';
import { AdminLoginRegComponent } from './user/Admin/admin-login-reg/admin-login-reg.component';
import { DeleteGradeModalComponent } from './utilities/modals/delete-grade-modal/delete-grade-modal.component';
import { MakeBookingComponent } from './dashboards/student-dashboard/make-booking/make-booking.component';
import { ViewBookingStudentComponent } from './dashboards/student-dashboard/view-booking/view-booking.component';
//import { ToastrModule } from 'ngx-toastr';
import {AddGradeComponent} from "./dashboards/tutor-dashboard/tutor-grades/add-grade/add-grade.component";
import {TutorHomeworkComponent} from "./dashboards/tutor-dashboard/tutor-homework/tutor-homework.component";
import {TutorOnlinevideoComponent} from "./dashboards/tutor-dashboard/tutor-onlinevideo/tutor-onlinevideo.component";
import {TutorMyprofileComponent} from "./dashboards/tutor-dashboard/tutor-myprofile/tutor-myprofile.component";
import {TutorSettingsComponent} from "./dashboards/tutor-dashboard/tutor-settings/tutor-settings.component";
import {TutorTimeslotsComponent} from "./dashboards/tutor-dashboard/tutor-timeslots/tutor-timeslots.component";
import {TutorGradesComponent} from "./dashboards/tutor-dashboard/tutor-grades/tutor-grades.component";
import {
  TutorGradeSubjectComponent
} from "./dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/tutor-grade-subject.component";
import {
  TutorAddSubjectComponent
} from "./dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/tutor-add-subject/tutor-add-subject.component";
import {TutorSubjectsComponent} from "./dashboards/tutor-dashboard/tutor-subjects/tutor-subjects.component";
import {BrowserAnimationsModule} from "@angular/platform-browser/animations";
import {TokenInterceptor} from "./user/auth/interceptors/TokenInterceptor";
import {TutorDashboardComponent} from "./dashboards/tutor-dashboard/tutor-dashboard.component";
import { TutorRegisterComponent } from './user/Tutor/tutor-register/tutor-register.component';
import { ViewMyBookingComponent } from './dashboards/tutor-dashboard/view-my-booking/view-my-booking.component';
import { environment } from 'src/environments/environment';
import { HomeworkscreenComponent } from './dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/homeworkscreen/homeworkscreen.component';


import { Angular4PaystackModule } from 'angular4-paystack';
import { VideoscreenComponent } from './dashboards/tutor-dashboard/tutor-grades/tutor-grade-subject/videoscreen/videoscreen.component';
import { SuccessTimeslotsComponent } from './utilities/modals/success-timeslots/success-timeslots.component';
import { DeleteerrorComponent } from './utilities/modals/deleteerror/deleteerror.component';
import { StudentHomeworkRecComponent } from './dashboards/student-dashboard/student-homework-rec/student-homework-rec.component';
import { DownloadComponent } from './dashboards/student-dashboard/student-homework-rec/download/download.component';
import { FileDeleteComponent } from './dashboards/student-dashboard/student-homework-rec/file-delete/file-delete.component';
import { UploadComponent } from './dashboards/student-dashboard/student-homework-rec/upload/upload.component';
import { UploadRecordingsComponent } from './upload-recordings/upload-recordings.component';
import { ViewrecordingsComponent } from './upload-recordings/viewrecordings/viewrecordings.component';
import { TutorHomeworkRecComponent } from './dashboards/tutor-dashboard/tutor-homework-rec/tutor-homework-rec.component';
import { TdownloadComponent } from './dashboards/tutor-dashboard/tutor-homework-rec/tdownload/tdownload.component';
import { UprecordingsComponent } from './upload-recordings/uprecordings/uprecordings.component';
import { VideoDeleteComponent } from './upload-recordings/video-delete/video-delete.component';
import { VideoDownloadComponent } from './upload-recordings/video-download/video-download.component';
import { VideoUploadComponent } from './upload-recordings/video-upload/video-upload.component';
import { SuccessfulBookingComponent } from './utilities/modals/successful-booking/successful-booking.component';
import { FailedBookingComponent } from './utilities/modals/failed-booking/failed-booking.component';
import { AuditReportComponent } from './dashboards/admin-dashboard/reports/audit-report/audit-report.component';
import { BookingReportComponent } from './dashboards/admin-dashboard/reports/booking-report/booking-report.component';
import { HelpFacilityComponent } from './pages/help-facility/help-facility.component';
import { HelpDocumentComponent } from './pages/help-facility/help-document/help-document.component';
import {MatSelectModule} from '@angular/material/select';
import { TutorAndSubjectsComponent } from './dashboards/admin-dashboard/tutors/tutor-and-subjects/tutor-and-subjects.component';

@NgModule({
  declarations: [
    AppComponent,
    WelcomeComponent,
    AboutUsComponent,
    SubjectsComponent,
    ContactComponent,
    TestimonialsComponent,
    ApplicationComponent,
    TutorDashboardComponent,
    AdminDashboardComponent,
    StudentDashboardComponent,
    UserAuthComponent,
    DiscountsComponent,
    PaymentsComponent,
    TutorsComponent,
    ReportsComponent,
    AdminFeedbackComponent,
    AdminSettingsComponent,
    AdminMyprofileComponent,
    AdminStudentsComponent,
    AdminTimeslotsComponent,
    AddDiscountComponent,
    EditDiscountComponent,
    TutorApplicationsComponent,
    TutorProfilesComponent,
    TutorHomeworkComponent,
    TutorOnlinevideoComponent,
    TutorRegistrationComponent,
    TutorLoginComponent,
    StudentLoginComponent,
    StudentRegistrationComponent,
    AdminLoginComponent,
    AddTimeslotComponent,
    EditTimeslotComponent,
    SuccessModalComponent,
    StudentSettingsComponent,
    AdminSubjectsComponent,
    AddSubjectComponent,
    EditSubjectComponent,
    TutorMyprofileComponent,
    TutorSettingsComponent,
    TutorReportComponent,
    StudentReportComponent,
    ForgotPasswordComponent,
    StudentLoginRegComponent,
    SuccessRegisterModelComponent,
    UpdateStudentModelComponent,
    StudentProfileComponent,
    ParentfeedbackReportComponent,
    PfeedbackReportComponent,
    UserReportComponent,
    TutorGradesComponent,
    AddGradeComponent,
    TutorGradeSubjectComponent,
    TutorAddSubjectComponent,
    ContractComponent,
    ResetPasswordComponent,
    ChangePasswordModelComponent,
    EmailNotSentModalComponent,
    EmailSentModalComponent,
    IncorrectEmailComponent,
    LoginModalComponent,
    RegistrationEmailErrorComponent,
    SuccessfulEmailUpdateComponent,
    UnauthorizedAccessComponent,
    UnauthorizedAccessLoginComponent,
    UserExistModalComponent,
    ValidLoginModalComponent,
    StudentChangePasswordComponent,
    StudentUpdateEmailComponent,
    AddDiscountModalComponent,
    EditSuccessModalComponent,
    DeleteTutorModalComponent,
    DeleteSubjectModalComponent,
    DeleteDiscountModalComponent,
    DeleteSubjectGradeModalComponent,
    TutorRegSuccessModalComponent,
    AddGradeModalComponent,
    AddSubjectModalComponent,
    DeleteAdminModalComponent,
    WrongEmailComponent,
    FileDeletedModalComponent,
    FileUploadedModalComponent,
    AdminLoginRegComponent,
    DeleteGradeModalComponent,

    TutorRegisterComponent,
    // /////////////
    ViewBookingStudentComponent,
    MakeBookingComponent,
    TutorSubjectsComponent,
    TutorTimeslotsComponent,
    ViewMyBookingComponent,
    HomeworkscreenComponent,
    VideoscreenComponent,
    SuccessTimeslotsComponent,
    DeleteerrorComponent,
    StudentHomeworkRecComponent,
    DownloadComponent,
    FileDeleteComponent,
    UploadComponent,
    UploadRecordingsComponent,
    ViewrecordingsComponent,
    TutorHomeworkRecComponent,
    TdownloadComponent,
    UprecordingsComponent,
    VideoDeleteComponent,
    VideoDownloadComponent,
    VideoUploadComponent,
    SuccessfulBookingComponent,
    FailedBookingComponent,
    AuditReportComponent,
    BookingReportComponent,
    HelpFacilityComponent,
    HelpDocumentComponent,
    TutorAndSubjectsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    MaterialModule,
    FormsModule,
    ReactiveFormsModule,
    RouterModule,
    HttpClientModule,
    BrowserAnimationsModule,
    TuiRootModule,
    TuiRootModule,
    TuiDialogModule,
    TuiAlertModule,
    TuiCalendarModule,
    TuiRadioListModule,
    TuiNotificationModule,
    TuiBadgeModule,
    // TutorModule,
    // NgbModule,
    TuiButtonModule,
    //ToastrModule.forRoot(),
    Angular4PaystackModule.forRoot(environment.paystack_key),
    MatSelectModule



  ],
  providers: [
    {
      provide: 'SocialAuthServiceConfig',
      useValue: {
        autoLogin: false,
        providers: [
          {
            id: GoogleLoginProvider.PROVIDER_ID,
            provider: new GoogleLoginProvider('425306728191-s40js5hqs4p077hho08cqb0bbc1nta6k.apps.googleusercontent.com'),
          },
        ],
      } as SocialAuthServiceConfig,
    },
    {provide: HTTP_INTERCEPTORS, useClass: TokenInterceptor, multi: true}
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }
