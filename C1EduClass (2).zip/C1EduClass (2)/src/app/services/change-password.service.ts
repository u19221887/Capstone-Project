import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ChangePassword } from '../shared/changePassword';


@Injectable({
  providedIn: 'root'
})
export class ChangePasswordService {

  apiUrl = 'https://localhost:7225/api/'

  httpOptions ={
    headers: new HttpHeaders({
      ContentType: 'application/json'
    })
  }


  constructor(private httpClient: HttpClient) { }

  changePassword(changePassword: ChangePassword){
    return this.httpClient.post(`${this.apiUrl}Authenticate/changepassword`,changePassword, this.httpOptions)
  }
}