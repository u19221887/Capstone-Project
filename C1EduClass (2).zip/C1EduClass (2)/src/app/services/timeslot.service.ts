import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { TutorAvailabilityTime } from '../shared/models/tutorAvailabilityTime.model';

@Injectable({
  providedIn: 'root'
})
export class TimeslotService {

  apiUrl = 'https://localhost:7225/api/Availability'

  httpOptions={
      headers : new HttpHeaders({
          ContentType:'application/json'
      })
  }

  constructor(private httpClient:HttpClient){

  }

  getCompanyAvailabilityTimes(): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/GetAllCompanyAvailabilityTimes`)
      .pipe(map(result => result))
  }

  //GetAllAvailabilityTimes

  getAllAvailabilityTimes(date:string):Observable<TutorAvailabilityTime>
  {
      return this.httpClient.get<TutorAvailabilityTime>(`${this.apiUrl}/GetAllAvailabilityTimes/${date}`)
      .pipe(map(result => result))
  }

  addTutorAvailabilityTimes(availabilityTimes: TutorAvailabilityTime)
    {
        return this.httpClient.post(`${this.apiUrl}/AddTutorAvailabilityTimes`, availabilityTimes, this.httpOptions)
    }

    
    
}
