import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Student } from '../shared/student';
import { Observable } from 'rxjs/internal/Observable';
import { map } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class StudentService {


  apiUrl = 'https://localhost:7225/api/'

  httpOptions ={
    headers: new HttpHeaders({
      ContentType: 'application/json'
    })
  }

  constructor(private httpClient: HttpClient) { }

  addStudent(student:Student){
    return this.httpClient.post(`${this.apiUrl}Student/AddStudent`, student, this.httpOptions)
}


getStudent(studentId:Number) {
  return this.httpClient.get(this.apiUrl + `Student/GetStudent/${studentId}`);
}

updateStudent(studentId:Number,student:Student) {
  return this.httpClient.put(this.apiUrl + `Student/EditStudent/${studentId}`, student,this.httpOptions);
}

//get all

getAllStudent(): Observable<any> {
  return this.httpClient.get(this.apiUrl + `Student/GetAllStudents`)
  .pipe(map(result=>result))
}

countStudents() {
  return this.httpClient.get(this.apiUrl + `Student/CountStudents`);
}


}
