import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder,Validators,FormControl, FormGroup, AbstractControl } from '@angular/forms';
import { ChangePassword } from 'src/app/shared/changePassword';
import { ChangePasswordService } from 'src/app/services/change-password.service';
import { MatDialog } from '@angular/material/dialog';
import { ChangePasswordModelComponent } from 'src/app/utilities/modals/change-password-model/change-password-model.component';
import { MatSnackBar } from '@angular/material/snack-bar';
import { IncorrectEmailComponent } from 'src/app/utilities/modals/incorrect-email/incorrect-email.component';

import { UnauthorizedAccessComponent } from 'src/app/utilities/modals/unauthorized-access/unauthorized-access.component';


@Component({
  selector: 'app-student-change-password',
  templateUrl: './student-change-password.component.html',
  styleUrls: ['./student-change-password.component.scss']
})
export class StudentChangePasswordComponent implements OnInit{

  constructor( private snackBar: MatSnackBar,private studentService:StudentService ,  private dialog: MatDialog, private changePasswordService: ChangePasswordService, private router : Router, private activated:ActivatedRoute, private formBuilder: FormBuilder) { }
  changePassword!: FormGroup

  getStudent!: Student
  students!: Student []

  ngOnInit(): void {



    this.changePassword = this.formBuilder.group({

      email: ['', [Validators.required, Validators.email]],
      password: ['', [
        Validators.required,
        Validators.minLength(6),
        this.passwordPatternValidator()
      ]],
      newPassword: ['', [
        Validators.required,
        Validators.minLength(6),
        this.passwordPatternValidator()
      ]],

    },

    );


    let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

  this.studentService.getAllStudent().subscribe(response => {


     this.students = response as Student[];
     console.log(this.students)
     this.getStudent=this.students.find(x=> x.studentEmail==o.username)!
      console.log(this.getStudent,this.students)


    })



    this.changePassword.patchValue({

      email: this.getStudent.studentEmail,

    });

}


passwordPatternValidator() {
  return (control: FormControl) => {
    const password = control.value;
    const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{6,}$/;

    if (passwordPattern.test(password)) {
      return null;
    } else {
      return { invalidPassword: true };
    }
  };


}




onSubmit(): void {
  if (this.changePassword.valid) {

    console.log(this.changePassword.value);


  } else {

    this.validateAllFormFields(this.changePassword);
  }


}

validateAllFormFields(formGroup: FormGroup): void {
  Object.keys(formGroup.controls).forEach(field => {
    const control = formGroup.get(field)!;
    if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    } else {
      control.markAsTouched({ onlySelf: true });
    }
  });



}



emailValidator(control: FormControl): { [key: string]: boolean } | null {
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  if (control.value && !emailPattern.test(control.value)) {
    return { invalidEmail: true };
  }

  return null;
}


confirmButton() {
  if (this.changePassword.valid) {
    let changePassword = new ChangePassword();
    changePassword.Email = this.changePassword.value.email;
    changePassword.CurrentPassword = this.changePassword.value.password;
    changePassword.NewPassword = this.changePassword.value.newPassword;

    this.changePasswordService.changePassword(changePassword).subscribe(
      (response: any) => {
        this.showModal();
        console.log('Success:', response);
      },
      (error: any) => {
        if (error.status === 500) {
          this.incorrectEmaildModal();
        }else if (error.status === 404) {
          this.unauthorizedAccessModal();
        }
        else {
          this.snackBar.open(`An error occurred: ${error.message}`, 'X', { duration: 5000 });
        }
      }
    );
  } else {
    this.validateAllFormFields(this.changePassword);

  }
}


  showModal() {
    const dialogRef = this.dialog.open(ChangePasswordModelComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.changePassword.reset();
    });
  }


  incorrectEmaildModal() {
    const dialogRef = this.dialog.open(IncorrectEmailComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.changePassword.reset();
    });
  }


  unauthorizedAccessModal() {
    const dialogRef = this.dialog.open(UnauthorizedAccessComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.changePassword.reset();
    });
  }
}






