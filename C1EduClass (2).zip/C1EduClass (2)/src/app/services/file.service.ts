import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class FileService {
  private apiUrl = 'http://localhost:3000/api';

  constructor(private http: HttpClient) { }

  uploadFile(file: File, containerName: string): Observable<any> {
    const formData = new FormData();
    formData.append('file', file);

    // Append the containerName as a query parameter in the URL
    return this.http.post<any>(`${this.apiUrl}/upload/${containerName}`, formData);
  }

  downloadFile(filename: string, containerName: string): Observable<any> {
    // Append the containerName as a query parameter in the URL
    return this.http.get(`${this.apiUrl}/download/${containerName}/${filename}`, { responseType: 'arraybuffer' });
  }

  deleteFile(filename: string, containerName: string): Observable<any> {
    const apiUrl = `${this.apiUrl}/delete/${containerName}/${filename}`;
    return this.http.delete(apiUrl);
  }

  getFilesList(containerName: string): Observable<string[]> {
    // Append the containerName as a query parameter in the URL
    return this.http.get<string[]>(`${this.apiUrl}/list/${containerName}`);
  }
}
