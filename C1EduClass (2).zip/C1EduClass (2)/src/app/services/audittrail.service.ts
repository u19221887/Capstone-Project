import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { map } from 'rxjs';
import { Observable } from 'rxjs/internal/Observable';

@Injectable({
  providedIn: 'root'
})
export class AudittrailService {

  apiUrl = 'https://localhost:7225/api/'

  httpOptions={
      headers : new HttpHeaders({
          ContentType:'application/json'
      })
  }

  constructor(private httpClient:HttpClient){

  }

  addAuditTrail(file: FormData)
  {
    return this.httpClient.post(`${this.apiUrl}Audit/AddAuditTrail`, file)
  }

  getAllAuditTrail():Observable<any>
  {
    return this.httpClient.get(`${this.apiUrl}Audit/GetAllAuditTrail`)
    .pipe(map(result=>result))
  }

  getAllAuditTrailByUser(role : string):Observable<any>
  {
    return this.httpClient.get(`${this.apiUrl}Audit/GetAuditTrailByUser/`+role)
    .pipe(map(result=>result))
  }
}
