import { Injectable } from '@angular/core';
import { Observable, map, of} from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { LoginUser } from '../shared/login';
import { User } from '../shared/user';

@Injectable({
  providedIn: 'root'
})
export class LoginService {


  apiUrl = 'https://localhost:7225/api/'

httpOptions ={
  headers: new HttpHeaders({
    ContentType: 'application/json'
  })
}


  constructor(private httpClient: HttpClient) { }

  LoginStudent(loginUser: LoginUser){
    return this.httpClient.post<User>(`${this.apiUrl}Authenticate/student-login`, loginUser, this.httpOptions)
  }

  LoginAdmin(loginUser: LoginUser){
    return this.httpClient.post<User>(`${this.apiUrl}Authenticate/admin-login`, loginUser, this.httpOptions)
  }

  LoginTutor(loginUser: LoginUser){
    return this.httpClient.post<User>(`${this.apiUrl}Authenticate/tutor-login`, loginUser, this.httpOptions)
  }
}
