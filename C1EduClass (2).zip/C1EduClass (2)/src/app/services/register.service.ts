import { Injectable } from '@angular/core';
import { Observable, map, of} from 'rxjs';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { RegisterUser } from '../shared/register';

@Injectable({
  providedIn: 'root'
})
export class RegisterService {

  apiUrl = 'https://localhost:7225/api/'

httpOptions ={
  headers: new HttpHeaders({
    ContentType: 'application/json'
  })
}

constructor(private httpClient: HttpClient) { }
RegisterUser(registerUser: RegisterUser){
  return this.httpClient.post(`${this.apiUrl}Authenticate/registerStudent`,registerUser, this.httpOptions)
}

RegisterAdmin(registerUser: RegisterUser){
  return this.httpClient.post(`${this.apiUrl}Authenticate/registerAdmin`,registerUser, this.httpOptions)
}

RegisterTutor(registerUser: RegisterUser){
  return this.httpClient.post(`${this.apiUrl}Authenticate/registerTutor`,registerUser, this.httpOptions)
}

tutorEmail(tutorAcceptance : string){
  return this.httpClient.post(`${this.apiUrl}Authenticate/TutorAcceptance/`+ tutorAcceptance, this.httpOptions)
}
}
