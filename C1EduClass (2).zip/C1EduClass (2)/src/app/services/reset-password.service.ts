import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ResetPassword } from '../shared/resetPassword';

@Injectable({
  providedIn: 'root'
})
export class ResetPasswordService {


  apiUrl = 'https://localhost:7225/api/'

  httpOptions ={
    headers: new HttpHeaders({
      ContentType: 'application/json'
    })
  }
  


  constructor(private httpClient: HttpClient) { }

  resetPassword(resetPassword: ResetPassword){
    return this.httpClient.post(`${this.apiUrl}Authenticate/ResetPassword`,resetPassword, this.httpOptions)
  }

}
