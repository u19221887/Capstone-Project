import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ForgotPassword } from '../shared/forgotPassword';


@Injectable({
  providedIn: 'root'
})
export class ForgotPasswordService {

  apiUrl = 'https://localhost:7225/api/'

httpOptions ={
  headers: new HttpHeaders({
    ContentType: 'application/json'
  })
}

  constructor(private httpClient: HttpClient) { }

  forgotPassword(forgotPassword: ForgotPassword){
    return this.httpClient.post(`${this.apiUrl}Authenticate/ForgotPassword`,forgotPassword, this.httpOptions)
  }
}