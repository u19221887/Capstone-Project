import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class PaymentService {

  //get ref from environment

  public ref = environment.paymentRef+Math.floor((Math.random() * 1000000000) + 1).toString();
  public currency = 'ZAR';

constructor() { }

paymentInit() {
  console.log('Payment initialized');
}



paymentCancel() {
  console.log('payment failed');
}

}
