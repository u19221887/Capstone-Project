import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';
import { Booking } from '../shared/models/booking.model';

@Injectable({
  providedIn: 'root'
})
export class BookingService {


  apiUrl = 'https://localhost:7225/api/Booking'

    httpOptions={
        headers : new HttpHeaders({
            ContentType:'application/json'
        })
    }

    constructor(private httpClient:HttpClient){

    }

  //MakeBooking Post
  makeBooking(booking: Booking)
  {
      return this.httpClient.post(`${this.apiUrl}/MakeBooking`, booking)
  }

  //get Booking/ViewBookingSession/1


  getBookingSessionsStudent(id : number): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/ViewBookingSession/`+id)
      .pipe(map((result: any) => result))
  }
  getBookingSessionsAdmin(): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/ViewAdminBookingSession`)
      .pipe(map((result: any) => result))
  }

  //Booking/ViewBookingSessionTutor/1

  getBookingSessionTutor(): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/ViewBookingSessionTutor`)
      .pipe(map((result: any) => result))
  }

  updateBookingStatus(bookingObjt: any) {
    return this.httpClient.post(`${this.apiUrl}/UpdateBookingStatus`,bookingObjt, this.httpOptions )
    .pipe(map((result: any) => result))
  }

  //get online
  getOnlineBookings(): Observable<any>
      {
          return this.httpClient.get(`${this.apiUrl}/ViewAllOnlineBookingSession`)
          .pipe(map(result => result))
      }

  getInPersonBookings(): Observable<any>
    {
      return this.httpClient.get(`${this.apiUrl}/ViewAllInPersonBookingSession`)
      .pipe(map(result => result))
    } 
    
    getTotal() {
      return this.httpClient.get(`${this.apiUrl}/ViewTotal`)
      .pipe(map(result => result))
    }
}
