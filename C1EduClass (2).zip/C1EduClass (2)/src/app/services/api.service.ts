import { HttpClient, HttpHeaders, HttpParams } from '@angular/common/http';
import {Injectable} from '@angular/core';
import { map, Observable } from 'rxjs';
import { Discount } from '../shared/discount';
import { TutorApplication } from '../shared/tutorapplications';
import { Form } from '@angular/forms';
import { Timeslot } from '../shared/timeslot';
import { Student } from '../shared/student';
import { Admin } from '../shared/admin';
import { Subject } from '../shared/subject';
import { Tutor } from '../shared/tutor';
import { ParentFeedback } from '../shared/parentfeedback';
import {TutorGrade} from '../shared/models/tutorGrade.model'

@Injectable({
    providedIn: 'root'
})

export class APIService{

    
    apiUrl = 'https://localhost:7225/api/'

    httpOptions={
        headers : new HttpHeaders({
            ContentType:'application/json'
        })
    }

    constructor(private httpClient:HttpClient){

    }

    getActiveDiscounts(): Observable<any>
    {
        return this.httpClient.get(`${this.apiUrl}Discount/GetActiveDiscounts`)
        .pipe(map(result => result))
    }

    getInactiveDiscounts(): Observable<any>
    {
        return this.httpClient.get(`${this.apiUrl}Discount/GetInactiveDiscounts`)
        .pipe(map(result => result))
    }

    deleteDiscount(discountId: Number)
    {
        return this.httpClient.delete<string>(`${this.apiUrl}Discount/DeleteDiscount` + "/" + discountId, this.httpOptions)
    }

    addDiscount(file: FormData)
    {
        return this.httpClient.post(`${this.apiUrl}Discount/AddDiscount`, file)
    }

    editDiscount(discountId: Number, discount: Discount)
    {
        return this.httpClient.put(`${this.apiUrl}Discount/UpdateDiscount/${discountId}`,discount, this.httpOptions)
    }

    AddTutorApplication(file: FormData)
    {
        return this.httpClient.post(`${this.apiUrl}TutorApplication/AddTutorApplication`, file)
    }

    GetPendingTutorApplications(): Observable<any>
    {
        return this.httpClient.get(`${this.apiUrl}TutorApplication/GetPendingTutorApplications`)
        .pipe(map(result => result)) 
    }

    GetApprovedTutorApplications(): Observable<any>
    {
        return this.httpClient.get(`${this.apiUrl}TutorApplication/GetApprovedTutorApplications`)
        .pipe(map(result => result)) 
    }


    AcceptTutorApplication(tutorApplicationId: Number)
    {
        return this.httpClient.patch(`${this.apiUrl}TutorApplication/AcceptTutorApplication`+"/"+ tutorApplicationId, this.httpOptions)
    }

    RejectTutorApplication(tutorApplicationId: Number)
    {
        return this.httpClient.patch(`${this.apiUrl}TutorApplication/RejectTutorApplication`+"/"+ tutorApplicationId, this.httpOptions)
    }

    getTutorTypes(): Observable<any>{
        return this.httpClient.get(`${this.apiUrl}Tutor/TutorTypes`)
        .pipe(map((result: any) => result))
    }

    getTutorApplication(tutorApplicationId: Number){
        return this.httpClient.get(`${this.apiUrl}Tutor/GetTutorApplication`+"/"+tutorApplicationId)
        .pipe(map(result => result))
    }

    addTutor( tutorApplicationId: Number, file: FormData){
        
        return this.httpClient.post(`${this.apiUrl}Tutor/AddTutor`+"/"+ tutorApplicationId, file)

    }

    addTutorByAdmin(tutorApplicationId: Number){
        
      return this.httpClient.post(`${this.apiUrl}Tutor/AddTutorByAdmin/` + tutorApplicationId,this.httpOptions)

  }


    getTutorFromTutorApplication(tutorApplicationId: Number){
        return this.httpClient.get(`${this.apiUrl}Tutor/GetTutorFromTutorApplication`+"/"+ tutorApplicationId)
        .pipe(map(result=>result))
    }

    getDiscountStatuses(): Observable<any>{
        return this.httpClient.get(`${this.apiUrl}Discount/GetDiscountStatuses`)
        .pipe(map((result: any) => result))
    }

    getDiscount(discountId : Number){
        return this.httpClient.get(`${this.apiUrl}Discount/GetDiscount`+"/"+ discountId)
    }

    getTutorProfile(tutorEmail : string){
        return this.httpClient.get(`${this.apiUrl}Tutor/GetTutorProfile`+"/"+ tutorEmail)
    }

    getAdminProfile(adminEmail : string){
        return this.httpClient.get(`${this.apiUrl}Admin/GetAdminProfile`+"/"+ adminEmail)
    }

    getStudentProfile(studentEmail : string){
        return this.httpClient.get(`${this.apiUrl}Student/GetStudentProfile`+"/"+ studentEmail)
    }

    createStudent(file: FormData){
        return this.httpClient.post(`${this.apiUrl}Student/AddStudent`, file)
    }

    getTimeslot(timeslotId: number) {
        return this.httpClient.get(`${this.apiUrl}Timeslot/GetTimeslot` + "/" + timeslotId)
        .pipe(map(result => result))
      }

    getTimeslots(): Observable<any>{
        return this.httpClient.get(`${this.apiUrl}Timeslot/GetAllTimeslots`)
        .pipe(map(result => result))
      }
      addTimeslot(timeslot: Timeslot)
      {
        return this.httpClient.post(`${this.apiUrl}Timeslot/AddTimeslot`, timeslot, this.httpOptions)
      }
    
      deleteTimeslot(timeslotId: Number)
      {
        return this.httpClient.delete<string>(`${this.apiUrl}Timeslot/DeleteTimeslot` + "/" + timeslotId, this.httpOptions)
      }
    
      editTimeslot(timeslotId: number, timeslot: Timeslot)
      {
        return this.httpClient.put(`${this.apiUrl}Timeslot/EditTimeslot${timeslotId}`,timeslot, this.httpOptions)
      }

      getStudent(studentId: number) {
        return this.httpClient.get(`${this.apiUrl}Student/GetStudent` + "/" + studentId)
        .pipe(map(result => result))
      }
    
      getStudents(): Observable<any>{
        return this.httpClient.get(`${this.apiUrl}Student/GetAllStudents`)
        .pipe(map(result => result))
      }
    
      addStudent(student: Student)
      {
        return this.httpClient.post(`${this.apiUrl}Student/AddStudent`, student, this.httpOptions)
      }
    
      deleteStudent(studentId: Number)
      {
        return this.httpClient.delete<string>(`${this.apiUrl}Student/DeleteStudent` + "/" + studentId, this.httpOptions)
      }
    
      editStudent(studentId: number, student: Student)
      {
        return this.httpClient.put(`${this.apiUrl}Student/EditStudent${studentId}`,student, this.httpOptions)
      }

      addAdmin(admin:Admin){
        return this.httpClient.post(`${this.apiUrl}Admin/AddAdmin`, admin, this.httpOptions)
    }

    getAdmin(adminId: number) {
      return this.httpClient.get(`${this.apiUrl}Admin/GetAdmin` + "/" + adminId)
      .pipe(map(result => result))
    }
  

    getAdmins(): Observable<any>{
      return this.httpClient.get(`${this.apiUrl}Admin/GetAllAdmins`)
      .pipe(map(result => result))
    }

    deleteAdmin(adminId: Number)
    {
      return this.httpClient.delete<string>(`${this.apiUrl}Admin/DeleteAdmin` + "/" + adminId, this.httpOptions)
    }
  
    editAdmin(adminId: number, admin: Admin)
    {
      return this.httpClient.put(`${this.apiUrl}Admin/EditAdmin${adminId}`,admin, this.httpOptions)
    }
    getSubject(subjectId: number) {
        return this.httpClient.get(`${this.apiUrl}Subject/GetSubject` + "/" + subjectId)
        .pipe(map(result => result))
      }
    
      getSubjects(): Observable<any>{
        return this.httpClient.get(`${this.apiUrl}Subject/GetAllSubjects`)
        .pipe(map(result => result))
      }
    
      addSubject(subject: Subject)
      {
        return this.httpClient.post(`${this.apiUrl}Subject/AddSubject`, subject, this.httpOptions)
      }
    
      deleteSubject(subjectId: Number)
      {
        return this.httpClient.delete<string>(`${this.apiUrl}Subject/DeleteSubject` + "/" + subjectId, this.httpOptions)
      }
    
      editSubject(subjectId: number, subject: Subject)
      {
        return this.httpClient.put(`${this.apiUrl}Subject/EditSubject${subjectId}`,subject, this.httpOptions)
      }



      //Tutor
      getAllTutors(): Observable<any>
    {
        return this.httpClient.get(`${this.apiUrl}Tutor/GetAllTutors`)
        .pipe(map(result => result))
    }

    deleteTutor(tutorId: Number)
    {
      return this.httpClient.delete<string>(`${this.apiUrl}Tutor/DeleteTutor` + "/" + tutorId, this.httpOptions)
    }

    getTutor(tutorId: number) {
      return this.httpClient.get(`${this.apiUrl}Tutor/GetTutor` + "/" + tutorId)
      .pipe(map(result => result))
    }

    editTutor(tutorId: Number, file: FormData)
    {
        return this.httpClient.put(`${this.apiUrl}Tutor/UpdateTutor/`+tutorId,file, this.httpOptions)
    }



    addFeedback(studentId: Number, file: FormData){
        return this.httpClient.post(`${this.apiUrl}ParentFeedback/AddFeedback`+"/" + studentId, file)
    }

    getAllFeedback(): Observable<any>
    {
      return this.httpClient.get(`${this.apiUrl}ParentFeedback/GetAllFeedback`)
      .pipe(map(result => result))

      
    }

    //count 

    countTutor(){
      return this.httpClient.get(`${this.apiUrl}Tutor/CountTutors`)
      .pipe(map(result => result))
    }

    countFulltime(){
      return this.httpClient.get(`${this.apiUrl}Tutor/CountFulltime`)
      .pipe(map(result => result))
    }

    countParttime(){
      return this.httpClient.get(`${this.apiUrl}Tutor/CountParttime`)
      .pipe(map(result => result))
    }

    countAdmin(){
      return this.httpClient.get(`${this.apiUrl}Tutor/CountAdmins`)
      .pipe(map(result => result))
    }

    countStudent(){
      return this.httpClient.get(`${this.apiUrl}Tutor/CountStudents`)
      .pipe(map(result => result))
    }

    
    
    //GRADES

    getGradeById(gradeid: Number) {

      return this.httpClient.get(`${this.apiUrl}Grade/GetGradeById` + "/" + gradeid)
      .pipe(map(result => result))

    }
    getAllGradesforTutor(idvalue: Number) {
      return this.httpClient.get(`${this.apiUrl}Grade/GetAllGradesforTutor` + "/" + idvalue)
      .pipe(map(result => result))
    }

    getAllGrades() : Observable<any>{
      return this.httpClient.get(`${this.apiUrl}Grade/GetAllGrades`)
        .pipe(map(result => result))
    }

    addTutorGrades(tutorGrades: TutorGrade)
    {
        return this.httpClient.post(`${this.apiUrl}Grade/AddTutorGrades`,tutorGrades, this.httpOptions)
    }

    getGradeName(id : Number): Observable<any>{
      return this.httpClient.get(`${this.apiUrl}Grade/GetGradeName` +"/" + id)
      .pipe(map(result=>result))
    }

    getGradesforTutorThatTheyCanAdd(id: Number): Observable<any>{
      return this.httpClient.get(`${this.apiUrl}Grade/GetGradesforTutorThatTheyCanAdd` +"/" + id)
      .pipe(map(result=>result))
    }

    deleteTutorGrade(tutorid: Number, gradeid:Number){
      return this.httpClient.delete<string>(`${this.apiUrl}Grade/DeleteTutorGrade` + "/" + {tutorid, gradeid} , this.httpOptions)
    }

    getTutorGrade(gradeId : Number){
      return this.httpClient.get(`${this.apiUrl}Grade/GetTutorGrade` + "/" + gradeId)
      .pipe(map(result => result))
    }
    getTutorGradefromGradeId(gradeId : Number){
      return this.httpClient.get(`${this.apiUrl}Grade/GetTutorGradefromGradeId` + "/" + gradeId)
      .pipe(map(result => result))
    }

    
    //tutorgrade-subjects
    getTutorGradeforSubject(tutorGradeId: number){
      return this.httpClient.get(`${this.apiUrl}Subject/GetTutorGradeforSubject` + "/" + tutorGradeId)
      .pipe(map(result => result))
    }

    getAllSubjectsforTutor(idvalue: Number) {
      return this.httpClient.get(`${this.apiUrl}Subject/GetAllSubjectsforTutor` + "/" + idvalue)
      .pipe(map(result => result))
    }

  

    addTutorGradeSubjects(tutorGradesSubjects: TutorGrade)
    {
        return this.httpClient.post(`${this.apiUrl}Subject/AddTutorGradeSubjects`,tutorGradesSubjects, this.httpOptions)
    }

    getSubjectName(id : Number): Observable<any>{
      return this.httpClient.get(`${this.apiUrl}Subject/GetSubjectName` +"/" + id)
      .pipe(map(result=>result))
    }

    getSubjectsforTutorThatTheyCanAdd(id: Number): Observable<any>{
      return this.httpClient.get(`${this.apiUrl}Subject/GetSubjectsforTutorThatTheyCanAdd` +"/" + id)
      .pipe(map(result=>result))
    }

    deleteTutorGradeSubject(tutorgradeid: Number, subjectid:Number){
      return this.httpClient.delete<string>(`${this.apiUrl}Subject/DeleteTutorGradeSubject` + "/" + {tutorgradeid, subjectid} , this.httpOptions)
    }

    
    getGradeSubjectId(subjectid: Number, gradeid : Number){
      return this.httpClient.get(`${this.apiUrl}Subject/GetGradeSubjectId/`+{subjectid,gradeid})
        .pipe(map(result=>result))
      }
  
      addRecordings(subject: FormData){
        return this.httpClient.post(`${this.apiUrl}Recordings/AddRecordings`, subject, this.httpOptions)
      }
  
      getRecordingsDetails(subject_Id : number){
        return this.httpClient.get(`${this.apiUrl}Recordings/GetRecordingsDetails` + "/" + subject_Id )
        .pipe(map(result => result))
      }
  
      getAllRecordingDetails(){
        return this.httpClient.get(`${this.apiUrl}Recordings/GetAllRecordingsDetails`)
        .pipe(map(result => result))
      }
  
      getSearchedRecordingsDetails(enteredQuery : string): Observable<any>{
        return this.httpClient.get<any>(`${this.apiUrl}Recordings/GetSearchedRecordingsDetails/${enteredQuery}`).pipe(map( result => result));
      }
  
      updateRecording(recording_ID: number, updatedRecording: FormData){
        return this.httpClient.put(this.apiUrl + `Recordings/EditRecording/${recording_ID}`, updatedRecording)
      }
  
      deleteRecordings(recording_ID: number){
        return this.httpClient.delete(this.apiUrl + `Recordings/DeleteRecording/${recording_ID}`)
      }
      
      GenerateVideoStreamLink(fileName: string): Observable<string> {
        return this.httpClient.get(this.apiUrl + `Recordings/GenerateBlobStreamLink/${fileName}`, { responseType: 'text' });
    }
    
    countBookings(){
      return this.httpClient.get(`${this.apiUrl}Booking/CountBookings`)
      .pipe(map(result => result))
    }

    countOnline(){
      return this.httpClient.get(`${this.apiUrl}Booking/CountOnline`)
      .pipe(map(result => result))
    }

    countInPerson(){
      return this.httpClient.get(`${this.apiUrl}Booking/CountInPerson`)
      .pipe(map(result => result))
    }

    getTutorsThatTutorThatSubject(subjectid: number, grade:number, date: string){
      let params = new HttpParams()
      .set('subjectid', subjectid.toString())
      .set('grade', grade.toString())
      .set('date', date);
      return this.httpClient.get(`${this.apiUrl}Subject/GetTutorThatTutorsThatSubject`, { params: params })
      .pipe(map(result => result))
    }

    addInitialGradeAndSubject(email :string)
    {
      return this.httpClient.post(`${this.apiUrl}TutorApplication/AddInitialGradeAndSubject/`+ email, this.httpOptions)
    }


    getSubjectById(id : number){
      return this.httpClient.get(`${this.apiUrl}Subject/GetSubjectsById`+"/"+ id)
  }

      //BookingStatus

      checkBookingStatus(id: number){
        return this.httpClient.get(`${this.apiUrl}Booking/CheckBookingStatus/` + id).pipe(map(result => result))
      }


      //list
      getTutorList(): Observable<any>
      {
          return this.httpClient.get(`${this.apiUrl}Subject/GetTutorList`)
          .pipe(map(result => result))
      }
}