import { HttpHeaders, HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable, map } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class TutorService {

  apiUrl = 'https://localhost:7225/api/Tutor'

  httpOptions ={
    headers: new HttpHeaders({
      ContentType: 'application/json'
    })
  }

    constructor(private httpClient: HttpClient) { }

    

 //get my subjects
 getMySubjects(){
  return this.httpClient.get(this.apiUrl+'/GetMyTutorSubjects');
}

//link subject to tutor
linkSubjectToTutor(subjectLink:any){

  const body = {
    TutorId:subjectLink.tutorId,
    SubjectId:subjectLink.subjectId
  }

  return this.httpClient.post('https://localhost:7225/api/Subject/LinkSubjectToTutor',body,this.httpOptions);
}

//get all subjects
getAllSubjects(){
  return this.httpClient.get('https://localhost:7225/api/Subject/GetAllSubjects');
}

//unlink subject from tutor
unlinkSubjectFromTutor(subTutorId:number){


    return this.httpClient.delete(`https://localhost:7225/api/Subject/UnlinkSubjectToTutor/${subTutorId}`);
  }


  getMyTutorSubjects(id: number): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/GetMyTutorSubjects/${id}`)
      .pipe(map(result => result))
  }

  getSubjectsLinkedToTutor(id: number): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/GetSubjectsLinkedToTutor/${id}`)
      .pipe(map(result => result))
  }

  
  getTutorSubjects(id: number): Observable<any>
  {
      return this.httpClient.get(`${this.apiUrl}/GetTutorSubjects/${id}`)
      .pipe(map(result => result))
  }
}
