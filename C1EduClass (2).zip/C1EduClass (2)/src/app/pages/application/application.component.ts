import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { APIService } from '../../services/api.service';
import { Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormBuilder } from '@angular/forms';


@Component({
  selector: 'app-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss']
})
export class ApplicationComponent implements OnInit {

  formData = new FormData();
  fileNameUploaded=''

  
  
  applicationForm: FormGroup= this.fb.group({
      name : ['', Validators.required],
      lname : ['', Validators.required],
      pnumber :  ['', Validators.required],
      email: ['', [Validators.required, Validators.email]],
      file : ['', Validators.required],
      grade :['', Validators.required],
      subject : ['', Validators.required]



    })

    constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar)
    {
      this.getAllSubject();
    }

    ngOnInit(){
    
    }

    uploadFile= (files:any)=>{
      let fileToUpload = <File>files[0];
      this.formData.append('file', fileToUpload,fileToUpload.name);
      this.fileNameUploaded= fileToUpload.name;
    }

    mySubjects : any [] =[];

    getAllSubject(){
      this.apiService.getSubjects().subscribe((result : any)=>{
        this.mySubjects = result
      })
    }
    
    onSubmit(){
      if (this.applicationForm.valid)
      {
        this.formData.append('name', this.applicationForm.get('name')!.value);
        this.formData.append('lname', this.applicationForm.get('lname')!.value);
        this.formData.append('pnumber', this.applicationForm.get('pnumber')!.value);
        this.formData.append('email', this.applicationForm.get('email')!.value);
        this.formData.append('grade', this.applicationForm.get('grade')!.value);
        this.formData.append('subject', this.applicationForm.get('subject')!.value);

        this.apiService.AddTutorApplication(this.formData).subscribe(()=> {
          this.clearData()
          this.router.navigateByUrl('user').then((navigated: boolean)=> {
            if (navigated){
              this.snackBar.open(this.applicationForm.get('name')!.value + ` upload successfully`, 'X', {duration: 5000});
            }
          });
        });
      }
    }

    clearData(){
      this.formData.delete("file");
      this.formData.delete("name");
      this.formData.delete("lname");
      this.formData.delete("pnumber");
      this.formData.delete("email");
    }

    emailValidator(control: FormControl): { [key: string]: boolean } | null {
      const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;
  
      if (control.value && !emailPattern.test(control.value)) {
        return { invalidEmail: true };
      }
  
      return null;
    }
}
