import { Component } from '@angular/core';

@Component({
  selector: 'app-help-document',
  templateUrl: './help-document.component.html',
  styleUrls: ['./help-document.component.scss']
})
export class HelpDocumentComponent {

  searchQuery: string = '';

  // Define an array of cards
  cards: { header: string, body: string, pdfUrl: string, isVisible: boolean }[] = [
    {
      header: 'Make Booking',
      body: 'A complete guide on how to go about making a booking.',
      pdfUrl: 'assets/pdfs/Make Booking Guide.pdf',
      isVisible: true // Set to true initially
    },
    {
      header: 'View Homework',
      body: 'A complete guide on how to go about viewing homework.',
      pdfUrl: 'assets/pdfs/View Homework Guide.pdf',
      isVisible: true // Set to true initially
    },
    {
      header: 'View Recordings',
      body: 'A complete guide on how to go about viewing a recordings',
      pdfUrl: 'assets/pdfs/View Recording Guide.pdf',
      isVisible: true // Set to true initially
    },
    {
      header: 'Upload Completed Homework',
      body: 'A complete guide on how to go about uploading homework that you have completed',
      pdfUrl: 'assets/pdfs/Upload Homework Guide.pdf',
      isVisible: true // Set to true initially
    },
    {
      header: 'Parent Feedback',
      body: 'A complete guide on how to go about adding parent feedback after the session',
      pdfUrl: 'assets/pdfs/Parent Feedback Guide.pdf',
      isVisible: true // Set to true initially
    },
    
  ];

  constructor() {}

  filterCards() {
    const searchQuery = this.searchQuery.toLowerCase();

    // Implement your filter logic here to show/hide cards based on searchQuery
    this.cards.forEach((card) => {
      card.isVisible = card.header.toLowerCase().includes(searchQuery);
    });
  }

  // Function to open a PDF document
  openPDF(pdfUrl: string) {
    // Implement your logic to open the PDF document here
    // You can use a library like pdf.js or open it in a new browser tab
    window.open(pdfUrl, '_blank');
  }
}
