import { Component } from '@angular/core';

@Component({
  selector: 'app-help-facility',
  templateUrl: './help-facility.component.html',
  styleUrls: ['./help-facility.component.scss']
})
export class HelpFacilityComponent {
  
}
