import { Component, OnInit  } from '@angular/core';
import { FormBuilder,Validators,FormControl, FormGroup, AbstractControl } from '@angular/forms';
import { ResetPasswordService } from '../../services/reset-password.service';
import { ActivatedRoute } from '@angular/router';
import { ResetPassword } from '../../shared/resetPassword';
import { Router } from '@angular/router';
import { MatDialog } from '@angular/material/dialog';
import { ChangePasswordModelComponent } from '../../utilities/modals/change-password-model/change-password-model.component';
import { MatSnackBar } from '@angular/material/snack-bar';
@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.scss']
})
export class ResetPasswordComponent {

  resetPassword!: FormGroup

  private token!: string;
  private email!: string;

  constructor(private snackBar: MatSnackBar,private dialog: MatDialog,private router : Router, private formBuilder: FormBuilder, private resetPasswordService: ResetPasswordService, private route: ActivatedRoute){}

  ngOnInit() {
    this.resetPassword = this.formBuilder.group({
      password: ['', [
        Validators.required,
        Validators.minLength(6),
        this.passwordPatternValidator()
      ]],
      confirmPassword: ['', Validators.required]
    }, {
      validator: this.passwordsMatchValidator
    });

    this.token = this.route.snapshot.queryParams['token'];
      this.email = this.route.snapshot.queryParams['email'];
  }



  passwordPatternValidator() {
    return (control: FormControl) => {
      const password = control.value;
      const passwordPattern = /^(?=.*[A-Za-z])(?=.*\d)[A-Za-z\d@$!%*#?&]{6,}$/;

      if (passwordPattern.test(password)) {
        return null;
      } else {
        return { invalidPassword: true };
      }
    };


  }

  passwordsMatchValidator(control: AbstractControl): { [key: string]: boolean } | null {
    const password = control.get('password');
    const confirmPassword = control.get('confirmPassword');

    if (password && confirmPassword && password.value !== confirmPassword.value) {
      return { 'passwordsMismatch': true };
    }
    return null;
  }


  onSubmit(): void {
    if (this.resetPassword.valid) {

      console.log(this.resetPassword.value);


    } else {

      this.validateAllFormFields(this.resetPassword);
    }


  }

  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });



}

confirmButton(): void {

//code for password submission

if (this.resetPassword.valid) {
  let resetPassword = new ResetPassword();
  resetPassword.Password = this.resetPassword.value.password;
  resetPassword.ConfirmPassword = this.resetPassword.value.confirmPassword;
  resetPassword.Token = this.token;
  resetPassword.Email = this.email;


      this.resetPasswordService.resetPassword(resetPassword).subscribe(
        (response: any) => {
          this.showModal();
          console.log('Success:', response);
        },


      );
    } else {
      this.validateAllFormFields(this.resetPassword);
    }
}

showModal() {
  const dialogRef = this.dialog.open(ChangePasswordModelComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    this.resetPassword.reset();
  });
}

cancel()
{}

}




