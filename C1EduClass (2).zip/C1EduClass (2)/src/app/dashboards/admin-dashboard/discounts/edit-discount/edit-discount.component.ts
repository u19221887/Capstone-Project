import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { AudittrailService } from 'src/app/services/audittrail.service';
import { DiscountStatus } from 'src/app/shared/discountStatus';

@Component({
  selector: 'app-edit-discount',
  templateUrl: './edit-discount.component.html',
  styleUrls: ['./edit-discount.component.scss']
})
export class EditDiscountComponent implements OnInit{
  
  add = new FormData(); 

  acceptedauditTrail : FormGroup = this.fb.group({
    Email: ["elysiapandarum@gmail.com"],
    Action: ["edited discount code: "]
  })

  s: any;
  newvalue : any;

   addAuditTrail(){
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.newvalue = this.s + " "+ this.discountForm.get('DiscountCode')!.value;

    this.acceptedauditTrail.get('Action')?.setValue(this.newvalue)
     if (this.acceptedauditTrail.valid)
     {
       this.add.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.add.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.add).subscribe(()=>{
         console.log("added audit")
       })
     }
   }


  discountStatusData : DiscountStatus[] =[]
  discount: any

  ngOnInit() : void{
    this.getDiscountStatuses();
    this.apiService.getDiscount(+this.route.snapshot.params['id']).subscribe(result=>{
      this.discount = result
      this.discountForm.patchValue({
        DiscountCode : this.discount.discountCode,
        DiscountStartDate : this.discount.discountStartDate,
        DiscountEndDate : this.discount.discountEndDate,
        DiscountPercentage : this.discount.discountPercentage,
        NumberOfSessions : this.discount.numberOfSessions,
        DiscountStatus : this.discount.discountStatusId

      })
    })
    
  }

  constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute, private auditTrailService :AudittrailService){}

  getDiscountStatuses(){
    this.apiService.getDiscountStatuses().subscribe(result =>{
      let discountStatusList: any[] = result
      discountStatusList.forEach((element)=>{
        this.discountStatusData.push(element)
        console.log(this.discountStatusData)
      })
    })
  }

  discountForm:  FormGroup= this.fb.group(
    {
      DiscountCode : ['',Validators.required],
      DiscountStartDate : ['',Validators.required],
      DiscountEndDate :  ['',Validators.required],
      NumberOfSessions: ['',Validators.required],
      DiscountPercentage :['',Validators.required],
      DiscountStatus : [null,Validators.required]
    })

    dateToday(): Date {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      const day = now.getDate();
      const hour = now.getHours();
      const minute = now.getMinutes();
      return new Date(year, month, day, hour, minute);
    }

    cancel(){

    }
  
    onSubmit(){
      this.apiService.editDiscount(this.discount.discountId, this.discountForm.value).subscribe(result =>{
        this.addAuditTrail()
        this.router.navigate(['/admin-discount'])
      })
    }
  
    //constructor(private apiService: APIService, private fb: FormBuilder, private router: Router){}
  
    
}
