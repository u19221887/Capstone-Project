import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { AudittrailService } from 'src/app/services/audittrail.service';
import { DiscountStatus } from 'src/app/shared/discountStatus';

@Component({
  selector: 'app-add-discount',
  templateUrl: './add-discount.component.html',
  styleUrls: ['./add-discount.component.scss']
})
export class AddDiscountComponent implements OnInit {
  
  formData = new FormData();

  add = new FormData(); 

  acceptedauditTrail : FormGroup = this.fb.group({
    Email: ["elysiapandarum@gmail.com"],
    Action: ["created discount code: "]
  })

  s: any;
  newvalue : any;

   addAuditTrail(){
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.newvalue = this.s + " "+ this.discountForm.get('DiscountCode')!.value;

    this.acceptedauditTrail.get('Action')?.setValue(this.newvalue)
     if (this.acceptedauditTrail.valid)
     {
       this.add.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.add.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.add).subscribe(()=>{
         console.log("added audit")
       })
     }
   }

  discountForm:  FormGroup= this.fb.group(
    {
      DiscountCode : ['',Validators.required],
      DiscountStartDate : ['',Validators.required],
      DiscountEndDate :  ['',Validators.required],
      NumberOfSessions: ['',Validators.required],
      DiscountPercentage: ['',Validators.required],
      DiscountStatus:[null,Validators.required]
    })

    discountStatusData : DiscountStatus[] =[]

    dateToday(): Date {
      const now = new Date();
      const year = now.getFullYear();
      const month = now.getMonth() + 1;
      const day = now.getDate();
      const hour = now.getHours();
      const minute = now.getMinutes();
      return new Date(year, month, day, hour, minute);
    }
      
  ngOnInit(){
    this.getDiscountStatuses();

  }

  cancel(){

  }

  onSubmit(){
    console.log("im here")
    if (this.discountForm.valid)
    {
      this.formData.append('DiscountCode', this.discountForm.get('DiscountCode')!.value)
      this.formData.append('DiscountStartDate', this.discountForm.get('DiscountStartDate')!.value)
      this.formData.append('DiscountEndDate', this.discountForm.get('DiscountEndDate')!.value)
      this.formData.append('DiscountPercentage', this.discountForm.get('DiscountPercentage')!.value)
      this.formData.append('NumberOfSessions', this.discountForm.get('NumberOfSessions')!.value)
      this.formData.append('DiscountStatus',this.discountForm.get('DiscountStatus')!.value)
      console.log('here')
      this.apiService.addDiscount(this.formData).subscribe(()=>{
        this.addAuditTrail()
        this.clearData()
        this.router.navigate(['/admin-discount']);
        });
        console.log(this.formData)
      };
    }
    

  constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute, private auditTrailService : AudittrailService){}

 

  getDiscountStatuses(){
    this.apiService.getDiscountStatuses().subscribe(result =>{
      let discountStatusList: any[] = result
      discountStatusList.forEach((element)=>{
        this.discountStatusData.push(element)
        console.log(this.discountStatusData)
      })
    })
  }

  clearData(){
    this.formData.delete("DiscountCode");
    this.formData.delete("DiscountStartDate");
    this.formData.delete("DiscountEndDate");
    this.formData.delete("DiscountPercentage");
    this.formData.delete("NumberOfSessions");
    this.formData.delete("DiscountStatus");
  }

}
