import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { Discount } from 'src/app/shared/discount';

@Component({
  selector: 'app-discounts',
  templateUrl: './discounts.component.html',
  styleUrls: ['./discounts.component.scss']
})


export class DiscountsComponent implements OnInit{


  ngOnInit(){
    this.getActiveDiscounts();
    this.getInactiveDiscounts();
  }

  activeDiscounts: Discount[] =[];
  inactiveDiscounts: Discount [] =[];

  constructor(private dataService: APIService, private router: Router){}

  deleteDiscount(discountId: Number) {
    this.dataService.deleteDiscount(discountId).subscribe(result => {
      window.location.reload();
      });
  }

  getActiveDiscounts(){
    this.dataService.getActiveDiscounts().subscribe(result => {
      let discountList:any[] = result
      discountList.forEach((element) => {
        this.activeDiscounts.push(element)
        console.log(this.activeDiscounts)
      });
    })
  }

  getInactiveDiscounts(){
    this.dataService.getInactiveDiscounts().subscribe(result => {
      let discountList:any[] = result
      discountList.forEach((element) => {
        this.inactiveDiscounts.push(element)
        console.log(this.inactiveDiscounts)
      });
    })
  }

}
