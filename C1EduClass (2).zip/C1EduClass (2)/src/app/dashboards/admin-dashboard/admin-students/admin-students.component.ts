import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';

@Component({
  selector: 'app-admin-students',
  templateUrl: './admin-students.component.html',
  styleUrls: ['./admin-students.component.scss']
})
export class AdminStudentsComponent implements OnInit {

  constructor(private apiService: StudentService, private router: Router){}
  
  students: Student[] = [];

  // getAllStudents()
  // {
  //   this.apiService.getAllStudent().subscribe(result=>{
  //     let studentList: any[]= result
  //     studentList.forEach((element)=>{
  //       this.students.push(element)
  //       //console.log(tutorApplicationList);
  //       console.log(this.students);
  //     });
  //   })
  // }

  getAllStudents()
  {
    this.apiService.getAllStudent().subscribe(result=>{
      let studentList: any[] = result
      studentList.forEach((element: any)=>{
        this.students.push(element)

      })
    })
  }

  ngOnInit(): void {
    this.getAllStudents();
    
  }

  deleteStudent(studentId: Number){

  }

}
