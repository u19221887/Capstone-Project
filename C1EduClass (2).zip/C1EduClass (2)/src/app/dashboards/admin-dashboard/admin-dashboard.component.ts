import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from '../../services/api.service';
import { Admin } from '../../shared/admin';

@Component({
  selector: 'app-admin-dashboard',
  templateUrl: './admin-dashboard.component.html',
  styleUrls: ['./admin-dashboard.component.scss']
})
export class AdminDashboardComponent implements OnInit {

  constructor(private apiService: APIService,private router : Router, private activated:ActivatedRoute){}

  getAdmin!: Admin
  admin!: Admin []



  ngOnInit(): void {

    // GET THE ID FROM THE URL
  //  this.activated.params.subscribe(params => {


  //   //SEND OFF REQUEST TO DB TO FIND OBJECT DATA
  //   this.studentService.getStudent(params['id']).subscribe(response => { //SUBSCRIBE TO THE RESPONSE


  //    this.getStudent = response as Student;
  //    console.log(this.getStudent)


  //   })

  //  })
  let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

  this.apiService.getAdmins().subscribe(response => {


     this.admin = response as Admin[];
     console.log(this.admin)
     this.getAdmin=this.admin.find(x=> x.adminEmail==o.username)!
      console.log(this.getAdmin,this.admin)


    })

}

logout() {
  localStorage.removeItem('User');

}

onLogoutClick() {
  this.logout();
  this.router.navigate(['/user']);
}


}
