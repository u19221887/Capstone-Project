import { Component, OnInit } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { Admin } from 'src/app/shared/admin';
import { MatDialog } from '@angular/material/dialog';
import { DeleteAdminModalComponent } from 'src/app/utilities/modals/delete-admin-modal/delete-admin-modal.component';

@Component({
  selector: 'app-admin-myprofile',
  templateUrl: './admin-myprofile.component.html',
  styleUrls: ['./admin-myprofile.component.scss']
})
export class AdminMyprofileComponent implements OnInit{


  constructor(private apiService:APIService , private router : Router, private dialog: MatDialog, private activated:ActivatedRoute ) { }


  getAdmin!: Admin
  admins!: Admin []


  ngOnInit(): void {

    // GET THE ID FROM THE URL
  //  this.activated.params.subscribe(params => {


  //   //SEND OFF REQUEST TO DB TO FIND OBJECT DATA
  //   this.studentService.getStudent(params['id']).subscribe(response => { //SUBSCRIBE TO THE RESPONSE


  //    this.getStudent = response as Student;
  //    console.log(this.getStudent)


  //   })

  //  })

  let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

  this.apiService.getAdmins().subscribe(response => {


     this.admins = response as Admin[];
     console.log(this.admins)
     this.getAdmin=this.admins.find(x=> x.adminEmail==o.username)!
      console.log(this.getAdmin,this.admins)


    })

}


  deleteAdmin(adminId: Number){
    this.apiService.deleteAdmin(adminId).subscribe((result: any) => {
      window.location.reload();
      this.showSuccessModal();
      });
    }

    showSuccessModal() {
      const dialogRef = this.dialog.open(DeleteAdminModalComponent, {
        width: '700px',
      height: '400px',
        disableClose: true,
      });
    }
}
