import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/services/booking.service';
import { PaymentService } from 'src/app/services/payment.service';



@Component({
  selector: 'app-payments',
  templateUrl: './payments.component.html',
  styleUrls: ['./payments.component.scss']
})
export class PaymentsComponent implements OnInit{


  sessionList: any[] = [];
  totalPrice: number = 0;
  constructor(private bookingService: BookingService,public paymentService: PaymentService,) {

    //TODO: get Student Id
    this.bookingService.getBookingSessionsAdmin(
    ).subscribe((data: any) => {
      console.log(data)

      this.sessionList = data
      })

      this.loadPaymentData();
   }

  ngOnInit() {

    
  }

   // Function to load payment data
   loadPaymentData() {
    this.bookingService.getBookingSessionsAdmin().subscribe((data: any) => {
      // Initialize the sessionList with the data
      this.sessionList = data;

      // Check and set payment status from local storage
      this.loadPaymentStatusFromLocalStorage();
    });
  }

  // Function to check and set payment status from local storage
  loadPaymentStatusFromLocalStorage() {
    const storedPaymentStatus = localStorage.getItem('paymentStatus');

    if (storedPaymentStatus) {
      const parsedPaymentStatus = JSON.parse(storedPaymentStatus);
      const sessionToUpdate = this.sessionList.find(item => item.id === parsedPaymentStatus.id);

      if (sessionToUpdate) {
        sessionToUpdate.isPaid = true; // Set the payment status to "Paid"
      }
    }
  }


  

  getTime(dateTime: string, endTime: string){
    return `${new Date(dateTime).toLocaleTimeString('en-ZA')} - ${new Date(endTime).toLocaleTimeString('en-ZA')}   `
  }

  totalAmount(totalPrice: string): number {
    var Price = Number(totalPrice)* 0.6* 100;
   return Price ;
 }

   //book
   paymentDone(ref: any,amount: number, bookingId: number) {

     const bookingObjt: any = {
       BookingId: bookingId,
       Date:  Date.now(),
       Ref: ref.reference,
       Amount: Number(amount),
     }

     
     // Update the isPaid property for the corresponding session
  const sessionToUpdate = this.sessionList.find(item => item.id === bookingId); // Update based on your data structure
  if (sessionToUpdate) {
    sessionToUpdate.isPaid = true;
  }

     // Store the updated payment status in local storage
    localStorage.setItem('paymentStatus', JSON.stringify(sessionToUpdate));


     // get booking id from somewhere
     this.bookingService.updateBookingStatus(bookingObjt).subscribe((data: any) => {
       // this.toastr.success('Booking successful');
     });

 
   }

   calculateDiscountedPrice(originalPrice: number): number {
    // Calculate the discounted price (60% discount)
    const discount = 0.6; // 60% discount
    return originalPrice * discount;
  }


}
