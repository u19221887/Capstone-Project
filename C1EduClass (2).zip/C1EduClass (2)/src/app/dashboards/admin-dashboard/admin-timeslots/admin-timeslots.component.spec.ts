import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AdminTimeslotsComponent } from './admin-timeslots.component';

describe('AdminTimeslotsComponent', () => {
  let component: AdminTimeslotsComponent;
  let fixture: ComponentFixture<AdminTimeslotsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [AdminTimeslotsComponent]
    });
    fixture = TestBed.createComponent(AdminTimeslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
