import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { SuccessModalComponent } from 'src/app/utilities/success-modal/success-modal.component';

@Component({
  selector: 'app-edit-timeslot',
  templateUrl: './edit-timeslot.component.html',
  styleUrls: ['./edit-timeslot.component.scss']
})
export class EditTimeslotComponent implements OnInit {

  editTimeslot!: FormGroup;



  timeslot:any
  constructor(private formBuilder: FormBuilder, private dialog: MatDialog, private apiService: APIService, private router: Router, private route:ActivatedRoute)  {}

  ngOnInit():void {
    this.apiService.getTimeslot(+this.route.snapshot.params['id']).subscribe(result => {
      this.timeslot = result
      this.editTimeslot = this.formBuilder.group({
        timeslotDay: ['', Validators.required],
        timeslotStartTime: ['', Validators.required],
        timeslotEndTime: ['', Validators.required],
      });
      this.editTimeslot.patchValue({
        timeslotDay: this.timeslot.timeslotDay,
        timeslotStartTime: this.timeslot.timeslotStartTime,
        timeslotEndTime: this.timeslot.timeslotEndTime

      });
  })}

  onSubmit(): void {
    if (this.editTimeslot.valid) {
      this.apiService.editTimeslot(this.timeslot.timeslotId, this.editTimeslot.value).subscribe(result => {
        this.router.navigate(['/timeslot-dashboard'])})
      console.log(this.editTimeslot.value);
      this.showSuccessModal();
    } else {

      this.validateAllFormFields(this.editTimeslot);
    }


  }



  showSuccessModal() {
    const dialogRef = this.dialog.open(SuccessModalComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.editTimeslot.reset();
    });
  }


  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });


}
}
