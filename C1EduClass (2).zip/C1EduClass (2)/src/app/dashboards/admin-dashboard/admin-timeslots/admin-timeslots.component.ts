import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { Timeslot } from 'src/app/shared/timeslot';

@Component({
  selector: 'app-admin-timeslots',
  templateUrl: './admin-timeslots.component.html',
  styleUrls: ['./admin-timeslots.component.scss']
})
export class AdminTimeslotsComponent implements OnInit{

  timeslots:Timeslot[] = []

  constructor(private apiService: APIService, private router: Router) { }

  ngOnInit(): void {
    this.getTimeslots()
  }

  getTimeslots()
  {
    this.apiService.getTimeslots().subscribe(result => {
      let timeslotList:any[] = result
      timeslotList.forEach((element) => {
        this.timeslots.push(element)
        console.log(this.timeslots)
      });
    })
  }

  deleteTimeslot(timeslotId: Number){
    this.apiService.deleteTimeslot(timeslotId).subscribe(result => {
      window.location.reload();
      });
    }

}
