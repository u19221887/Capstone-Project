import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { SuccessModalComponent } from 'src/app/utilities/success-modal/success-modal.component';

@Component({
  selector: 'app-add-timeslot',
  templateUrl: './add-timeslot.component.html',
  styleUrls: ['./add-timeslot.component.scss']
})
export class AddTimeslotComponent implements OnInit {

  newTimeslotCreation!: FormGroup;



  constructor( private router: Router, private formBuilder: FormBuilder, private dialog: MatDialog, private apiService: APIService)  {}

  ngOnInit() {
    this.newTimeslotCreation = this.formBuilder.group({
      timeslotDay: ['', Validators.required],
      timeslotStartTime: ['', Validators.required],
      timeslotEndTime: ['', Validators.required],
    });

  }

  onSubmit(): void {
    if (this.newTimeslotCreation.valid) {
      this.apiService.addTimeslot(this.newTimeslotCreation.value).subscribe(_result => {
        this.router.navigate(['/timeslot-dashboard'])
  })
      console.log(this.newTimeslotCreation.value);
      this.showSuccessModal();
    } else {

      this.validateAllFormFields(this.newTimeslotCreation);
    }


  }



  showSuccessModal() {
    const dialogRef = this.dialog.open(SuccessModalComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.newTimeslotCreation.reset();
    });
  }


  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });

  }

}
