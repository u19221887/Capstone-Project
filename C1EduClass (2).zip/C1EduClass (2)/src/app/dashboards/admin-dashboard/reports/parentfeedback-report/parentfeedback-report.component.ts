import { Component, OnInit } from '@angular/core';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { MatSnackBar } from '@angular/material/snack-bar';
import { FormBuilder } from '@angular/forms';
import { APIService } from 'src/app/services/api.service';


@Component({
  selector: 'app-parentfeedback-report',
  templateUrl: './parentfeedback-report.component.html',
  styleUrls: ['./parentfeedback-report.component.scss']
})
export class ParentfeedbackReportComponent implements OnInit {

  
  formData = new FormData();
  
  

  
  
  feedbackForm: FormGroup= this.fb.group({
      ParentName : ['', Validators.required],
      ParentSurname : ['', Validators.required],
      ParentFeedbackDescription :  ['', Validators.required],
      StudentName: ['', Validators.required],
      StudentSurname : ['', Validators.required],
      Subject : ['', Validators.required],


    })

    constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute){}
    student: any;

    ngOnInit(){
      this.apiService.getStudent(+this.route.snapshot.params['id']).subscribe(result =>{
        this.student = result
      })
    
    }
    
    onSubmit(){
      if (this.feedbackForm.valid)
      {

        this.formData.append('ParentName', this.feedbackForm.get('ParentName')!.value);
        this.formData.append('ParentSurname', this.feedbackForm.get('ParentSurname')!.value);
        this.formData.append('ParentFeedbackDescription', this.feedbackForm.get('ParentFeedbackDescription')!.value);
        this.formData.append('StudentName', this.feedbackForm.get('StudentName')!.value);
        this.formData.append('StudentSurname', this.feedbackForm.get('StudentSurname')!.value);
        this.formData.append('Subject', this.feedbackForm.get('Subject')!.value);



        this.apiService.addFeedback(this.student.studentId, this.formData).subscribe(()=> {
          this.clearData()
          this.router.navigateByUrl('student-dashboard').then((navigated: boolean)=> {
            if (navigated){
              this.snackBar.open(this.feedbackForm.get('name')!.value + ` upload successfully`, 'X', {duration: 5000});
            }
          });
        });
      }
    }

    clearData(){
      this.formData.delete("ParentName");
      this.formData.delete("ParentSurname");
      this.formData.delete("ParentFeedbackDescription");
      this.formData.delete("StudentName");
      this.formData.delete("StudentSurname");
      this.formData.delete("subject");
    }

}
