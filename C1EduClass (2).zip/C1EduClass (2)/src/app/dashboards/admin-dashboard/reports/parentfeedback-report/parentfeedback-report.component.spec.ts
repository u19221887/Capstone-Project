import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ParentfeedbackReportComponent } from './parentfeedback-report.component';

describe('ParentfeedbackReportComponent', () => {
  let component: ParentfeedbackReportComponent;
  let fixture: ComponentFixture<ParentfeedbackReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [ParentfeedbackReportComponent]
    });
    fixture = TestBed.createComponent(ParentfeedbackReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
