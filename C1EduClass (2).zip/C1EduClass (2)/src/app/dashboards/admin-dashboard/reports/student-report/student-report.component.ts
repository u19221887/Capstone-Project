import { Component, OnInit } from '@angular/core';
import { Student } from 'src/app/shared/student';
import { StudentService } from 'src/app/services/student.service';
import { Router } from '@angular/router';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';

@Component({
  selector: 'app-student-report',
  templateUrl: './student-report.component.html',
  styleUrls: ['./student-report.component.scss']
})
export class StudentReportComponent implements OnInit {

  student:Student[] = []


  total :any
  
  tot :any
 //added this
  currentDate: any
  

  constructor(private studentService: StudentService, private router:Router) { }

  ngOnInit(): void {
    this.getStudents();
    this.countStudents();
    console.log(this.total)

    //added this
    this.currentDate = new Date().toLocaleDateString(); 
  }


  getStudents()
  {
    this.studentService.getAllStudent().subscribe(res => {
      this.student = res as Student[];
  });

  }

  countStudents()
  {
    this.studentService.countStudents().subscribe(result=>{
      this.tot = result
      console.log(this.tot)
      this.total= this.tot.count
      console.log(this.total)

      

    });
  }


  // downloadPDF() {
  //   const doc = new jsPDF.default();

  //   const columns = Object.keys(this.student[0]);
    
  //   const rows = this.student.map(student => Object.values(student));
    

    
    
    
  //   (doc as any).autoTable({
  //     head: [columns],
  //     body: rows,
  //   });

  //   doc.save('student_data.pdf');
  // }


  downloadPDF() {
    const doc = new jsPDF.default();

    const logoImg = new Image();
    logoImg.src = "/assets/educlass.png.jpg";

    const width = 30;  // Adjust the width as needed
    const height = 30;

    doc.addImage(logoImg, 'PNG', 50, 10, width, height);

    const titleFontSize = 18; 
    doc.setFontSize(18); // Adjust the font size as needed
    doc.setFont('helvetica', 'bold');

    const title = 'List of Students';
    const titleWidth = doc.getStringUnitWidth(title) * titleFontSize / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.width - titleWidth) / 2; // Centered horizontally
    const titleY = 25; // Adjust the Y coordinate as needed

    doc.text(title, titleX, titleY);

    //date
    const dateFontSize = 10; 
    doc.setFontSize(dateFontSize);
    doc.setFont('helvetica', 'normal');

    const currentDate = new Date().toLocaleDateString();

    const datetext="Date: "+ currentDate

    doc.text(datetext,10,35)

    const spaceBetweenLogoAndTable = 20; // Adjust this value as needed
    const tableX = 10;
    const tableY = 10 + 10 + spaceBetweenLogoAndTable;

    const headerFillerColor=[60,122,110]


    const columns = ['Student Name', 'Student Surname', 'Student Phone Number', 'Student Email', 'Student Grade', 'Student Subject'];
    const rows = this.student.map(student => [
      student.studentName,
      student.studentSurname,
      student.studentPhoneNumber,
      student.studentEmail,
      student.grade,
      student.subject
      
    ]);

     //total
     const totalStudent = this.total;
     const ttext ="Total Number of students: " + totalStudent;
 
     const spaceBetweenTotalAndTable = 20; // Adjust this value as needed
     const totalX = 10;
     const totalY = 50 + 10 + spaceBetweenLogoAndTable;
 
 
     doc.text(ttext,totalX, totalY);
 
  
    
    (doc as any).autoTable({
      startY: tableY,
      head:[columns],
      body: rows,
      headStyles:{
        fillColor:headerFillerColor
      }
    });
    doc.save('students_report.pdf');
  }


  // downloadPDF() {
  //   const doc = new jsPDF.default();
  
  //   const columns = ['Student Name', 'Student Surname', 'Student Phone Number', 'Student Email', 'Student Grade', 'Student Subject'];
  //   const rows = this.student.map(student => [
  //     student.studentName,
  //     student.studentSurname,
  //     student.studentPhoneNumber,
  //     student.studentEmail,
  //     student.grade,
  //     student.subject
  //   ]);
  
  //   // Calculate the total number of students
  //   const totalStudents = this.student.length;
  
  //   // Create the footer content
  //   const footer = [{ content: 'Total Students:', colSpan: 5 }, {}, {}, {}, {}, totalStudents.toString()];
  
  //   // Generate the table
  //   (doc as any).autoTable({
  //     headStyles: { fillColor: [0, 128, 0], textColor: [255, 255, 255] },
  //     head: [columns],
  //     body: rows,
  //     foot: [footer]
  //   });
  
  //   doc.save('student_data.pdf');
  // }

  // downloadPDF() {
  //   const doc = new jsPDF.default();
  
  //   const columns = ['Student Name', 'Student Surname', 'Student Phone Number', 'Student Email', 'Student Grade', 'Student Subject'];
  
  //   // Filter out students with empty names
  //   const filteredStudents = this.student.filter(student => student.studentName.trim() !== '');
  
  //   // Map rows based on the student data
  //   const rows = filteredStudents.map(student => [
  //     student.studentName,
  //     student.studentSurname,
  //     student.studentPhoneNumber,
  //     student.studentEmail,
  //     student.grade,
  //     student.subject
  //   ]);
  
  //   // Calculate the total number of students
  //   const totalStudents = filteredStudents.length;
  
  //   // Generate the table
  //   (doc as any).autoTable({
  //     headStyles: { fillColor: [0, 128, 0], textColor: [255, 255, 255] },
  //     head: [columns],
  //     body: rows,
  //     foot: [[{ content: 'Total Students:', colSpan: 5 }, {}, {}, {}, {}, totalStudents.toString()]]
  //   });
  
  //   doc.save('student_data.pdf');
  // }

}
