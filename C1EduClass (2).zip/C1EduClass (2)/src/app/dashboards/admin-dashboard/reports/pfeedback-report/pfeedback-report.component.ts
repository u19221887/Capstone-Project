import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Chart from 'chart.js/auto';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';

import { APIService } from 'src/app/services/api.service';
import { ParentFeedback } from 'src/app/shared/parentfeedback';

@Component({
  selector: 'app-pfeedback-report',
  templateUrl: './pfeedback-report.component.html',
  styleUrls: ['./pfeedback-report.component.scss']
})
export class PfeedbackReportComponent implements OnInit{

  Parentfeedbacks: ParentFeedback[] = [];

 //added this
  currentDate: any
  

  constructor(private apiService: APIService, private router:Router) { }

  ngOnInit(): void {
    this.getAllFeedback();
    console.log(this.Parentfeedbacks)


    //added this
    this.currentDate = new Date().toLocaleDateString(); 
  }


  getAllFeedback()
  {
    this.apiService.getAllFeedback().subscribe(res => {
      this.Parentfeedbacks = res as ParentFeedback[];
      console.log(this.Parentfeedbacks)
  });

  }



  // downloadPDF() {
  //   const doc = new jsPDF.default();

  //   const columns = Object.keys(this.feedback[0]);
    
  //   const rows = this.feedback.map(feedback => Object.values(feedback));
    

    
    
    
  //   (doc as any).autoTable({
  //     head: [columns],
  //     body: rows,
  //   });

  //   doc.save('feedback_data.pdf');
  // }


  downloadPDF() {
    const doc = new jsPDF.default();

    const logoImg = new Image();
    logoImg.src = "/assets/educlass.png.jpg";

    const width = 30;  // Adjust the width as needed
    const height = 30;

    doc.addImage(logoImg, 'PNG', 50, 10, width, height);

    const titleFontSize = 18; 
    doc.setFontSize(18); // Adjust the font size as needed
    doc.setFont('helvetica', 'bold');

    const title = 'List of feedbacks';
    const titleWidth = doc.getStringUnitWidth(title) * titleFontSize / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.width - titleWidth) / 2; // Centered horizontally
    const titleY = 25; // Adjust the Y coordinate as needed

    doc.text(title, titleX, titleY);

    //date
    const dateFontSize = 10; 
    doc.setFontSize(dateFontSize);
    doc.setFont('helvetica', 'normal');

    const currentDate = new Date().toLocaleDateString();

    const datetext="Date: "+ currentDate

    doc.text(datetext,10,35)

    const spaceBetweenLogoAndTable = 20; // Adjust this value as needed
    const tableX = 10;
    const tableY = 10 + 10 + spaceBetweenLogoAndTable;

    const headerFillerColor=[60,122,110]


    const columns = ['Parent Name', 'Parent Surname', 'Parent Name', 'Student Surname', 'Student Feedback Description', 'Student Subject'];
    const rows = this.Parentfeedbacks.map(Parentfeedbacks => [
      Parentfeedbacks.parentName,
      Parentfeedbacks.parentSurname,
      Parentfeedbacks.parentFeedbackDescription,
      Parentfeedbacks.studentName,
      Parentfeedbacks.studentName,
      Parentfeedbacks.subject
      
    ]);

  
    
    (doc as any).autoTable({
      startY: tableY,
      head:[columns],
      body: rows,
      headStyles:{
        fillColor:headerFillerColor
      }
    });
    doc.save('parentfeedback_report.pdf');
  }


  // downloadPDF() {
  //   const doc = new jsPDF.default();
  
  //   const columns = ['feedback Name', 'feedback Surname', 'feedback Phone Number', 'feedback Email', 'feedback Grade', 'feedback Subject'];
  //   const rows = this.feedback.map(feedback => [
  //     feedback.feedbackName,
  //     feedback.feedbackSurname,
  //     feedback.feedbackPhoneNumber,
  //     feedback.feedbackEmail,
  //     feedback.grade,
  //     feedback.subject
  //   ]);
  
  //   // Calculate the total number of feedbacks
  //   const totalfeedbacks = this.feedback.length;
  
  //   // Create the footer content
  //   const footer = [{ content: 'Total feedbacks:', colSpan: 5 }, {}, {}, {}, {}, totalfeedbacks.toString()];
  
  //   // Generate the table
  //   (doc as any).autoTable({
  //     headStyles: { fillColor: [0, 128, 0], textColor: [255, 255, 255] },
  //     head: [columns],
  //     body: rows,
  //     foot: [footer]
  //   });
  
  //   doc.save('feedback_data.pdf');
  // }

  // downloadPDF() {
  //   const doc = new jsPDF.default();
  
  //   const columns = ['feedback Name', 'feedback Surname', 'feedback Phone Number', 'feedback Email', 'feedback Grade', 'feedback Subject'];
  
  //   // Filter out feedbacks with empty names
  //   const filteredfeedbacks = this.feedback.filter(feedback => feedback.feedbackName.trim() !== '');
  
  //   // Map rows based on the feedback data
  //   const rows = filteredfeedbacks.map(feedback => [
  //     feedback.feedbackName,
  //     feedback.feedbackSurname,
  //     feedback.feedbackPhoneNumber,
  //     feedback.feedbackEmail,
  //     feedback.grade,
  //     feedback.subject
  //   ]);
  
  //   // Calculate the total number of feedbacks
  //   const totalfeedbacks = filteredfeedbacks.length;
  
  //   // Generate the table
  //   (doc as any).autoTable({
  //     headStyles: { fillColor: [0, 128, 0], textColor: [255, 255, 255] },
  //     head: [columns],
  //     body: rows,
  //     foot: [[{ content: 'Total feedbacks:', colSpan: 5 }, {}, {}, {}, {}, totalfeedbacks.toString()]]
  //   });
  
  //   doc.save('feedback_data.pdf');
  // }
}
