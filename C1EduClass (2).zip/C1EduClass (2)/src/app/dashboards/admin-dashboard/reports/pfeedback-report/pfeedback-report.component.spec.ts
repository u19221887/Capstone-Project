import { ComponentFixture, TestBed } from '@angular/core/testing';

import { PfeedbackReportComponent } from './pfeedback-report.component';

describe('PfeedbackReportComponent', () => {
  let component: PfeedbackReportComponent;
  let fixture: ComponentFixture<PfeedbackReportComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [PfeedbackReportComponent]
    });
    fixture = TestBed.createComponent(PfeedbackReportComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
