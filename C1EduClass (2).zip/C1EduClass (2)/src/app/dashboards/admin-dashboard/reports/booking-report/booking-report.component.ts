import { Component } from '@angular/core';
import { Router } from '@angular/router';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { APIService } from 'src/app/services/api.service';
import { BookingService } from 'src/app/services/booking.service';

@Component({
  selector: 'app-booking-report',
  templateUrl: './booking-report.component.html',
  styleUrls: ['./booking-report.component.scss']
})
export class BookingReportComponent {
  constructor(private apiService: APIService,private bookingService : BookingService, private router: Router){
    this.getInPersonList();
    this.getOnlineList();
    this.getTotal();
  }
  
  online:any []=[];
  inperson:any []=[];

  getOnlineList(){
    this.bookingService.getOnlineBookings().subscribe(result=>{
    let list:any[] = result
    list.forEach((element)=>{
      this.online.push(element)
      console.log(this.online)
    })
    })
  }
  getInPersonList(){
    this.bookingService.getInPersonBookings().subscribe(result=>{
    let list:any[] = result
    list.forEach((element)=>{
      this.inperson.push(element)
      console.log(this.inperson)
    })
    })
  }
  getTime(dateTime: string, endTime: string){
    return `${new Date(dateTime).toLocaleTimeString('en-ZA')} - ${new Date(endTime).toLocaleTimeString('en-ZA')}   `
  }

  total :any;
  getTotal(){
    this.bookingService.getTotal().subscribe(result=>{
      this.total = result
      console.log(this.total)
    })
  }

  ttot: any;
  ttotal: any;

  stot: any;
  stotal: any;

  atot: any;
  atotal: any;

  ftot: any;
  ftotal: any;

  ptot: any;
  ptotal: any;

  data: any;

   totalfBooking: any;


   countOnline()
  {
    this.apiService.countOnline().subscribe(result=>{
      this.ftot = result
      console.log(this.ftot)
      this.ftotal= this.ftot.count
      console.log(this.ftotal)

    });
  }

  countInPerson()
  {
    this.apiService.countInPerson().subscribe(result=>{
      this.ptot = result
      console.log(this.ptot)
      this.ptotal= this.ptot.count
      console.log(this.ptotal)

    });
  }

  countBookings()
  {
    this.apiService.countBookings().subscribe(result=>{
      this.ttot = result
      console.log(this.ttot)
      this.ttotal= this.ttot.count
      console.log(this.ttotal)

    });
  }


  ngOnInit(): void {
    this.countOnline();
    this.countInPerson();
    this.countBookings();
  }




  
  getData(){

    console.log(this.ttotal)
     this.data = [
  
      {
        name: 'Bookings',
        total: this.ttotal,
        isExpand: false,
        address: [
          {
            Online: this.ftotal,
            InPerson: this.ptotal,
          }
        ]
      },
      
    ]
  }

  downloadPDF(){
    const doc = new jsPDF.default();
    const logoImg = new Image();
    logoImg.src = "/assets/logo.jpeg";

    const width = 30;  // Adjust the width as needed
    const height = 30;

    doc.addImage(logoImg, 'PNG', 50, 10, width, height);

    const titleFontSize = 18; 
    doc.setFontSize(18); // Adjust the font size as needed
    doc.setFont('helvetica', 'bold');

    const title = 'C1 EduClass';
    const titleWidth = doc.getStringUnitWidth(title) * titleFontSize / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.width - titleWidth) / 2; // Centered horizontally
    const titleY = 25; // Adjust the Y coordinate as needed

    doc.text(title, titleX, titleY);

    const TutorHeading = "Booking Report"

    doc.text(TutorHeading, titleX, 40)

    //date
    const dateFontSize = 10; 
    doc.setFontSize(dateFontSize);
    doc.setFont('helvetica', 'normal');

    const currentDate = new Date().toLocaleDateString();

    const datetext="Date: "+ currentDate

    doc.text(datetext,10,50)

    const spaceBetweenLogoAndTable = 40; // Adjust this value as needed
    const tableX = 10;
    const tableY = 10 + 10 + spaceBetweenLogoAndTable;

    const headerFillColor = [60, 122, 110];
    
    const Ftime = this.ftotal
    const Ptime = this.ptotal
    
    const columns = ["Type","Total"]
    const rows = this.data.map((data: { name: any; total: any;  }) => [
      data.name,
      data.total,
    ]);

    const columnstt = ["",""]
    const rowstt = [["--Online", Ftime], ["--In Person", Ptime]]

    //total
    const totalBookings = this.ttotal + this.atotal + this.stotal;
    const ttext ="Total Number of bookings: " + totalBookings;

    const spaceBetweenTotalAndTable = 20; // Adjust this value as needed
    const totalX = 10;
    const totalY = 70 + 10 + spaceBetweenLogoAndTable;


    doc.text(ttext,totalX, totalY);


    
    

    (doc as any).autoTable({
      startY: tableY,
      head:[columns],
      body: rows,
      
      headStyles: {
          fillColor: headerFillColor
      }
    });

    (doc as any).autoTable({
      startY: tableY+30,
      //head:[columnstt],
      body: rowstt,

      headStyles:{
        fillColor: headerFillColor
      }
    })

    doc.save('Booking.pdf');
  }

}
