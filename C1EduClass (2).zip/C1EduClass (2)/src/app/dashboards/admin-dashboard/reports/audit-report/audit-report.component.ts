import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { AudittrailService } from 'src/app/services/audittrail.service';

@Component({
  selector: 'app-audit-report',
  templateUrl: './audit-report.component.html',
  styleUrls: ['./audit-report.component.scss']
})
export class AuditReportComponent implements OnInit {

  audits : any[] =[];
  constructor(private auditService: AudittrailService, private router: Router){
    this.getAllAudits();
  }
  ngOnInit(): void {
    this.getAllAudits();
    //this.countTutors();
    //console.log(this.total)
    
  }

  getAllAudits(){
    this.auditService.getAllAuditTrail().subscribe(result=>{
      this.audits = result
      console.log(this.audits)
    });
  }

  getAllAuditsForAdmin(){
    this.auditService.getAllAuditTrailByUser("Admin").subscribe(result=>{
      this.audits = result
    })
  }

  getAllAuditsForTutor(){
    this.auditService.getAllAuditTrailByUser("Tutor").subscribe(result=>{
      this.audits = result
    })
  }

  getAllAuditsForStudent(){
    this.auditService.getAllAuditTrailByUser("Student").subscribe(result=>{
      this.audits = result
    })
  }

  downloadPDF(){
    const doc = new jsPDF.default();
    const logoImg = new Image();
    logoImg.src = "/assets/logo.jpeg";

    const width = 30;  // Adjust the width as needed
    const height = 30;

    doc.addImage(logoImg, 'PNG', 30, 10, width, height);

    const titleFontSize = 18; 
    doc.setFontSize(18); // Adjust the font size as needed
    doc.setFont('helvetica', 'bold');

    const title = 'C1 EduClass: Audit Trail';
    const titleWidth = doc.getStringUnitWidth(title) * titleFontSize / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.width - titleWidth) / 2; // Centered horizontally
    const titleY = 25; // Adjust the Y coordinate as needed

    doc.text(title, titleX, titleY);

    //date
    const dateFontSize = 10; 
    doc.setFontSize(dateFontSize);
    doc.setFont('helvetica', 'normal');

    const currentDate = new Date().toLocaleDateString();

    const datetext="Date: "+ currentDate

    doc.text(datetext,10,35)

    const spaceBetweenLogoAndTable = 20; // Adjust this value as needed
    const tableX = 10;
    const tableY = 10 + 10 + spaceBetweenLogoAndTable;

    const headerFillColor = [60, 122, 110];

    const columns = ["Email","Action", "Date"]
    const rows = this.audits.map(audits => [
      audits.email,
      audits.action,
      audits.date,
    ]);

    //total
    //const totalTutor = this.total;
    //const ttext ="Total Number of tutors: " + totalTutor;

    const spaceBetweenTotalAndTable = 20; // Adjust this value as needed
    const totalX = 10;
    const totalY = 50 + 10 + spaceBetweenLogoAndTable;


    //doc.text(ttext,totalX, totalY);


    
    

    (doc as any).autoTable({
      startY: tableY,
      head:[columns],
      body: rows,
      headStyles: {
          fillColor: headerFillColor
      }
    });

    doc.save('audit.pdf');
  }
}
