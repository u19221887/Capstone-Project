import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import Chart from 'chart.js/auto';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';

import { APIService } from 'src/app/services/api.service';
import { Tutor } from 'src/app/shared/tutor';

@Component({
  selector: 'app-reports',
  templateUrl: './reports.component.html',
  styleUrls: ['./reports.component.scss']
})
export class ReportsComponent implements OnInit {

  total :any
  
  tot :any

  tutors: Tutor[]=[];

  constructor(private apiService: APIService, private router: Router){}
  ngOnInit(): void {
    this.getAllTutors();
    this.countTutors();
    console.log(this.total)
    
  }

  getAllTutors()
  {
    this.apiService.getAllTutors().subscribe(result=>{
    this.tutors = result as Tutor[];
  });
  }

  countTutors()
  {
    this.apiService.countTutor().subscribe(result=>{
      this.tot = result
      console.log(this.tot)
      this.total= this.tot.count
      console.log(this.total)

    });
  }
  downloadPDF(){
    const doc = new jsPDF.default();
    const logoImg = new Image();
    logoImg.src = "/assets/logo.jpeg";

    const width = 30;  // Adjust the width as needed
    const height = 30;

    doc.addImage(logoImg, 'PNG', 50, 10, width, height);

    const titleFontSize = 18; 
    doc.setFontSize(18); // Adjust the font size as needed
    doc.setFont('helvetica', 'bold');

    const title = 'C1 EduClass';
    const titleWidth = doc.getStringUnitWidth(title) * titleFontSize / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.width - titleWidth) / 2; // Centered horizontally
    const titleY = 25; // Adjust the Y coordinate as needed

    doc.text(title, titleX, titleY);

    //date
    const dateFontSize = 10; 
    doc.setFontSize(dateFontSize);
    doc.setFont('helvetica', 'normal');

    const currentDate = new Date().toLocaleDateString();

    const datetext="Date: "+ currentDate

    doc.text(datetext,10,35)

    const spaceBetweenLogoAndTable = 20; // Adjust this value as needed
    const tableX = 10;
    const tableY = 10 + 10 + spaceBetweenLogoAndTable;

    const headerFillColor = [60, 122, 110];

    const columns = ["Tutor Name","Tutor Surname", "Tutor Email","Tutor Phone Number","Tutor City"]
    const rows = this.tutors.map(tutors => [
      tutors.tutorName,
      tutors.tutorSurname,
      tutors.tutorEmail,
      tutors.tutorPhoneNumber,
      tutors.tutorCity
    ]);

    //total
    const totalTutor = this.total;
    const ttext ="Total Number of tutors: " + totalTutor;

    const spaceBetweenTotalAndTable = 20; // Adjust this value as needed
    const totalX = 10;
    const totalY = 50 + 10 + spaceBetweenLogoAndTable;


    doc.text(ttext,totalX, totalY);


    
    

    (doc as any).autoTable({
      startY: tableY,
      head:[columns],
      body: rows,
      headStyles: {
          fillColor: headerFillColor
      }
    });

    doc.save('tutor.pdf');
  }

}
