import { Component } from '@angular/core';
import { Router } from '@angular/router';
import * as jsPDF from 'jspdf';
import 'jspdf-autotable';
import { APIService } from 'src/app/services/api.service';

@Component({
  selector: 'app-user-report',
  templateUrl: './user-report.component.html',
  styleUrls: ['./user-report.component.scss']
})
export class UserReportComponent {
  constructor(private apiService: APIService, private router: Router){}
  
  ttot: any;
  ttotal: any;

  stot: any;
  stotal: any;

  atot: any;
  atotal: any;

  ftot: any;
  ftotal: any;

  ptot: any;
  ptotal: any;

  data: any;

   totalfTutor: any;


  countFulltime()
  {
    this.apiService.countFulltime().subscribe(result=>{
      this.ftot = result
      console.log(this.ftot)
      this.ftotal= this.ftot.count
      console.log(this.ftotal)

    });
  }

  countParttime()
  {
    this.apiService.countParttime().subscribe(result=>{
      this.ptot = result
      console.log(this.ptot)
      this.ptotal= this.ptot.count
      console.log(this.ptotal)

    });
  }

  countTutors()
  {
    this.apiService.countTutor().subscribe(result=>{
      this.ttot = result
      console.log(this.ttot)
      this.ttotal= this.ttot.count
      console.log(this.ttotal)

    });
  }

  countStudents()
  {
    this.apiService.countStudent().subscribe(result=>{
      this.stot = result
      console.log(this.stot)
      this.stotal= this.stot.count
      console.log(this.stotal)

    });
  }

  countAdmins()
  {
    this.apiService.countAdmin().subscribe(result=>{
      this.atot = result
      console.log(this.atot)
      this.atotal= this.atot.count
      console.log(this.atotal)

    });
  }


  ngOnInit(): void {
    this.countFulltime();
    this.countParttime();
    this.countTutors();
    this.countAdmins();
    this.countStudents();



  }




  
  getData(){

    console.log(this.ttotal)
     this.data = [
      {
        name: 'Admin',
        total: this.atotal,
        isExpand: false,
        // address: [
        //   {
        //     FullTime: 2,
        //     PartTime: 3,
        //   }
        //]
      },
      {
        name: 'Students',
        total: this.stotal,
        isExpand: false,
        // address: [
        //   {
        //     FullTime: 2,
        //     PartTime: 3,
        //   }
        // ]
      },
      {
        name: 'Tutors',
        total: this.ttotal,
        isExpand: false,
        address: [
          {
            FullTime: this.ftotal,
            PartTime: this.ptotal,
          }
        ]
      },
      
    ]
  }

  downloadPDF(){
    const doc = new jsPDF.default();
    const logoImg = new Image();
    logoImg.src = "/assets/logo.jpeg";

    const width = 30;  // Adjust the width as needed
    const height = 30;

    doc.addImage(logoImg, 'PNG', 50, 10, width, height);

    const titleFontSize = 18; 
    doc.setFontSize(18); // Adjust the font size as needed
    doc.setFont('helvetica', 'bold');

    const title = 'C1 EduClass';
    const titleWidth = doc.getStringUnitWidth(title) * titleFontSize / doc.internal.scaleFactor;
    const titleX = (doc.internal.pageSize.width - titleWidth) / 2; // Centered horizontally
    const titleY = 25; // Adjust the Y coordinate as needed

    doc.text(title, titleX, titleY);

    const TutorHeading = "User Report"

    doc.text(TutorHeading, titleX, 40)

    //date
    const dateFontSize = 10; 
    doc.setFontSize(dateFontSize);
    doc.setFont('helvetica', 'normal');

    const currentDate = new Date().toLocaleDateString();

    const datetext="Date: "+ currentDate

    doc.text(datetext,10,50)

    const spaceBetweenLogoAndTable = 40; // Adjust this value as needed
    const tableX = 10;
    const tableY = 10 + 10 + spaceBetweenLogoAndTable;

    const headerFillColor = [60, 122, 110];
    
    const Ftime = this.ftotal
    const Ptime = this.ptotal
    
    const columns = ["Type","Total"]
    const rows = this.data.map((data: { name: any; total: any;  }) => [
      data.name,
      data.total,
    ]);

    const columnstt = ["",""]
    const rowstt = [["--Fulltime", Ftime], ["--Part-Time", Ptime]]

    //total
    const totalTutor = this.ttotal + this.atotal + this.stotal;
    const ttext ="Total Number of users: " + totalTutor;

    const spaceBetweenTotalAndTable = 20; // Adjust this value as needed
    const totalX = 10;
    const totalY = 70 + 10 + spaceBetweenLogoAndTable;


    doc.text(ttext,totalX, totalY);


    
    

    (doc as any).autoTable({
      startY: tableY,
      head:[columns],
      body: rows,
      
      headStyles: {
          fillColor: headerFillColor
      }
    });

    (doc as any).autoTable({
      startY: tableY+30,
      //head:[columnstt],
      body: rowstt,

      headStyles:{
        fillColor: headerFillColor
      }
    })

    doc.save('Users.pdf');
  }

}
