import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { SuccessModalComponent } from 'src/app/utilities/success-modal/success-modal.component';
import { Subject } from 'src/app/shared/subject';

@Component({
  selector: 'app-edit-subject',
  templateUrl: './edit-subject.component.html',
  styleUrls: ['./edit-subject.component.scss']
})
export class EditSubjectComponent implements OnInit{
  editSubject!: FormGroup;
  profilePicture!: string | null;
  selectedFile!: File;

  subjectUpdate: Subject = new Subject();

  getSubject!: any
  subjects!: Subject []

  constructor(private router: Router, private route:ActivatedRoute, private apiService: APIService, private formBuilder: FormBuilder, private dialog: MatDialog, private icon: MatIcon)  {}

  ngOnInit() {
    this.editSubject = this.formBuilder.group({
      subjectName: ['', Validators.required],
      subjectDescription: ['', Validators.required],
    });

    let o = JSON.parse(localStorage.getItem('User')!);
    console.log(o);

    this.apiService.getSubjects().subscribe(response => {
      this.subjects = response as Subject[];
      console.log(this.subjects);
      this.getSubject = this.subjects.find(x => x.subjectId == o.subjectId)!;

    this.editSubject.patchValue({
      subjectName: this.getSubject.subjectName,
      subjectDescription: this.getSubject.subjectDescription,
    });
    console.log(this.getSubject)
})}




  maxLengthValidator(maxLength: number) {
    return (control: FormControl) => {
      if (control.value && control.value.length > maxLength) {
        return { maxlength: true };
      }
      return null;
    };
  }



  onSubmit(): void {


  }



  showSuccessModal() {
    const dialogRef = this.dialog.open(SuccessModalComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.editSubject.reset();
    });
  }


  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });
}
updateSubject() {
const updateSubject: Subject = {
  ...this.getSubject,

  subjectName: this.editSubject.value.subjectName,
  subjectDescription: this.editSubject.value.subjectDescription,
};
this.apiService.editSubject(this.getSubject.id, updateSubject)
.subscribe(
  (response: any) => {
    this.showSuccessModal();

    this.router.navigate(['/admin-dashboard']);
  },
  (error) => {
    console.error('Error updating subject:', error);
    alert('Error updating subject information.');
  }
);
}

}
