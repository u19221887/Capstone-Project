import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Subject } from 'src/app/shared/subject';
import { APIService } from 'src/app/services/api.service';


@Component({
  selector: 'app-admin-subjects',
  templateUrl: './admin-subjects.component.html',
  styleUrls: ['./admin-subjects.component.scss']
})
export class AdminSubjectsComponent implements OnInit{
  subjects:Subject[] = []

  constructor(private apiService: APIService, private router: Router) { }

  ngOnInit(): void {
    this.getSubjects()
  }

  getSubjects()
  {
    this.apiService.getSubjects().subscribe(result => {
      let subjectList:any[] = result
      subjectList.forEach((element) => {
        this.subjects.push(element)
        console.log(this.subjects)
      });
    })
  }

  deleteSubject(subjectId: Number){
    this.apiService.deleteSubject(subjectId).subscribe(result => {
      window.location.reload();
      });
    }
}
