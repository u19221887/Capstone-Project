import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { AudittrailService } from 'src/app/services/audittrail.service';
import { AddSubjectModalComponent } from 'src/app/utilities/modals/add-subject-modal/add-subject-modal.component';

@Component({
  selector: 'app-add-subject',
  templateUrl: './add-subject.component.html',
  styleUrls: ['./add-subject.component.scss']
})
export class AddSubjectComponent implements OnInit {
  newSubjectCreation!: FormGroup;

  acceptedauditTrail : FormGroup = this.formBuilder.group({
    Email: ["elysiapandarum@gmail.com"],
    Action: ["added a new subject: "]
  })

  s: any;
newvalue : any;
formData = new FormData();

   addAuditTrail(){
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.newvalue = this.s + " "+ this.newSubjectCreation.get('subjectName')!.value;

    this.acceptedauditTrail.get('Action')?.setValue(this.newvalue)
     if (this.acceptedauditTrail.valid)
     {
       this.formData.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.formData.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.formData).subscribe(()=>{
         console.log("added audit")
       })
     }
   }


  constructor(private router: Router, private formBuilder: FormBuilder, private dialog: MatDialog, private apiService: APIService, private auditTrailService: AudittrailService)  {}

  ngOnInit() {
    this.newSubjectCreation = this.formBuilder.group({
      subjectName: ['', Validators.required],
      subjectDescription: ['', Validators.required],
    });

  }

  onSubmit(): void {
    if (this.newSubjectCreation.valid) {
      this.apiService.addSubject(this.newSubjectCreation.value).subscribe(result => {
        this.addAuditTrail()
        this.router.navigate(['/admin-dashboard'])
  })
      console.log(this.newSubjectCreation.value);
      this.showSuccessModal();
    } else {

      this.validateAllFormFields(this.newSubjectCreation);
    }


  }



  showSuccessModal() {
    const dialogRef = this.dialog.open(AddSubjectModalComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.newSubjectCreation.reset();
    });
  }


  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });


}
}
