import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { AudittrailService } from 'src/app/services/audittrail.service';
import { Tutor } from 'src/app/shared/tutor';
import { TutorApplication } from 'src/app/shared/tutorapplications';
import { DeleteerrorComponent } from 'src/app/utilities/modals/deleteerror/deleteerror.component';

@Component({
  selector: 'app-tutor-profiles',
  templateUrl: './tutor-profiles.component.html',
  styleUrls: ['./tutor-profiles.component.scss']
})
export class TutorProfilesComponent implements OnInit {

  deleteddauditTrail : FormGroup = this.fb.group({
    Email: ["ctjbrand@gmail.com"],
    Action: ["deleted tutor:"]
  })

  formData= new FormData();


  constructor(private apiService: APIService, private router: Router, private dialog: MatDialog, private fb:FormBuilder, private auditTrailService : AudittrailService){
    
    
  }
  
  tutors: Tutor[] =[];

 

  getAllTutors()
  {
    this.apiService.getAllTutors().subscribe(result=>{
      let tutorList: any[]=result
      tutorList.forEach((element)=>{
        this.tutors.push(element)
        //console.log(tutorApplicationList);
        console.log(this.tutors);
      });
    })
  }



  ngOnInit(): void {
    this.getAllTutors();
    
  }

  deleteTutor(tutorId: Number, tutoremail: string){
    this.apiService.deleteTutor(tutorId).subscribe(result => {
      this.addAuditTrail(tutoremail)
      window.location.reload();

    },
    (error: any)=>{
      if(error.status ===401){
        this.unauthorizedModal();
      }
    })
  
  }

  unauthorizedModal() {
    const dialogRef = this.dialog.open(DeleteerrorComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });
}

s: any;
newvalue : any;
addAuditTrail(email:string){
  this.s = this.deleteddauditTrail.get('Action')?.value;
  this.newvalue = this.s + " "+ email;

  this.deleteddauditTrail.get('Action')?.setValue(this.newvalue)
     if (this.deleteddauditTrail.valid)
     {
       this.formData.append('Email', this.deleteddauditTrail.get('Email')!.value)
       this.formData.append('Action', this.deleteddauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.formData).subscribe(()=>{
         console.log("added audit")
       })
     }
}
}
