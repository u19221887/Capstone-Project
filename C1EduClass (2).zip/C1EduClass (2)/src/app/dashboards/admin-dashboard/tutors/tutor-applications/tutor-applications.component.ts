import {Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { TutorApplication } from 'src/app/shared/tutorapplications';
import {saveAs} from 'file-saver'
import { TutorService } from 'src/app/services/tutor.service';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { RegisterService } from 'src/app/services/register.service';
import { MatDialog } from '@angular/material/dialog';
import { SuccessfultutoremailComponent } from 'src/app/utilities/modals/successfultutoremail/successfultutoremail.component';
import { Admin } from 'src/app/shared/admin';
import { AudittrailService } from 'src/app/services/audittrail.service';


@Component({
  selector: 'app-tutor-applications',
  templateUrl: './tutor-applications.component.html',
  styleUrls: ['./tutor-applications.component.scss']
})
export class TutorApplicationsComponent implements OnInit {
  getAdmin!: Admin
  admins!: Admin []
  tutorTypeData: any;
  formData = new FormData();

 // displayedColumns : string[] = ['name','lname','pnumber','email','cv'];
 // dataSource = new MatTableDataSource<TutorApplication>();

  tutReg : FormGroup = this.fb.group({
  email: ['',[Validators.required, Validators.email]],
  password: ['#Password11']
})

   acceptedauditTrail : FormGroup = this.fb.group({
     Email: ["elysiapandarum@gmail.com"],
     Action: ["accepted tutor application for"]
   })

   rejectedauditTrail : FormGroup = this.fb.group({
    Email: ["elysiapandarum@gmail.com"],
    Action: ["rejected tutor application for"]
  })

  
  constructor(private apiService: APIService, private router: Router, private tutorservice : TutorService,private registerService: RegisterService, private fb: FormBuilder, private dialog: MatDialog, private auditTrailService : AudittrailService){
    let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

  this.apiService.getAdmins().subscribe(response => {


     this.admins = response as Admin[];
     console.log(this.admins)
     this.getAdmin=this.admins.find(x=> x.adminEmail==o.username)!
      console.log(this.getAdmin,this.admins)


    })
  }

 

  ngOnInit(): void {
    this.getPendingTutorApplications();
    this.GetTutorTypes();
    
  }

  tutorapplications: TutorApplication[] =[];

  getPendingTutorApplications()
  {
    this.apiService.GetPendingTutorApplications().subscribe(result=>{
      let tutorApplicationList: any[]=result
      tutorApplicationList.forEach((element)=>{
        this.tutorapplications.push(element)
        //console.log(tutorApplicationList);
        console.log(this.tutorapplications);
      });
    })
  }

  saveBase64asDoc(base64String: string, fileName: string)
  {
    try{
      const binaryData = atob(base64String);

      const arrayBuffer = new ArrayBuffer(binaryData.length);
      const uint8Array = new Uint8Array(arrayBuffer);
      for(let i=0;i<binaryData.length; i++)
      {
        uint8Array[i]= binaryData.charCodeAt(i);
      }

      const blob = new Blob([arrayBuffer], {type: 'application/msword'});

      saveAs(blob, fileName);
      console.log('Successfully saved the .doc file.');

    }
    catch(error)
    {
      console.error('Error saving the .doc file:', error);
    }
  }


tutor: any
  AcceptTutorApplication(tutorApplicationId: Number, tutorApplicationEmail : string)
  {
    this.apiService.AcceptTutorApplication(tutorApplicationId).subscribe(result=>{
      //this.router.navigate(['/tutor-registration',tutorApplicationId]);
      console.log("ACCEPTED")
      console.log(tutorApplicationId)
      this.apiService.addTutorByAdmin(tutorApplicationId).subscribe(result=>{
        console.log("added to tutor table")
      })

     //this.emailAcceptance(tutorApplicationEmail)
     this.addAuditTrail(tutorApplicationEmail)
     
      
       
      })
 
    
    
  }
s: any;
newvalue : any;

   addAuditTrail(email : string){
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.newvalue = this.s + " "+ email;

    this.acceptedauditTrail.get('Action')?.setValue(this.newvalue)
     if (this.acceptedauditTrail.valid)
     {
       this.formData.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.formData.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.formData).subscribe(()=>{
         console.log("added audit")
       })
     }
   }

   addRejectedAuditTrail(email : string){
    this.s = this.rejectedauditTrail.get('Action')?.value;
    this.newvalue = this.s + " "+ email;

    this.acceptedauditTrail.get('Action')?.setValue(this.newvalue)
     if (this.acceptedauditTrail.valid)
     {
       this.formData.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.formData.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.formData).subscribe(()=>{
         console.log("added audit")
       })
     }
   }



  AddTutorByAdmin(tutorApplicationId: Number)
  {
    this.apiService.addTutorByAdmin(tutorApplicationId).subscribe(()=>{
    console.log('Added a new tutor')
    
    
    })
  }

  RejectTutorApplication(tutorApplicationId: Number, tutorApplicationEmail : string)
  {
    this.apiService.RejectTutorApplication(tutorApplicationId).subscribe(result=>{
      window.location.reload();
    })

    this.addRejectedAuditTrail(tutorApplicationEmail)
  }

  emailAcceptance(email : string)
  {
    this.registerService.tutorEmail(email).subscribe(
      result =>{
        localStorage.setItem('Application', JSON.stringify(result));
        console.log('email sent')
        //this.successModal();
        window.location.reload();
      }
    );
  }

  GetTutorTypes(){
    this.apiService.getTutorTypes().subscribe(result => {
      let tutorTypeList:any[] = result
      tutorTypeList.forEach((element) => {
        this.tutorTypeData.push(element)
        console.log(this.tutorTypeData);
      });

      console.log(tutorTypeList)
    });
  }

  
  

  setEmail(email: string)
  {
    this.tutReg.get('email')?.setValue(email)
    this.registerService.RegisterTutor(this.tutReg.value).subscribe(()=>{
    console.log(this.tutReg)
    //this.tutReg.reset();
    console.log("sent")
    this.successModal(email);
    
    

    })
    
  }

  
  successModal(email:string){
    const dialogRef = this.dialog.open(SuccessfultutoremailComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
    setTimeout(() => {
      this.emailAcceptance(email)
      dialogRef.close();
    }, 10000); // 10 seconds
  }
  }

  
  

