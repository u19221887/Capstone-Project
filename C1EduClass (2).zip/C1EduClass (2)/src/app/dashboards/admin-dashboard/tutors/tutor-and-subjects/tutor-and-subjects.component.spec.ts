import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorAndSubjectsComponent } from './tutor-and-subjects.component';

describe('TutorAndSubjectsComponent', () => {
  let component: TutorAndSubjectsComponent;
  let fixture: ComponentFixture<TutorAndSubjectsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorAndSubjectsComponent]
    });
    fixture = TestBed.createComponent(TutorAndSubjectsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
