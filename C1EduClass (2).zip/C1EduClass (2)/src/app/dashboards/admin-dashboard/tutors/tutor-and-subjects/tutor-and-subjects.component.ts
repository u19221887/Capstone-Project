
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { Tutor } from 'src/app/shared/tutor';
import { Subject } from 'src/app/shared/subject';
import { TutorService } from 'src/app/services/tutor.service';
import { identity } from 'rxjs';
import { TutorSubject } from 'src/app/shared/tutorSubject';
import { APIService } from 'src/app/services/api.service';

@Component({
  selector: 'app-tutor-and-subjects',
  templateUrl: './tutor-and-subjects.component.html',
  styleUrls: ['./tutor-and-subjects.component.scss']
})
export class TutorAndSubjectsComponent {
  formData= new FormData();


  constructor(private tutorService: TutorService, private router: Router, private dialog: MatDialog, private fb:FormBuilder, private apiService: APIService){
    this.getTutorList();
    
  }
  
  tutorsubjects:any []=[];


 

  // getMyTutorSubjects(id: number) {
  //   this.tutorService.getMyTutorSubjects(id).subscribe(result=>{
  //     let tutorSubjectList: any[]=result
  //     tutorSubjectList.forEach((element)=>{
  //       //console.log(tutorApplicationList);
  //       console.log(this.tutorsubjects);
  //     });
  //   })
  // }

  getTutorList(){
    this.apiService.getTutorList().subscribe(result=>{
    let list:any[] = result
    list.forEach((element)=>{
      this.tutorsubjects.push(element)
      console.log(this.tutorsubjects)
    })
    })
  }



  ngOnInit(): void {
  }
}

