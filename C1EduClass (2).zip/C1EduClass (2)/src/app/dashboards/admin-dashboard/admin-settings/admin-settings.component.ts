import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatIcon } from '@angular/material/icon';
import { Router, ActivatedRoute } from '@angular/router';
import { HttpClient } from '@angular/common/http';
import { APIService } from 'src/app/services/api.service';
import { SuccessModalComponent } from 'src/app/utilities/success-modal/success-modal.component';
import { Admin } from 'src/app/shared/admin';

@Component({
  selector: 'app-admin-settings',
  templateUrl: './admin-settings.component.html',
  styleUrls: ['./admin-settings.component.scss']
})
export class AdminSettingsComponent  implements OnInit{
  registration!: FormGroup;
  profilePicture!: string | null;
  selectedFile!: File;

  editAdmin: Admin = new Admin();

  getAdmin!: any
  admins!: Admin []

  constructor(private router: Router, private route:ActivatedRoute, private apiService: APIService, private formBuilder: FormBuilder, private dialog: MatDialog, private icon: MatIcon)  {}

  ngOnInit() {
    this.registration = this.formBuilder.group({
      adminName: ['', Validators.required],
      adminSurname: ['', Validators.required],
      adminPhoneNumber: new FormControl('', [Validators.required, Validators.minLength(10), Validators.maxLength(10)]),
      adminEmail: ['', [Validators.required, Validators.email]],
      adminIdNumber: new FormControl('', [Validators.required, Validators.minLength(13), Validators.maxLength(13)]),
    });

    let o = JSON.parse(localStorage.getItem('User')!);
    console.log(o);

    this.apiService.getAdmins().subscribe(response => {
      this.admins = response as Admin[];
      console.log(this.admins);
      this.getAdmin = this.admins.find(x => x.adminEmail == o.username)!;

    this.registration.patchValue({
      adminName: this.getAdmin.adminName,
      adminSurname: this.getAdmin.adminSurname,
      adminPhoneNumber: this.getAdmin.adminPhoneNumber,
      adminEmail: this.getAdmin.adminEmail,
      adminIdNumber: this.getAdmin.adminIdNumber
    });
    console.log(this.getAdmin)
})}

  emailValidator(control: FormControl): { [key: string]: boolean } | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (control.value && !emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }

    return null;
  }



  maxLengthValidator(maxLength: number) {
    return (control: FormControl) => {
      if (control.value && control.value.length > maxLength) {
        return { maxlength: true };
      }
      return null;
    };
  }



  onSubmit(): void {


  }



  showSuccessModal() {
    const dialogRef = this.dialog.open(SuccessModalComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.registration.reset();
    });
  }


  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });
}
updateAdmin() {
const updateAdmin: Admin = {
  ...this.getAdmin,

  adminName: this.registration.value.adminName,
  adminSurname: this.registration.value.adminSurname,
  adminPhoneNumber: this.registration.value.adminPhoneNumber,
  adminEmail: this.registration.value.adminEmail,
  adminIdNumber: this.registration.value.adminIdNumber
};
this.apiService.editAdmin(this.getAdmin.id, updateAdmin)
.subscribe(
  (response: any) => {
    this.showSuccessModal();

    this.router.navigate(['/admin-profile']);
  },
  (error) => {
    console.error('Error updating admin:', error);
    alert('Error updating admin information.');
  }
);
}

updateEmail(){

  this.router.navigate(['/admin-update-email']);
}

changePassword(){

  this.router.navigate(['/admin-change-password']);
}
}
