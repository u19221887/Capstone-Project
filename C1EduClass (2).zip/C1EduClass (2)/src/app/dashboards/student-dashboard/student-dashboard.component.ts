import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';

@Component({
  selector: 'app-student-dashboard',
  templateUrl: './student-dashboard.component.html',
  styleUrls: ['./student-dashboard.component.scss']
})
export class StudentDashboardComponent implements OnInit{



  constructor(private studentService:StudentService , private router : Router, private activated:ActivatedRoute, private apiService : APIService) { }


  getStudent!: Student 
  students!: Student [];
  res!: any;
  showButton: boolean = false;
  x :number =0

  ngOnInit(): void {

  let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

  this.studentService.getAllStudent().subscribe(response => { 
     this.students = response as Student[]; 
     console.log(this.students)
     this.getStudent=this.students.find(x=> x.studentEmail==o.username)!
      console.log(this.getStudent,this.students)
  

      this.x =this.getStudent.id
      console.log(this.x)

      let j: any ={
        id: this.x
      }
      localStorage.setItem('Student', JSON.stringify(j));

     this.apiService.checkBookingStatus(this.getStudent.id).subscribe((result)=>{
       this.res = result;
       console.log(this.res);
       if(this.res == true){
         this.showButton = true;
       }
     })
       
    })
  
}

logout() {
  localStorage.removeItem('User');
 
}

onLogoutClick() {
  this.logout();
  this.router.navigate(['/user']);
}

}
