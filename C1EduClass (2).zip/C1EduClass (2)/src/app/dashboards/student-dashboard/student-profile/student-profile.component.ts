import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';

@Component({
  selector: 'app-student-profile',
  templateUrl: './student-profile.component.html',
  styleUrls: ['./student-profile.component.scss']
})
export class StudentProfileComponent implements OnInit {


  constructor(private studentService:StudentService , private router : Router, private activated:ActivatedRoute, private apiService:APIService ) { }


  getStudent!: Student 
  students!: Student []
  gradeName!: any

  ngOnInit(): void {

    // GET THE ID FROM THE URL 
  //  this.activated.params.subscribe(params => { 


  //   //SEND OFF REQUEST TO DB TO FIND OBJECT DATA 
  //   this.studentService.getStudent(params['id']).subscribe(response => { //SUBSCRIBE TO THE RESPONSE

     
  //    this.getStudent = response as Student;
  //    console.log(this.getStudent)

     
  //   })

  //  })
  let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

  this.studentService.getAllStudent().subscribe(response => { 

     
     this.students = response as Student[]; 
     console.log(this.students)
     this.getStudent=this.students.find(x=> x.studentEmail==o.username)!
      console.log(this.getStudent,this.students)
console.log(this.getStudent.grade)
  this.apiService.getGradeById(this.getStudent.grade).subscribe(response =>{
    let gradeList: any = response
    this.gradeName=gradeList.gradeName
    console.log(gradeList)
  }
  )
       
    })
  
}


}
