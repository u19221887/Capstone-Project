import { Component } from '@angular/core';
import { FileService } from 'src/app/services/file.service';
import { ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-upload',
  templateUrl: './upload.component.html',
  styleUrls: ['./upload.component.scss']
})
export class UploadComponent {
  selectedFile: File | null = null;
  containerName: string = '';
  customFileName: string = ''; // Added customFileName property

  constructor(
    private fileService: FileService,
    private route: ActivatedRoute
  ) {
    // Get the containerName from the route parameters
    this.containerName = this.route.snapshot.paramMap.get('containerName') || '';
  }

  onFileSelected(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    if (inputElement.files && inputElement.files.length) {
      this.selectedFile = inputElement.files[0];
    }
  }

  onUpload() {
    if (this.selectedFile) {
      const containerName = 'homeworkcontainer'; // Replace with the desired container name

      // Check if a custom file name has been provided
      if (this.customFileName.trim() !== '') {
        const newFile = new File([this.selectedFile], this.customFileName, {
          type: this.selectedFile.type,
        });

        this.fileService.uploadFile(newFile, containerName).subscribe(
          () => {
            Swal.fire({
              icon: 'success',
              title: 'File uploaded successfully',
              showConfirmButton: false,
              timer: 1500, // Auto close after 1.5 seconds
            });
          },
          (error) => {
            console.error('Error uploading file:', error);
            Swal.fire({
              icon: 'error',
              title: 'Error uploading file',
              text: 'Please try again later.',
            });
          }
        );
      } else {
        Swal.fire({
          icon: 'error',
          title: 'Custom file name is required',
          text: 'Please enter a custom file name before uploading.',
        });
      }
    }
  }
}
