import { Component } from '@angular/core';

@Component({
  selector: 'app-student-homework-rec',
  templateUrl: './student-homework-rec.component.html',
  styleUrls: ['./student-homework-rec.component.scss']
})
export class StudentHomeworkRecComponent {

}
