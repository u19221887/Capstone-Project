import { Component, Input } from '@angular/core';
import { FileService } from 'src/app/services/file.service';

@Component({
  selector: 'app-file-delete',
  templateUrl: './file-delete.component.html',
  styleUrls: ['./file-delete.component.scss']
})
export class FileDeleteComponent {
  @Input() filename: string = '';
  @Input() containerName: string = ''; // Add containerName as an input

  constructor(private fileService: FileService) { }

  onDeleteFile(): void {
    if (!this.filename || !this.containerName) {
      return;
    }

    this.fileService.deleteFile(this.filename, this.containerName) // Pass containerName
      .subscribe(
        () => {
          console.log('File deleted successfully.');
          // Notify parent component about the deletion with both filename and containerName
        },
        (error) => {
          console.error('Error deleting file:', error);
          // Handle error scenarios, display error messages, etc.
        }
      );
  }
}
