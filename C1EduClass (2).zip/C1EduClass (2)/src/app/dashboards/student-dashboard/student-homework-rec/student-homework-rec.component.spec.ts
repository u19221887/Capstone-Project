import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentHomeworkRecComponent } from './student-homework-rec.component';

describe('StudentHomeworkRecComponent', () => {
  let component: StudentHomeworkRecComponent;
  let fixture: ComponentFixture<StudentHomeworkRecComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentHomeworkRecComponent]
    });
    fixture = TestBed.createComponent(StudentHomeworkRecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
