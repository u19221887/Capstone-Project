import { Component, OnInit, TemplateRef  } from '@angular/core';
import { FormBuilder,Validators,FormControl, FormGroup, AbstractControl, ValidationErrors} from '@angular/forms';

import { UpdateStudentModelComponent } from 'src/app/utilities/modals/update-student-model/update-student-model.component';
import { MatDialog } from '@angular/material/dialog';
import { HttpClient } from '@angular/common/http';
import { Router, ActivatedRoute } from '@angular/router';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';




@Component({
  selector: 'app-student-settings',
  templateUrl: './student-settings.component.html',
  styleUrls: ['./student-settings.component.scss']
})
export class StudentSettingsComponent implements OnInit {

  registration!: FormGroup;
  profilePicture!: string | null;
  selectedFile!: File;

  editStudent: Student = new Student();

  getStudent!: any
  students!: Student []





  constructor(private formBuilder: FormBuilder, private dialog: MatDialog, private http: HttpClient, private studentService:StudentService, private router : Router , private activated:ActivatedRoute)  {}

  ngOnInit() {
    this.registration = this.formBuilder.group({
      studentName: [''],
      parentTitle: [''],
      studentLastName: [''],
      parentName: [''],
      studentNumber: new FormControl(''),
      parentLastName: [''],
      studentEmail: [''],
      parentNumber: new FormControl(''),
      grade: [''],
      parentEmail: [''],
      //subject: [''],
      province: [''],
      birthday: [''],
      city: [''],
      address: [''],
      postalCode: [''],
      age: ['']
    });

    // let o=JSON.parse(localStorage.getItem('User')!)
    // console.log(o)

    // this.studentService.getAllStudent().subscribe(response => {


    //    this.students = response as Student[];
    //    console.log(this.students)
    //    this.getStudent=this.students.find(x=> x.studentEmail==o.username)!
    //     console.log(this.getStudent,this.students)


    //   })



      let o = JSON.parse(localStorage.getItem('User')!);
    console.log(o);

    this.studentService.getAllStudent().subscribe(response => {
      this.students = response as Student[];
      console.log(this.students);
      this.getStudent = this.students.find(x => x.studentEmail == o.username)!;


      this.registration.patchValue({
        studentName: this.getStudent.studentName,


        parentTitle: this.getStudent.parentTitle,
        studentLastName: this.getStudent.studentSurname,
        parentName: this.getStudent.parentName,
        studentNumber: this.getStudent.studentPhoneNumber,
        parentLastName: this.getStudent.parentSurname,
        studentEmail: this.getStudent.studentEmail,
        parentNumber: this.getStudent.parentPhoneNumber,
        grade: this.getStudent.grade,
        parentEmail: this.getStudent.parentEmail,
        //subject: this.getStudent.subject,
        province: this.getStudent.studentProvince,
        birthday: this.getStudent.dateOfBirth,
        city: this.getStudent.studentCity,
        address: this.getStudent.studentAddress,
        postalCode: this.getStudent.studentPostalCode,
        age: this.getStudent.studentAge


      });
      console.log(this.getStudent)
    });





  }


  onFileSelected(event: any) {
    this.selectedFile = event.target.files[0];
  }


  uploadImage() {
    const formData = new FormData();
    formData.append('image', this.selectedFile);

    this.http.post<any>('http://localhost:4200/upload', formData).subscribe(
      (response) => {
        // Update profile picture URL
        this.profilePicture = response.imageUrl;
      },
      (error) => {
        console.error('Error uploading image:', error);
      }
    );
  }


  deleteImage() {
    this.http.delete<any>('http://localhost:4200/delete').subscribe(
      () => {
        // Clear profile picture URL
        this.profilePicture = null;
      },
      (error) => {
        console.error('Error deleting image:', error);
      }
    );
  }

  emailValidator(control: FormControl): { [key: string]: boolean } | null {
    const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

    if (control.value && !emailPattern.test(control.value)) {
      return { invalidEmail: true };
    }

    return null;
  }



  maxLengthValidator(maxLength: number) {
    return (control: FormControl) => {
      if (control.value && control.value.length > maxLength) {
        return { maxlength: true };
      }
      return null;
    };
  }


  onSubmit(): void {


    // if (this.registration.valid) {

    //   console.log(this.registration.value);
    //   this.showSuccessModal();
    // } else {

    //   this.validateAllFormFields(this.registration);
    // }


  }

  showSuccessModal() {
    const dialogRef = this.dialog.open(UpdateStudentModelComponent, {
      width: '700px',
    height: '400px',
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe(() => {

      this.registration.reset();
    });
  }





  validateAllFormFields(formGroup: FormGroup): void {
    Object.keys(formGroup.controls).forEach(field => {
      const control = formGroup.get(field)!;
      if (control instanceof FormGroup) {
        this.validateAllFormFields(control);
      } else {
        control.markAsTouched({ onlySelf: true });
      }
    });

}






updateStudent() {



  const updatedStudent: Student = {
    ...this.getStudent,

    studentName: this.registration.value.studentName,
    parentTitle: this.registration.value.parentTitle,
    studentSurname: this.registration.value.studentLastName,
    parentName: this.registration.value.parentName,
    studentPhoneNumber: this.registration.value.studentNumber,
    parentSurname: this.registration.value.parentLastName,
    studentEmail: this.registration.value.studentEmail,
    parentPhoneNumber: this.registration.value.parentNumber,
    grade: this.registration.value.grade,
    parentEmail: this.registration.value.parentEmail,

    studentAddress: this.registration.value.address,
    studentProvince: this.registration.value.province,
    dateOfBirth: this.registration.value.birthday,
    studentCity: this.registration.value.city,
    studentPostalCode: this.registration.value.postalCode,
    studentAge: this.registration.value.age,
  };

  // // Check if a new image is selected
  // if (this.selectedFile) {
  //   // Convert image to base64
  //   const reader = new FileReader();
  //   reader.onload = (event: any) => {
  //     const base64Image = event.target.result;
  //     // Update the updatedStudent object with the new image data
  //     updatedStudent.studentImage = base64Image;

  //     // Call the service method to update the student
  //     this.studentService.updateStudent(this.getStudent.studentId, updatedStudent)
  //       .subscribe(
  //         (response: any) => {
  //           this.showSuccessModal();
  //           this.router.navigate(['/student-profile']);
  //         },
  //         (error) => {
  //           console.error('Error updating student:', error);
  //           alert('Error updating student information.');
  //         }
  //       );
  //   };
  //   reader.readAsDataURL(this.selectedFile);
  // } else {
  //   // No new image selected, update student without image
  //   // Call the service method to update the student
  //   this.studentService.updateStudent(this.getStudent.studentId, updatedStudent)
  //     .subscribe(
  //       // ... rest of your code ...
  //       (response: any) => {
  //         this.showSuccessModal();

  //         this.router.navigate(['/student-profile']);
  //       },
  //       (error) => {
  //         console.error('Error updating student:', error);
  //         alert('Error updating student information.');
  //       }
  //     );
  // }


  this.studentService.updateStudent(this.getStudent.id, updatedStudent)
    .subscribe(
      (response: any) => {
        this.showSuccessModal();

        this.router.navigate(['/student-profile']);
      },
      (error) => {
        console.error('Error updating student:', error);
        alert('Error updating student information.');
      }
    );
}

updateEmail(){

  this.router.navigate(['/student-update-email']);
}

changePassword(){

  this.router.navigate(['/student-change-password']);
}

}

// updateStudent()
// {
//   let student = new Student();
//   student.studentName = this.registration.value.studentName;
//   student.parentTitle = this.registration.value.parentTitle;
//   student.studentSurname = this.registration.value.studentLastName;

//   student.parentName = this.registration.value.parentName;
//   student.studentPhoneNumber = this.registration.value.studentNumber;
//   student.parentSurname = this.registration.value.parentLastName

//   student.studentEmail = this.registration.value.studentEmail
//   student.parentPhoneNumber = this.registration.value.parentNumber
//   student.grade = this.registration.value.grade

//   student.parentEmail = this.registration.value.parentEmail
//   student.subject = this.registration.value.subject
//   student.studentAddress = this.registration.value.address

//   student.studentProvince = this.registration.value.province
//   student.dateOfBirth = this.registration.value.birthday
//   student.studentCity = this.registration.value.city
//   student.studentPostalCode = this.registration.value.postalCode
//   student.studentAge = this.registration.value.age

//  this.studentService.updateStudent(this.editStudent.studentId,student).subscribe((response:any) => {

//   // if(response.statusCode == 200)
//   // {
//   //   this.router.navigate(['/student-profile'])
//   // }
//   // else
//   // {
//   //   alert(response.message);
//   // }
//  });

// }

 // GET THE ID FROM THE URL
     //this.activated.params.subscribe(params => {

      //SEND OFF REQUEST TO DB TO FIND OBJECT DATA
      //this.studentService.getStudent(params['id']).subscribe(response => { //SUBSCRIBE TO THE RESPONSE

       //MAP THE RESPONSE TP THE CURRENT EDITCOURSE OBJECT
       //this.editStudent = response as Student;

       //MAP THE RESPONSE VALUES TO THE FORM
      //  this.registration.controls['studentName'].setValue(this.editStudent.studentName);
      //  this.registration.controls['parentTitle'].setValue(this.editStudent.parentTitle);
      //  this.registration.controls['studentLastName'].setValue(this.editStudent.studentSurname);
      //  this.registration.controls['parentName'].setValue(this.editStudent.parentName);
      //  this.registration.controls['studentNumber'].setValue(this.editStudent.studentPhoneNumber);
      //  this.registration.controls['parentLastName'].setValue(this.editStudent.parentSurname);
      //  this.registration.controls['studentEmail'].setValue(this.editStudent.studentEmail);
      //  this.registration.controls['parentNumber'].setValue(this.editStudent.parentPhoneNumber);
      //  this.registration.controls['grade'].setValue(this.editStudent.grade);
      //  this.registration.controls['parentEmail'].setValue(this.editStudent.parentEmail);
      //  this.registration.controls['subject'].setValue(this.editStudent.subject);
      //  this.registration.controls['address'].setValue(this.editStudent.studentAddress);
      //  this.registration.controls['province'].setValue(this.editStudent.studentProvince);
      //  this.registration.controls['birthday'].setValue(this.editStudent.dateOfBirth);
      //  this.registration.controls['city'].setValue(this.editStudent.studentCity);
      //  this.registration.controls['postalCode'].setValue(this.editStudent.studentPostalCode);
      //  this.registration.controls['age'].setValue(this.editStudent.studentAge);



      //})

    // })


