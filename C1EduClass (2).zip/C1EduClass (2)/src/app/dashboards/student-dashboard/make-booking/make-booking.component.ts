import { Component, OnInit, ViewChild } from '@angular/core';
import { TuiDay } from '@taiga-ui/cdk';
// import { ToastrService } from 'ngx-toastr';
import { BookingService } from 'src/app/services/booking.service';
import { TimeslotService } from 'src/app/services/timeslot.service';
import { TutorService } from 'src/app/services/tutor.service';
import { Booking } from 'src/app/shared/models/booking.model';
import { SuccessfulBookingComponent } from 'src/app/utilities/modals/successful-booking/successful-booking.component';
import { FailedBookingComponent } from 'src/app/utilities/modals/failed-booking/failed-booking.component';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AudittrailService } from 'src/app/services/audittrail.service';
import { APIService } from 'src/app/services/api.service';
import { TuiCalendarComponent } from '@taiga-ui/core';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';

@Component({
  selector: 'app-make-booking',
  templateUrl: './make-booking.component.html',
  styleUrls: ['./make-booking.component.css'],
})
export class MakeBookingComponent implements OnInit {

  


  value: TuiDay | null = null;
  today: TuiDay = TuiDay.currentLocal();
  booking: Booking = new Booking();
  tutorList: any[] = [];
  tutor!: any;
  TutorChosen: string = 'N/A';
  subjects: any[] = [];
  iaShowSubjects: boolean = false;

  bookingInfoPromptInfo: any;

  bookingPrice: string = '';
  open = false;

  mySubjects : any [] =[];

  add = new FormData(); 
  student: string ='';
  
  acceptedauditTrail : FormGroup = this.fb.group({
    Email: [''],
    Action: ["made booking for "]
  })

  s: any;
  x: any;
  gradeval : any;
  newvalue : any;
  studentval : any;


   addAuditTrail(){
    let j = JSON.parse(localStorage.getItem('User')!)
    console.log(j)
    this.student = j.username
    console.log(this.student)
    
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.x = this.s + this.booking.TutorAvailabiltyId;
    this.newvalue = this.student;

    this.acceptedauditTrail.get('Email')?.setValue(this.newvalue)
    this.acceptedauditTrail.get('Action')?.setValue(this.x)
     if (this.acceptedauditTrail.valid)
     {
       this.add.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.add.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.add).subscribe(()=>{
         console.log("added audit")
       })
     }
   }


  constructor(
    private companyAvailabilityService: TimeslotService,
    private bookingService: BookingService,
    private tutorService: TutorService,
    private dialog: MatDialog,
    private router: Router,
    private fb: FormBuilder,
    private auditTrailService : AudittrailService,
    private apiService : APIService,
    private studentService: StudentService
    // private toastr: ToastrService
  ) {
    //TODO: get student Id from where you store it
    this.booking.StudentId = 1;

    //TODO: get tutor Id from where you store it
    const tutorId = 9;
  }

  students!: Student[];
  getStudent! : Student;
  
  ngOnInit(){
    this.getAllSubject()
    let o = JSON.parse(localStorage.getItem('User')!);

    this.studentService.getAllStudent().subscribe((response) => {
      this.students = response as Student[];
      console.log(this.students);
      this.getStudent = this.students.find(
        (x) => x.studentEmail == o.username
      )!;
      console.log(this.getStudent, this.students);
      

      this.studentval = this.getStudent.id
      console.log(this.studentval)
      this.gradeval =this.getStudent.grade
      console.log(this.gradeval)
  })
}
  

  getAllSubject(){
    this.apiService.getSubjects().subscribe((result : any)=>{
      this.mySubjects = result
    })
  }

  selectedSubject: { id: number, subjectName: string, subjectDescription: string } = { id: 0, subjectName: '', subjectDescription: '' }; 
  idtotake :any;
  
  
  onSubjectChange(event: any) {
    
    const selectedIndex = event.target.selectedIndex;
    console.log(selectedIndex)
    this.selectedSubject = this.mySubjects[selectedIndex];


   
    console.log(this.selectedSubject)
    // Here, you can access the selected subject's properties like id, subjectname, subjectdescription
    console.log("Selected ID:", this.selectedSubject.id);
    console.log("Selected Name:", this.selectedSubject.subjectName);
    console.log("Selected Description:", this.selectedSubject.subjectDescription);
    this.idtotake= this.selectedSubject.id;
  }
  subjectid :number =0;
  newlist : any[] =[];

  onDayClick(day: TuiDay): void {
    this.value = day;

     console.log(this.value.toLocalNativeDate().toDateString());
     this.subjectid = this.selectedSubject.id
     console.log(this.subjectid)
 
     console.log(this.idtotake);
     
     const params = { subjectid: this.idtotake, grade: this.gradeval, date: this.value.toLocalNativeDate().toDateString() };
     
     
     this.apiService.getTutorsThatTutorThatSubject(this.idtotake, this.gradeval,this.value.toLocalNativeDate().toDateString())
     .subscribe((newdata:any) =>{
       this.newlist = newdata;
       console.log(this.newlist)
     })
    

    this.companyAvailabilityService
      .getAllAvailabilityTimes(this.value.toLocalNativeDate().toDateString())
      .subscribe((data: any) => {
        this.tutorList = data;
      });
  }

  setTutor() {

    this.booking.TutorAvailabiltyId = this.tutor?.id ?? 0;
    //this.getTutorSubjects(this.tutor?.tutorId );
    this.TutorChosen = this.tutor?.name ?? 'N/A';
  }

  setPrice() {
    this.bookingPrice = this.booking.SessionCostId == 1 ? 'R150:00' : 'R250:00';
  }

  getTime(dateTime: string, endTime: string) {
    return `${new Date(dateTime).toLocaleTimeString('en-ZA')} - ${new Date(
      endTime
    ).toLocaleTimeString('en-ZA')}   `;
  }

  ConfirmDialog() {
    this.booking.SessionCostId = Number(this.booking.SessionCostId);
    this.booking.TutorSubjectId = Number(this.subjectid);

    //build
    this.bookingInfoPromptInfo = {
      tutor: this.TutorChosen,
      sessiontype: this.booking.SessionCostId == 1 ? 'Online' : 'In Person',
      subject: this.mySubjects.find(
        (r) => r.subjectid == Number(this.booking.TutorSubjectId)
      )?.subjectDescription,
      timeSlot: this.getTime(this.tutor.startTime, this.tutor.endTime),
      price: this.bookingPrice,
    };

    this.open = true;
  }

  makeBooking() {
    this.booking.StudentId = this.studentval;
    this.bookingService.makeBooking(this.booking).subscribe((booked) => {

      if (booked == null) {
        // this.toastr.error('Booking failed');
        this.failed();
        return;
      }
      // this.toastr.success('Successfully booked');
      this.addAuditTrail();
      this.success();

      this.router.navigate(['/student-dashboard/view-booking']).then((navigated: boolean) => {
        if (navigated) {

        }
      });
    });
  }

  getTutorSubjects(id: number) {
    this.tutorService.getSubjectsLinkedToTutor(id).subscribe((data: any) => {

      this.subjects = data;
      this.iaShowSubjects = true;
    });
  }

  
  
  openPDF(pdfUrl: string) {
    // Implement your logic to open the PDF document here
    // You can use a library like pdf.js or open it in a new browser tab
    window.open(pdfUrl, '_blank');
}

success() {
  const dialogRef = this.dialog.open(SuccessfulBookingComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    //this.login.reset();
  });
}

failed() {
  const dialogRef = this.dialog.open(FailedBookingComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    //this.login.reset();
  });
}

}
