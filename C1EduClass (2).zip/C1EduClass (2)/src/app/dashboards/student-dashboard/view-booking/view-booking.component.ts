import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/services/booking.service';
import { PaymentService } from 'src/app/services/payment.service';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';

@Component({
  selector: 'app-view-booking',
  templateUrl: './view-booking.component.html',
  styleUrls: ['./view-booking.component.css']
})
export class ViewBookingStudentComponent implements OnInit {
  sessionList: any[] = [];
  totalPrice: number = 0;
  constructor(private bookingService: BookingService,public paymentService: PaymentService,private studentService: StudentService) {
    let o = JSON.parse(localStorage.getItem('User')!);

    this.studentService.getAllStudent().subscribe((response) => {
      this.students = response as Student[];
      console.log(this.students);
      this.getStudent = this.students.find(
        (x) => x.studentEmail == o.username
      )!;
      console.log(this.getStudent, this.students);
      

      this.studentval = this.getStudent.id
      this.bookingService.getBookingSessionsStudent(this.studentval
        ).subscribe((data: any) => {
          console.log(data)
    
          this.sessionList = data
          })
  })
    //TODO: get Student Id
    
   }

   students!: Student[];
   getStudent! : Student;
   studentval : any;

  ngOnInit() {
   
}


  getTime(dateTime: string, endTime: string){
    return `${new Date(dateTime).toLocaleTimeString('en-ZA')} - ${new Date(endTime).toLocaleTimeString('en-ZA')}   `
  }

   totalAmount(totalPrice: string): number {
     var Price = Number(totalPrice)* 100;
    return Price ;
  }

    //book
    paymentDone(ref: any,amount: number, bookingId: number) {

      const bookingObjt: any = {
        BookingId: bookingId,
        Date:  Date.now(),
        Ref: ref.reference,
        Amount: Number(amount),
      }

      // get booking id from somewhere
      this.bookingService.updateBookingStatus(bookingObjt).subscribe((data: any) => {
        // this.toastr.success('Booking successful');
      });
    }


}
