import { ComponentFixture, TestBed } from '@angular/core/testing';

import { StudentUpdateEmailComponent } from './student-update-email.component';

describe('StudentUpdateEmailComponent', () => {
  let component: StudentUpdateEmailComponent;
  let fixture: ComponentFixture<StudentUpdateEmailComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [StudentUpdateEmailComponent]
    });
    fixture = TestBed.createComponent(StudentUpdateEmailComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
