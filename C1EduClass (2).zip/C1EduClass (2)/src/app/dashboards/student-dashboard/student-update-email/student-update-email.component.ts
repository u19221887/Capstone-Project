import { Component, OnInit } from '@angular/core';
import { StudentService } from 'src/app/services/student.service';
import { Student } from 'src/app/shared/student';
import { Router, ActivatedRoute } from '@angular/router';
import { FormBuilder,Validators,FormControl, FormGroup, AbstractControl } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';

import { SuccessfulEmailUpdateComponent } from 'src/app/utilities/modals/successful-email-update/successful-email-update.component';
@Component({
  selector: 'app-student-update-email',
  templateUrl: './student-update-email.component.html',
  styleUrls: ['./student-update-email.component.scss']
})
export class StudentUpdateEmailComponent implements OnInit {


  constructor(private dialog: MatDialog,private studentService:StudentService , private router : Router, private activated:ActivatedRoute, private formBuilder: FormBuilder) { }
  updateEmail!: FormGroup

  getStudent!: any
  students!: Student []

//   ngOnInit(): void {



//     this.updateEmail = this.formBuilder.group({

//       email: ['', [Validators.required, Validators.email]],

//     },

//     );


//     let o=JSON.parse(localStorage.getItem('User')!)
//   console.log(o)

//   this.studentService.getAllStudent().subscribe(response => {


//      this.students = response as Student[];
//      console.log(this.students)
//      this.getStudent=this.students.find(x=> x.studentEmail==o.username)!
//       console.log(this.getStudent,this.students)


//     })



//     this.updateEmail.patchValue({

//       email: this.getStudent.studentEmail,

//     });

// }

ngOnInit(): void {
  this.updateEmail = this.formBuilder.group({
    email: ['', [Validators.required, Validators.email]],


  });

  let o = JSON.parse(localStorage.getItem('User')!);

  this.studentService.getAllStudent().subscribe(response => {
    this.students = response as Student[];
    this.getStudent = this.students.find(x => x.studentEmail == o.username)!;

    this.updateEmail.patchValue({
      email: this.getStudent.studentEmail,






    });
  });
}


onSubmit(): void {
  // if (this.updateEmail.valid) {

  //   console.log(this.updateEmail.value);


  // } else {

  //   this.validateAllFormFields(this.updateEmail);
  // }


}

validateAllFormFields(formGroup: FormGroup): void {
  Object.keys(formGroup.controls).forEach(field => {
    const control = formGroup.get(field)!;
    if (control instanceof FormGroup) {
      this.validateAllFormFields(control);
    } else {
      control.markAsTouched({ onlySelf: true });
    }
  });



}


emailValidator(control: FormControl): { [key: string]: boolean } | null {
  const emailPattern = /^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/;

  if (control.value && !emailPattern.test(control.value)) {
    return { invalidEmail: true };
  }

  return null;
}


updateStudent() {



  const updatedStudent: Student = {
    ...this.getStudent,


    studentEmail: this.updateEmail.value.email,


    //for place holding

    // studentName: this.updateEmail.value.studentName,
    // parentTitle: this.updateEmail.value.parentTitle,
    // studentSurname: this.updateEmail.value.studentLastName,
    // parentName: this.updateEmail.value.parentName,
    // studentPhoneNumber: this.updateEmail.value.studentNumber,
    // parentSurname: this.updateEmail.value.parentLastName,

    // parentPhoneNumber: this.updateEmail.value.parentNumber,
    // grade: this.updateEmail.value.grade,
    // parentEmail: this.updateEmail.value.parentEmail,
    // subject: this.updateEmail.value.subject,
    // studentAddress: this.updateEmail.value.address,
    // studentProvince: this.updateEmail.value.province,
    // dateOfBirth: this.updateEmail.value.birthday,
    // studentCity: this.updateEmail.value.city,
    // studentPostalCode: this.updateEmail.value.postalCode,
    // studentAge: this.updateEmail.value.age,

  };


  this.studentService.updateStudent(this.getStudent.id, updatedStudent)
  .subscribe(
    (response: any) => {
      this.showUpdateModal();

      this.router.navigate(['/student-login']);
    },
    (error) => {
      console.error('Error updating student:', error);
      alert('Error updating student information.');
    }
  );

}


showUpdateModal() {
  const dialogRef = this.dialog.open(SuccessfulEmailUpdateComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    //this.updateEmail.reset();
  });
}
  }


