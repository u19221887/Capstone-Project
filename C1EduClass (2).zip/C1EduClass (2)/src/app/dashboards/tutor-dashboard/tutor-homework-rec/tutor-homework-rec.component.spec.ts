import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorHomeworkRecComponent } from './tutor-homework-rec.component';

describe('TutorHomeworkRecComponent', () => {
  let component: TutorHomeworkRecComponent;
  let fixture: ComponentFixture<TutorHomeworkRecComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorHomeworkRecComponent]
    });
    fixture = TestBed.createComponent(TutorHomeworkRecComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
