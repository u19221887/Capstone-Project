import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TuploadComponent } from './tupload.component';

describe('TuploadComponent', () => {
  let component: TuploadComponent;
  let fixture: ComponentFixture<TuploadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TuploadComponent]
    });
    fixture = TestBed.createComponent(TuploadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
