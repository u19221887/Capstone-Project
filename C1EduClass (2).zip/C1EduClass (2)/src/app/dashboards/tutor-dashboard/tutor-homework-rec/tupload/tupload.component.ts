import { Component } from '@angular/core';
import { FileService } from 'src/app/services/file.service';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-tupload',
  templateUrl: './tupload.component.html',
  styleUrls: ['./tupload.component.scss']
})
export class TuploadComponent {
  selectedFile: File | null = null;
  containerName: string = '';

  constructor(
    private fileService: FileService,
    private route: ActivatedRoute,
    private router: Router
  ) {
    // Get the containerName from the route parameters
    this.containerName = this.route.snapshot.paramMap.get('containerName') || '';
  }

  onFileSelected(event: Event) {
    const inputElement = event.target as HTMLInputElement;
    if (inputElement.files && inputElement.files.length) {
      this.selectedFile = inputElement.files[0];
    }
  }

  onUpload() {
    if (this.selectedFile) {
      const containerName = 'studentcontainer'; // Replace with the desired container name
      this.fileService.uploadFile(this.selectedFile, containerName).subscribe(
        () => {
          alert('File uploaded successfully.');
        },
        (error) => {
          console.error('Error uploading file:', error);
          alert('Error uploading file. Please try again later.');
        }
      );
    }
  }

}
