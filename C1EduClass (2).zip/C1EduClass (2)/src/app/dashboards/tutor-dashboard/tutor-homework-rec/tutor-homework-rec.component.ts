import { Component } from '@angular/core';

@Component({
  selector: 'app-tutor-homework-rec',
  templateUrl: './tutor-homework-rec.component.html',
  styleUrls: ['./tutor-homework-rec.component.scss']
})
export class TutorHomeworkRecComponent {

}
