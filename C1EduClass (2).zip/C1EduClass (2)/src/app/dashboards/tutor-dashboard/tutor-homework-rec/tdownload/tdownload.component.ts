import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { RouterModule } from '@angular/router';
import { FileService } from 'src/app/services/file.service';

@Component({
  selector: 'app-tdownload',
  templateUrl: './tdownload.component.html',
  styleUrls: ['./tdownload.component.scss']
})
export class TdownloadComponent implements OnInit {
  fileList: string[] = [];
  videoUrl: string | null = null; // Variable to store the video URL
  imageUrl: string | null = null; // Variable to store the image URL
  containerName: string = 'homeworkcontainer'; // Default container name
  searchQuery: string = '';

  constructor(private fileService: FileService, private route: ActivatedRoute, private router: Router) { }

  ngOnInit(): void {
    // Read the 'containerName' route parameter and set the containerName accordingly
    this.route.params.subscribe(params => {
      const containerName = params['containerName'];
      if (containerName === 'homeworkcontainer' || containerName === 'studentcontainer') {
        this.containerName = containerName;
        this.fetchFileList();
      } else {
        // Handle invalid containerName
        console.error('Invalid containerName:', containerName);
        // You might want to redirect or show an error message here
      }
    });
  }

  // Function to navigate to DownloadComponent with a specific containerName
  navigateToDownload(containerName: string) {
    // Use the router to navigate to the DownloadComponent
    this.router.navigate(['/tutor-download', containerName]);
  }

  fetchFileList(): void {
    // Load files from the specified container
    this.fileService.getFilesList(this.containerName).subscribe(
      (fileList) => {
        this.fileList = fileList;
      },
      (error) => {
        console.error('Error fetching file list:', error);
        alert('Error fetching file list. Please try again later.');
      }
    );
  }

  onDownload(filename: string): void {
    this.fileService.downloadFile(filename, this.containerName).subscribe( // Pass containerName here
      (data) => {
        if (filename.endsWith('.mp4')) {
          // Download video files by creating a link and triggering a click event
          const blob = new Blob([data], { type: 'video/mp4' });
          const url = window.URL.createObjectURL(blob);

          const link = document.createElement('a');
          link.href = url;
          link.download = filename;
          document.body.appendChild(link);
          link.click();
          document.body.removeChild(link);
        } else {
          // For other file types, trigger the file download as before
          this.downloadFile(data, filename); // Add this line to call the downloadFile function
        }
      },
      (error) => {
        console.error('Error downloading file:', error);
        alert('Error downloading file. Please try again later.');
      }
    );
  }

  private downloadFile(data: any, filename: string) {
    const blob = new Blob([data], { type: 'application/octet-stream' });
    const url = window.URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = filename;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  }

  onView(filename: string): void {
    this.fileService.downloadFile(filename, this.containerName).subscribe(
      (data) => {
        if (filename.endsWith('.pdf')) {
          // Set the window location to the URL of the PDF file
          const blob = new Blob([data], { type: 'application/pdf' });
          const url = window.URL.createObjectURL(blob);
          window.open(url, '_blank');
        } else if (filename.endsWith('.mp4')) {
          // Handle video files
          this.videoUrl = window.URL.createObjectURL(new Blob([data], { type: 'video/mp4' }));
        } else if (filename.endsWith('.png') || filename.endsWith('.jpg') || filename.endsWith('.jpeg')) {
          // Handle image files
          this.imageUrl = window.URL.createObjectURL(new Blob([data], { type: 'image/*' }));
        } else {
          // For other file types, trigger the file download as before
          this.downloadFile(data, filename);
        }
      },
      (error) => {
        console.error('Error viewing file:', error);
        alert('Error viewing file. Please try again later.');
      }
    );
  }

  // Helper function to revoke the video URL and image URL when they are no longer needed
  revokeUrls(): void {
    if (this.videoUrl) {
      window.URL.revokeObjectURL(this.videoUrl);
      this.videoUrl = null;
    }
    if (this.imageUrl) {
      window.URL.revokeObjectURL(this.imageUrl);
      this.imageUrl = null;
    }
  }

  // This function will be called when the component is destroyed
  ngOnDestroy(): void {
    this.revokeUrls();
  }
}
