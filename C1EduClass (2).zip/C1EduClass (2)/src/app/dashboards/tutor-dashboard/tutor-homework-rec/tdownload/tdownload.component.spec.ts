import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TdownloadComponent } from './tdownload.component';

describe('TdownloadComponent', () => {
  let component: TdownloadComponent;
  let fixture: ComponentFixture<TdownloadComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TdownloadComponent]
    });
    fixture = TestBed.createComponent(TdownloadComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
