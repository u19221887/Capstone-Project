import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TfileDeleteComponent } from './tfile-delete.component';

describe('TfileDeleteComponent', () => {
  let component: TfileDeleteComponent;
  let fixture: ComponentFixture<TfileDeleteComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TfileDeleteComponent]
    });
    fixture = TestBed.createComponent(TfileDeleteComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
