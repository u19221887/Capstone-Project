import { Component } from '@angular/core';

@Component({
  selector: 'app-tutor-onlinevideo',
  templateUrl: './tutor-onlinevideo.component.html',
  styleUrls: ['./tutor-onlinevideo.component.scss']
})
export class TutorOnlinevideoComponent {

}
