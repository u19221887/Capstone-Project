import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorOnlinevideoComponent } from './tutor-onlinevideo.component';

describe('TutorOnlinevideoComponent', () => {
  let component: TutorOnlinevideoComponent;
  let fixture: ComponentFixture<TutorOnlinevideoComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorOnlinevideoComponent]
    });
    fixture = TestBed.createComponent(TutorOnlinevideoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
