import { Component, OnInit } from '@angular/core';
import { BookingService } from 'src/app/services/booking.service';

@Component({
  selector: 'app-view-my-booking',
  templateUrl: './view-my-booking.component.html',
  styleUrls: ['./view-my-booking.component.css']
})
export class ViewMyBookingComponent implements OnInit {

  sessionList: any[] = [];

  constructor(private bookingService: BookingService) {

    //TODO: get Tutor Id
    this.bookingService.getBookingSessionTutor(
    ).subscribe((data: any) => {
      console.log(data)
      this.sessionList = data
      })
   }

  ngOnInit() {
  }

  getTime(dateTime: string, endTime: string){
    return `${new Date(dateTime).toLocaleTimeString('en-ZA')} - ${new Date(endTime).toLocaleTimeString('en-ZA')}   `
  }
}
