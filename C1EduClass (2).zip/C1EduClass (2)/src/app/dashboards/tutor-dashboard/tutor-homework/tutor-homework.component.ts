import { Component } from '@angular/core';

@Component({
  selector: 'app-tutor-homework',
  templateUrl: './tutor-homework.component.html',
  styleUrls: ['./tutor-homework.component.scss']
})
export class TutorHomeworkComponent {

}
