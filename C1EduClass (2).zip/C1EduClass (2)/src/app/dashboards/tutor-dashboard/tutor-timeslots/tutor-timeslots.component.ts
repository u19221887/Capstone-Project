import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder, FormControl, FormArray } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { TuiDay } from '@taiga-ui/cdk';
import { AudittrailService } from 'src/app/services/audittrail.service';
import { BookingService } from 'src/app/services/booking.service';
import { TimeslotService } from 'src/app/services/timeslot.service';
import { SuccessTimeslotsComponent } from 'src/app/utilities/modals/success-timeslots/success-timeslots.component';

@Component({
  selector: 'app-tutor-timeslots',
  templateUrl: './tutor-timeslots.component.html',
  styleUrls: ['./tutor-timeslots.component.scss']
})
export class TutorTimeslotsComponent implements OnInit{

  add = new FormData(); 
  tutor: string ='';
  
  acceptedauditTrail : FormGroup = this.fb.group({
    Email: [''],
    Action: ["added timeslots for "]
  })

  s: any;
  x: any;
  newvalue : any;

   addAuditTrail(){
    let j = JSON.parse(localStorage.getItem('User')!)
    console.log(j)
    this.tutor = j.username
    console.log(this.tutor)
    
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.x = this.s + this.checkBoxForm.get('Date')?.value;
    this.newvalue = this.tutor;

    this.acceptedauditTrail.get('Email')?.setValue(this.newvalue)
    this.acceptedauditTrail.get('Action')?.setValue(this.x)
     if (this.acceptedauditTrail.valid)
     {
       this.add.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.add.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.add).subscribe(()=>{
         console.log("added audit")
       })
     }
   }


  idvalue=0;


  companyTimeSlots: any = [];
  value: TuiDay | null = null;
  today: TuiDay = TuiDay.currentLocal();

  checkBoxForm!: FormGroup;



  constructor(private companyAvailabilityService: TimeslotService,private bookingService: BookingService,public fb: FormBuilder ,private snackBar: MatSnackBar, private router: Router, private dialog: MatDialog, private auditTrailService: AudittrailService) {
    this.checkBoxForm = this.fb.group({
      CompanyAvailabilities: this.fb.array([]),
      TutorId: new FormControl(1),  //TODO: get Tutor id from local storage
      Date: new FormControl("")
    });

    this.companyAvailabilityService.getCompanyAvailabilityTimes().subscribe((data: any) => {
      this.companyTimeSlots = data;
      console.log(data);
    })

   }



  ngOnInit() {
    //this.getfromLS();


  }

  getTime(dateTime: string, endTime: string){
    return `${new Date(dateTime).toLocaleTimeString('en-ZA')} - ${new Date(endTime).toLocaleTimeString('en-ZA')}   `
  }

  onChange(selectedOption: MatCheckboxChange) {
    const slots = (<FormArray>(
      this.checkBoxForm.get("CompanyAvailabilities")
    )) as FormArray;

    if (selectedOption.checked) {
      slots.push(new FormControl(selectedOption.source.value));
    } else {
      const i = slots.controls.findIndex(
        x => x.value === selectedOption.source.value
      );
      slots.removeAt(i);
    }
  }


  onDayClick(day: TuiDay): void {
    this.value = day;

    this.checkBoxForm.patchValue({
      Date:  day.toLocalNativeDate()
    })
}

  onSubmit() {

    try{

      console.log(this.checkBoxForm.value)
      this.companyAvailabilityService.addTutorAvailabilityTimes(this.checkBoxForm.value).subscribe(res => {
         console.log(res)
         this.addAuditTrail();
         this.router.navigate(['/tutor-dashboard/',this.idvalue]).then((navigated: boolean)=> {
           if (navigated){
             this.successModal();
           }
         });
      })

    }
    catch(e){
      console.log(e)
    }


  }

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)
  }

  successModal(){
    const dialogRef = this.dialog.open(SuccessTimeslotsComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
  }
}
