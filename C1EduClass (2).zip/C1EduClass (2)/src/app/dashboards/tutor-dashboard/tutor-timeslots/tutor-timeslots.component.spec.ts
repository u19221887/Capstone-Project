import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorTimeslotsComponent } from './tutor-timeslots.component';

describe('TutorTimeslotsComponent', () => {
  let component: TutorTimeslotsComponent;
  let fixture: ComponentFixture<TutorTimeslotsComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorTimeslotsComponent]
    });
    fixture = TestBed.createComponent(TutorTimeslotsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
