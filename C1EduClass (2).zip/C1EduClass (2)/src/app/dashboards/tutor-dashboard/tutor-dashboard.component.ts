import { Component, OnInit } from '@angular/core';
import { Tutor } from '../../shared/tutor';
import { FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute, RoutesRecognized } from '@angular/router';
import { APIService } from '../../services/api.service';


@Component({
  selector: 'app-tutor-dashboard',
  templateUrl: './tutor-dashboard.component.html',
  styleUrls: ['./tutor-dashboard.component.scss']
})
export class TutorDashboardComponent implements OnInit {

  
  constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute){
    this.getfromLS()
  }

  idvalue =0;


  // tutor: any

  // ngOnInit(): void {
  //     this.apiService.getTutor(+this.route.snapshot.params['id']).subscribe(result=>{
  //       this.tutor = result
  //       console.log(this.tutor)
  //     })
  //   }

  tId =0;
  getTutor!: any
  tutor!: any

  tutorInfo! : any;


  ngOnInit(): void {
    

    // GET THE ID FROM THE URL 
  //  this.activated.params.subscribe(params => { 


  //   //SEND OFF REQUEST TO DB TO FIND OBJECT DATA 
  //   this.studentService.getStudent(params['id']).subscribe(response => { //SUBSCRIBE TO THE RESPONSE

     
  //    this.getStudent = response as Student;
  //    console.log(this.getStudent)

     
  //   })

  //  })
  
  let o=JSON.parse(localStorage.getItem('User')!)
  console.log(o)

   this.apiService.getAllTutors().subscribe(response => { 

     
      this.tutor = response as Tutor[]; 
      console.log(this.tutor)
     this.getTutor=this.tutor.find((x: { tutorEmail: any; })=> x.tutorEmail==o.username)!
       console.log(this.getTutor,this.tutor)
  
       console.log(this.getTutor)
        this.tId = this.getTutor.id;
       console.log(this.tId)
       
     })

  //this.apiService.getTutorProfile(o.userEmail).subscribe((result: any)=>{
  //this.tutor = result});
  console.log(this.tutor);
  }

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)

    this.apiService.getTutor(this.idvalue).subscribe((result: any)=>{
      this.tutorInfo = result;
      console.log(this.tutorInfo)
    })
  }

  

logout() {
  localStorage.removeItem('User');
 
}

onLogoutClick() {
  this.logout();
  this.router.navigate(['/user']);
}

}
