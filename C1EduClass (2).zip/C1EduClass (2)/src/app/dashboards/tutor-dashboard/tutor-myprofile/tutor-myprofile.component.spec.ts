import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorMyprofileComponent } from './tutor-myprofile.component';

describe('TutorMyprofileComponent', () => {
  let component: TutorMyprofileComponent;
  let fixture: ComponentFixture<TutorMyprofileComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorMyprofileComponent]
    });
    fixture = TestBed.createComponent(TutorMyprofileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
