import { Component, OnInit } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';

@Component({
  selector: 'app-tutor-myprofile',
  templateUrl: './tutor-myprofile.component.html',
  styleUrls: ['./tutor-myprofile.component.scss']
})
export class TutorMyprofileComponent implements OnInit {
 
  constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute){}

  idvalue = 0;
  tutor: any

  ngOnInit(): void {
      this.apiService.getTutor(+this.route.snapshot.params['id']).subscribe(result=>{
        this.tutor = result
        console.log(this.tutor)
      })
      this.getfromLS();
    }

    getfromLS(){
      let o=JSON.parse(localStorage.getItem('Tutor')!)
      console.log(o)
      this.idvalue = o.id
      console.log(this.idvalue)
    }
}
