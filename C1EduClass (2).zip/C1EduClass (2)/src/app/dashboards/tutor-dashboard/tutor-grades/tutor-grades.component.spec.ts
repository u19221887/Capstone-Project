import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorGradesComponent } from './tutor-grades.component';

describe('TutorGradesComponent', () => {
  let component: TutorGradesComponent;
  let fixture: ComponentFixture<TutorGradesComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorGradesComponent]
    });
    fixture = TestBed.createComponent(TutorGradesComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
