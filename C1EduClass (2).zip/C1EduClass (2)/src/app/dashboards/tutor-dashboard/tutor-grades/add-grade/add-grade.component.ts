import { Component, OnInit } from '@angular/core';
import { FormArray, FormBuilder, FormControl, FormGroup } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { MatDialog } from '@angular/material/dialog';
import { AddGradeModalComponent } from 'src/app/utilities/modals/add-grade-modal/add-grade-modal.component';
import { AudittrailService } from 'src/app/services/audittrail.service';



@Component({
  selector: 'app-add-grade',
  templateUrl: './add-grade.component.html',
  styleUrls: ['./add-grade.component.scss']
})
export class AddGradeComponent implements OnInit{
  
  add = new FormData(); 
  tutor: string ='';
  
  acceptedauditTrail : FormGroup = this.fb.group({
    Email: [''],
    Action: ["added grades"]
  })

  s: any;
  newvalue : any;

   addAuditTrail(){
    let j = JSON.parse(localStorage.getItem('User')!)
    console.log(j)
    this.tutor = j.username
    console.log(this.tutor)
    
    this.s = this.acceptedauditTrail.get('Action')?.value;
    this.newvalue = this.tutor;

    this.acceptedauditTrail.get('Email')?.setValue(this.newvalue)
    this.acceptedauditTrail.get('Action')?.setValue(this.s)
     if (this.acceptedauditTrail.valid)
     {
       this.add.append('Email', this.acceptedauditTrail.get('Email')!.value)
       this.add.append('Action', this.acceptedauditTrail.get('Action')!.value)

       this.auditTrailService.addAuditTrail(this.add).subscribe(()=>{
         console.log("added audit")
       })
     }
   }


  constructor(private apiService: APIService,private snackBar: MatSnackBar, private router: Router, public fb: FormBuilder, private dialog: MatDialog, private auditTrailService : AudittrailService){
    this.getfromLS();
    this.checkBoxForm = this.fb.group({
      Grades: this.fb.array([]),
      TutorId : new FormControl(this.idvalue)
    });
      this.apiService.getGradesforTutorThatTheyCanAdd(this.idvalue).subscribe((data: any)=>{
        this.grades = data;
        console.log(this.grades)
      })
    }

  ngOnInit(): void {
   this.getfromLS();
  }
  
  
  idvalue =0;

  grades: any =[];

  gradesToshow: any = [];

  onlyShowThese(){
    this.apiService.getGradesforTutorThatTheyCanAdd(this.idvalue).subscribe((result: any)=>{
      this.gradesToshow = result
      console.log(this.gradesToshow)
    });
  }

  getAllGradesforTutor()
   {
     this.apiService.getAllGradesforTutor(this.idvalue).subscribe((result: any)=>{
      this.gradesToshow=result
      console.log(this.gradesToshow)
      
      });
    
   }

  checkBoxForm! : FormGroup;
  
  getAllGrades()
  {
    this.apiService.getAllGrades().subscribe(result=>{
      let GradeList: any[]=result
      GradeList.forEach((element)=>{
        this.grades.push(element)
        //console.log(tutorApplicationList);
        console.log(this.grades);
      });
    })
  }

  onChange(selectedOption: MatCheckboxChange) {
    const slots = (<FormArray>(
      this.checkBoxForm.get("Grades")
    )) as FormArray;

    if (selectedOption.checked) {
      slots.push(new FormControl(selectedOption.source.value));
    } else {
      const i = slots.controls.findIndex(
        x => x.value === selectedOption.source.value
      );
      slots.removeAt(i);
    }
  }

  onSubmit() {

    try{

      console.log(this.checkBoxForm.value)
      this.apiService.addTutorGrades(this.checkBoxForm.value).subscribe(res => {
        console.log(res)
        this.addAuditTrail();
        this.router.navigate(['/tutor-dashboard/',this.idvalue]).then((navigated: boolean)=> {
          if (navigated){
           // this.snackBar.open(`Grades added successfully`, 'X', {duration: 5000});
           this.successModal();
          }
        });
      })

    }
    catch(e){
      console.log(e)
    }


  }

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)

    let j = JSON.parse(localStorage.getItem('User')!)
    console.log(j)
    this.tutor = j.username
    console.log(this.tutor)
  }



  successModal(){
    const dialogRef = this.dialog.open(AddGradeModalComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
  }

  
}
