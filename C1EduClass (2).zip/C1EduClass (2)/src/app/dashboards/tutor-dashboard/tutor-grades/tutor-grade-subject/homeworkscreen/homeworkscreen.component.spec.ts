import { ComponentFixture, TestBed } from '@angular/core/testing';

import { HomeworkscreenComponent } from './homeworkscreen.component';

describe('HomeworkscreenComponent', () => {
  let component: HomeworkscreenComponent;
  let fixture: ComponentFixture<HomeworkscreenComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [HomeworkscreenComponent]
    });
    fixture = TestBed.createComponent(HomeworkscreenComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
