import { Component, OnInit } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { DeleteSubjectModalComponent } from 'src/app/utilities/modals/delete-subject-modal/delete-subject-modal.component';

@Component({
  selector: 'app-tutor-grade-subject',
  templateUrl: './tutor-grade-subject.component.html',
  styleUrls: ['./tutor-grade-subject.component.scss']
})
export class TutorGradeSubjectComponent implements OnInit {

  idValue =0;
  

  
  constructor(private apiService: APIService, private router: Router, private route: ActivatedRoute, private dialog: MatDialog){
    this.getfromLS();

    this.apiService.getTutorGradeforSubject(+this.route.snapshot.params['id']).subscribe(result=>{
      this.tutorGrade = result
      console.log(this.tutorGrade)
    })

    this.getAllSubjectsforTutor();
    this.getTutorGradefromGradeId();

    this.gradeid = this.route.snapshot.params['id'];
    console.log(this.gradeid)
  }
  grade : any
  
  ngOnInit(): void {
    this.apiService.getGradeById(this.tutorGrade.gradeId).subscribe(result=>{
      this.grade = result
    })

    
  }
  idvalue =0;
  tutor: any

  tutorGrade:any



  subjects: any =[];

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)
  }

  deleteTutorSubject(tutorGradeId:number, subjectid:number){
    this.apiService.deleteTutorGradeSubject(tutorGradeId, subjectid).subscribe(result=>{
    window.location.reload();
    this.deleteModal();
    })
    

  }

  getAllSubjectsforTutor(){
    this.apiService.getAllSubjectsforTutor(this.route.snapshot.params['id']).subscribe((result: any)=>{
      this.subjects = result
      console.log(this.subjects)
    })
  }

  getTutorGradefromGradeId()
   {
    this.apiService.getTutorGrade(this.route.snapshot.params['id']).subscribe(result=>{
      this.tutorGrade = result
      //this.router.navigate(['/tutor-grade-subject', this.tutorGrade.id]);


      console.log(this.tutorGrade)
      this.apiService.getGradeById(this.tutorGrade.gradeId).subscribe(result=>{
        this.grade = result
        console.log(this.grade)
      })
    })
   }

  deleteModal(){
    const dialogRef = this.dialog.open(DeleteSubjectModalComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
  }
  
  routingid? :any;
  routingidd? :number;

  getGradeSubjectIdforHomework(subjectid: number, gradeidd : number){
    this.apiService.getGradeSubjectId(subjectid,gradeidd).subscribe(result=>{
      this.routingid = result
      this.routingidd = this.routingid[0].id
      console.log(this.routingid)
      console.log(this.routingidd)
      this.router.navigate(['/homework', this.routingidd])
    })
    
  }

  getGradeSubjectIdforVideos(subjectid: number, gradeidd : number){
    this.apiService.getGradeSubjectId(subjectid,gradeidd).subscribe(result=>{
      this.routingid = result
      this.routingidd = this.routingid[0].id
      console.log(this.routingid)
      console.log(this.routingidd)
      this.router.navigate(['/video', this.routingidd])
    })
    
  }


  gradeid : number;

  
}
