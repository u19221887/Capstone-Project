import { Component } from '@angular/core';
import { FormBuilder } from '@angular/forms';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { APIService } from 'src/app/services/api.service';

@Component({
  selector: 'app-homeworkscreen',
  templateUrl: './homeworkscreen.component.html',
  styleUrls: ['./homeworkscreen.component.scss']
})
export class HomeworkscreenComponent {

  constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute){
    this.getfromLS()
  }
  
  idvalue =0;
  tutorInfo! : any;

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)

    this.apiService.getTutor(this.idvalue).subscribe((result: any)=>{
      this.tutorInfo = result;
      console.log(this.tutorInfo)
    })
  }

  logout() {
    localStorage.removeItem('User');
   
  }
  
  onLogoutClick() {
    this.logout();
    this.router.navigate(['/user']);
  }

}
