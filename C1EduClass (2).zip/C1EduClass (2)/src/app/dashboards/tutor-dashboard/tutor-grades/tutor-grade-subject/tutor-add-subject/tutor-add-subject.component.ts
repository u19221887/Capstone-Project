import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, FormArray } from '@angular/forms';
import { MatCheckboxChange } from '@angular/material/checkbox';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { AddSubjectModalComponent } from 'src/app/utilities/modals/add-subject-modal/add-subject-modal.component';

@Component({
  selector: 'app-tutor-add-subject',
  templateUrl: './tutor-add-subject.component.html',
  styleUrls: ['./tutor-add-subject.component.scss']
})
export class TutorAddSubjectComponent implements OnInit {
  constructor(private apiService: APIService,private snackBar: MatSnackBar, private router: Router, public fb: FormBuilder,private route: ActivatedRoute, private dialog: MatDialog){
    this.getfromLS();

   
    this.apiService.getTutorGrade(this.route.snapshot.params['id']).subscribe(result=>{
    this.tutorGrade = result
    console.log(this.tutorGrade) })


      
   

    this.apiService.getTutorGradeforSubject(+this.route.snapshot.params['id']).subscribe((data: any)=>{
      this.tutorSubject = data
      console.log(this.tutorSubject)

    this.checkBoxForm = this.fb.group({
      Subjects: this.fb.array([]),
      TutorGradeId : new FormControl(this.tutorGrade.id)
    });

      this.apiService.getSubjectsforTutorThatTheyCanAdd(this.tutorGrade.id).subscribe((data: any)=>{
        this.subjects = data;
        console.log(this.subjects)
      })
    
    })
  }

    tutorGrade:any

    tutorSubject : any[] = [];

  ngOnInit(): void {
   this.getfromLS();
  }
  
  
  idvalue =0;

  subjects: any =[];

  subjectsToshow: any = [];

  onlyShowThese(){
    this.apiService.getSubjectsforTutorThatTheyCanAdd(this.idvalue).subscribe((result: any)=>{
      this.subjectsToshow = result
      console.log(this.subjectsToshow)
    });
  }

  getAllSubjectsforTutor()
   {
     this.apiService.getAllSubjectsforTutor(this.idvalue).subscribe((result: any)=>{
      this.subjectsToshow=result
      console.log(this.subjectsToshow)
      
      });
    
   }

  checkBoxForm! : FormGroup;
  
  getAllSubjects()
  {
    this.apiService.getSubjects().subscribe(result=>{
      let GradeList: any[]=result
      GradeList.forEach((element)=>{
        this.subjects.push(element)
        //console.log(tutorApplicationList);
        console.log(this.subjects);
      });
    })
  }

  onChange(selectedOption: MatCheckboxChange) {
    const slots = (<FormArray>(
      this.checkBoxForm.get("Subjects")
    )) as FormArray;

    if (selectedOption.checked) {
      slots.push(new FormControl(selectedOption.source.value));
    } else {
      const i = slots.controls.findIndex(
        x => x.value === selectedOption.source.value
      );
      slots.removeAt(i);
    }
  }

  onSubmit() {

    try{

      console.log(this.checkBoxForm.value)
      this.apiService.addTutorGradeSubjects(this.checkBoxForm.value).subscribe(res => {
        console.log(res)
        this.router.navigate(['/tutor-grade-subject',this.tutorGrade.id]).then((navigated: boolean)=> {
          if (navigated){
            this.snackBar.open(`Subjects added successfully`, 'X', {duration: 5000});
          }
        });
      })

    }
    catch(e){
      console.log(e)
    }


  }

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)
  }

  successModal(){
    const dialogRef = this.dialog.open(AddSubjectModalComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
  }


  
}
  

