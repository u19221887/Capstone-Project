import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorAddSubjectComponent } from './tutor-add-subject.component';

describe('TutorAddSubjectComponent', () => {
  let component: TutorAddSubjectComponent;
  let fixture: ComponentFixture<TutorAddSubjectComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorAddSubjectComponent]
    });
    fixture = TestBed.createComponent(TutorAddSubjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
