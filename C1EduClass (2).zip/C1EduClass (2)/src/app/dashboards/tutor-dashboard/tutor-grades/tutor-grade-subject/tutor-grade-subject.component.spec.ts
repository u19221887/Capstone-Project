import { ComponentFixture, TestBed } from '@angular/core/testing';

import { TutorGradeSubjectComponent } from './tutor-grade-subject.component';

describe('TutorGradeSubjectComponent', () => {
  let component: TutorGradeSubjectComponent;
  let fixture: ComponentFixture<TutorGradeSubjectComponent>;

  beforeEach(() => {
    TestBed.configureTestingModule({
      declarations: [TutorGradeSubjectComponent]
    });
    fixture = TestBed.createComponent(TutorGradeSubjectComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
