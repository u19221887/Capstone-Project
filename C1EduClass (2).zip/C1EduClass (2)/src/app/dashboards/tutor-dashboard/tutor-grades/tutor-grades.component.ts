import { Component } from '@angular/core';
import { MatDialog } from '@angular/material/dialog';
import { ActivatedRoute, Router } from '@angular/router';
import { APIService } from 'src/app/services/api.service';
import { Grade } from 'src/app/shared/grade';
import { Tutor } from 'src/app/shared/tutor';
import { DeleteGradeModalComponent } from 'src/app/utilities/modals/delete-grade-modal/delete-grade-modal.component';

@Component({
  selector: 'app-tutor-grades',
  templateUrl: './tutor-grades.component.html',
  styleUrls: ['./tutor-grades.component.scss']
})
export class TutorGradesComponent {


  constructor(private apiService: APIService, private router: Router, private route: ActivatedRoute, private dialog: MatDialog){}
  
  idvalue =0;
  tutor: any


  grades: any =[];

  gradeData: any[] = [];

  gradeName : any [] = [];

  tutorGrade : any 

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)
  }

  // getTutor(idvalue: number){
  //   this.apiService.getTutor(this.idvalue).subscribe((result: any)=>{
  //     this.tutor = result});
  //     console.log(this.tutor);
  //  }

  

   getAllGradesforTutor()
   {
     this.apiService.getAllGradesforTutor(this.route.snapshot.params['id']).subscribe((result: any)=>{
      this.grades=result
      console.log(this.grades)
      
      });
    
   }


   getTutorGradefromGradeId(gId : Number)
   {
    this.apiService.getTutorGradefromGradeId(gId).subscribe(result=>{
      this.tutorGrade = result
      this.router.navigate(['/tutor-grade-subject', this.tutorGrade.id]);


      console.log(this.tutorGrade)
    })
   }

  ngOnInit(): void {
    
    this.getfromLS();
    console.log(this.idvalue)

    this.apiService.getTutor(+this.route.snapshot.params['id']).subscribe(result=>{
      this.tutor = result
      console.log(this.tutor)

    this.getGradeName();
    })

    this.getAllGradesforTutor();

    

    
  }
  

  deleteTutorGrade(tutorId: number, gradeId: number){
    this.apiService.deleteTutorGrade(tutorId, gradeId).subscribe(result=>{
      window.location.reload();
      this.deleteGrade();
    })
  }

  
  getGrades(){
    this.apiService.getAllGrades().subscribe(result =>{
      let gradeList : any[]= result
      gradeList.forEach((element)=>
      this.gradeData.push(element))
    });
  }
  
  getGradeName(){
    this.apiService.getGradeName(this.idvalue).subscribe(result =>{
      let gradeDataNames = result
      gradeDataNames.forEach((element: any)=>
      this.gradeName.push(element))
    })
    console.log(this.gradeName)
  }

  getTutorGrade(gradeId : number){
    console.log(gradeId)
    this.apiService.getTutorGrade(gradeId).subscribe(result =>{
      let val = result
      this.router.navigate(['/tutor-grade-subject', val]);
    })
  }

  deleteGrade(){
    const dialogRef = this.dialog.open(DeleteGradeModalComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
  }
  
}
