import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { MatDialog } from '@angular/material/dialog';
import { MatSnackBar } from '@angular/material/snack-bar';
import { Router, ActivatedRoute } from '@angular/router';
import { EditSuccessModalComponent } from 'src/app/utilities/modals/edit-success-modal/edit-success-modal.component';
import { APIService } from 'src/app/services/api.service';
import { Tutor } from 'src/app/shared/tutor';
import { TutorType } from 'src/app/shared/tutorType';

@Component({
  selector: 'app-tutor-settings',
  templateUrl: './tutor-settings.component.html',
  styleUrls: ['./tutor-settings.component.scss']
})
export class TutorSettingsComponent implements OnInit {

   
  idvalue=0;
  tutor: any

  formsData = new FormData();

  constructor(private apiService: APIService, private fb: FormBuilder, private router: Router, private snackBar: MatSnackBar, private route: ActivatedRoute ,private dialog: MatDialog){

  }

  tutorForm : FormGroup = this.fb.group(
    {
        title: ['',Validators.required],
        tutorName:  ['',Validators.required],
        tutorSurname:  ['',Validators.required],
        tutorEmail:  ['',Validators.required],
        tutorPhoneNumber: ['',Validators.required],
        tutorAddress:  ['',Validators.required],
        tutorCity:  ['',Validators.required],
        tutorPostalCode:  ['',Validators.required],
        tutorProvince :  ['',Validators.required],
        tutorIdNumber : ['', Validators.required],
        tutorType :['', Validators.required]
    }
  )

  typeid? : any
  ngOnInit() {
    this.GetTutorTypes()
    this.getfromLS();

    this.apiService.getTutor(this.idvalue).subscribe(result=>{
      this.tutor = result
      this.tutorForm.patchValue({
        title: this.tutor.title,
        tutorName: this.tutor.tutorName,
        tutorSurname: this.tutor.tutorSurname,
        tutorEmail: this.tutor.tutorEmail,
        tutorPhoneNumber: this.tutor.tutorPhoneNumber,
        tutorAddress: this.tutor.tutorAddress,
        tutorCity: this.tutor.tutorCity,
        tutorPostalCode: this.tutor.tutorPostalCode,
        tutorProvince : this.tutor.tutorProvince,
        tutorIdNumber : this.tutor.tutorIdNumber,
        tutorType : this.tutor.tutorTypeId,
        

        
        
        
      })
      console.log(result);
      this.typeid = this.tutor.tutorTypeId;
      this.tutor = result;
      console.log(this.tutor)
      console.log(this.typeid)
    })
   
  
  }

  onSubmit(){
    console.log('Form validity:', this.tutorForm.valid);
    if(this.tutorForm.valid){
      this.formsData.append('title', this.tutorForm.get('title')!.value);
      this.formsData.append('tutorName', this.tutorForm.get('tutorName')!.value);
      this.formsData.append('tutorSurname', this.tutorForm.get('tutorSurname')!.value);
      this.formsData.append('tutorEmail', this.tutorForm.get('tutorEmail')!.value);
      this.formsData.append('tutorPhoneNumber', this.tutorForm.get('tutorPhoneNumber')!.value);
      this.formsData.append('tutorAddress', this.tutorForm.get('tutorAddress')!.value);
      this.formsData.append('tutorCity', this.tutorForm.get('tutorCity')!.value);
      this.formsData.append('tutorPostalCode', this.tutorForm.get('tutorPostalCode')!.value);
      this.formsData.append('tutorProvince', this.tutorForm.get('tutorProvince')!.value);
      this.formsData.append('tutorIdNumber',this.tutorForm.get('tutorIdNumber')!.value);
      this.formsData.append('tutorType', this.tutorForm.get('tutorType')!.value);

      console.log(this.formsData)
      
      this.apiService.editTutor(this.idvalue, this.formsData).subscribe(()=>{
        this.router.navigate(['/tutor-dashboard',this.idvalue])
        this.UpdateModal();
      })

      

    }
    

  }

  tutorTypeData: TutorType[] =[]

  GetTutorTypes(){
    this.apiService.getTutorTypes().subscribe(result => {
      let tutorTypeList:any[] = result
      tutorTypeList.forEach((element) => {
        this.tutorTypeData.push(element)
      });

      
    });
  }

  cancel(){

  }

  getfromLS(){
    let o=JSON.parse(localStorage.getItem('Tutor')!)
    console.log(o)
    this.idvalue = o.id
    console.log(this.idvalue)
  }

  UpdateModal(){
    const dialogRef = this.dialog.open(EditSuccessModalComponent,{
      width: '700px',
      height: '400px',
      disableClose:true,
    });
  }
}
