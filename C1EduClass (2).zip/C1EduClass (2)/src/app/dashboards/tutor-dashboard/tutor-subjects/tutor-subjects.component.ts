import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup } from '@angular/forms';
// import { ToastrService } from 'ngx-toastr';
import { TutorService } from 'src/app/services/tutor.service';
import { MatDialog } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AddSubjectModalComponent } from 'src/app/utilities/modals/add-subject-modal/add-subject-modal.component';

@Component({
  selector: 'app-tutor-subjects',
  templateUrl: './tutor-subjects.component.html',
  styleUrls: ['./tutor-subjects.component.css']
})
export class TutorSubjectsComponent implements OnInit {

  subjectList: any[] = [];
  mySubjectList: any[] = [];
  linkObject: any = {
    tutorId: 1,
    subjectId: 0
  };

open = false;


  constructor(private tutorService: TutorService,
    private dialog: MatDialog,
    private router: Router
    // private toastr: ToastrService
    ) {
    this.getAllSubjects();
    this.getMySubjects();
  }

  ngOnInit() {
  }

  showDialog(): void {
    this.open = true;
}


readonly stringify = (item: {name: string; surname: string}): string =>
`${item.name} ${item.surname}`;

//get my subjects
getMySubjects(){
  this.tutorService.getMySubjects().subscribe((data:any)=>{
    this.mySubjectList = data;
    console.log(data)
  });

}

linkSubject(){

  //get subject id abd tutor id from from somewhere
  this.tutorService.linkSubjectToTutor(this.linkObject).subscribe((data:any)=>{
    // this.toastr.success('Subject linked successfully');
    this.getMySubjects();

    this.subjectLinked();

    this.router.navigate(['/tutor-subjects']).then((navigated: boolean) => {
      if (navigated) {

      }
    });
  });
}

//unlink subject from tutor
unlinkSubject(subTutorId:number){
  this.tutorService.unlinkSubjectFromTutor(subTutorId).subscribe((data:any)=>{
    // this.toastr.success('Subject unlinked successfully');
    this.getMySubjects();
  })
}

getAllSubjects(){
  this.tutorService.getAllSubjects().subscribe((data:any)=>{
    console.log(data);

    this.subjectList = data;
  });
}


subjectLinked() {
  const dialogRef = this.dialog.open(AddSubjectModalComponent, {
    width: '700px',
  height: '400px',
    disableClose: true,
  });

  dialogRef.afterClosed().subscribe(() => {

    //this.login.reset();
  });
}

}
